const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Replace Super Fiesta
if (code.includes('(Super Fiesta)')) {
  code = code.replace('(Super Fiesta)', '(Pentagon)');
  console.log('Replaced Super Fiesta');
} else {
  console.log('Could not find Super Fiesta');
}

// Replace Compare Models pull handle to make it clickable
const compareHandle = '<div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0" />';
const compareHandleNew = '<div onClick={() => setShowCompareSelector(false)} className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0 cursor-pointer hover:bg-gray-400" />';
if (code.includes(compareHandle)) {
  code = code.replace(compareHandle, compareHandleNew);
  console.log('Replaced Compare handle');
} else {
  console.log('Could not find Compare handle');
}

// Replace Choose Model pull handle to make it clickable
const chooseHandle = '<div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0" />';
const chooseHandleNew = '<div onClick={() => { setShowModelMenu(false); setShowProviderFilter(false); }} className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0 cursor-pointer hover:bg-gray-400" />';
if (code.includes(chooseHandle)) {
  code = code.replace(chooseHandle, chooseHandleNew);
  console.log('Replaced Choose handle');
} else {
  console.log('Could not find Choose handle');
}

// Fix RotateCcw button for Reset Filter in Choose Model
const resetFilterBtn = '<button onClick={() => {}} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300">';
const resetFilterBtnNew = '<button onClick={() => { setModelSearchQuery(""); setSelectedProviderFilter(null); }} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300 transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer">';
if (code.includes(resetFilterBtn)) {
  code = code.replace(resetFilterBtn, resetFilterBtnNew);
  console.log('Replaced Reset Filter button');
} else {
  console.log('Could not find Reset Filter button');
}

// Write file
fs.writeFileSync('src/components/AiAgentChat.tsx', code);
