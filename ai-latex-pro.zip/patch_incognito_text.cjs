const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const targetText = 'This chat will not be saved to history, reflected in memory, or used to train AI models. We will keep your chat for up to 30 days.';
const newText = 'This chat is entirely private. It will not be saved to local history, cloud storage, or anywhere else. It will disappear completely once you close or switch the chat.';

if (code.includes(targetText)) {
  code = code.replace(targetText, newText);
  fs.writeFileSync('src/components/AiAgentChat.tsx', code);
  console.log('Successfully patched incognito description text.');
} else {
  console.log('Could not find incognito description text.');
}
