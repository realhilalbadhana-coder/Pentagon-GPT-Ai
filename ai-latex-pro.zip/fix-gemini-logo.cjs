const fs = require('fs');
let content = fs.readFileSync('src/components/ModelLogos.tsx', 'utf8');

const geminiProComponent = `export const GeminiProLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.progem} 
    alt="Google Gemini Pro" 
    className={\`\${className} object-contain inline-block shrink-0\`} 
    referrerPolicy="no-referrer"
  />
);

// 1. Google Gemini Official Icon`;

content = content.replace(/\/\/ 1\. Google Gemini Official Icon/g, geminiProComponent);

fs.writeFileSync('src/components/ModelLogos.tsx', content, 'utf8');
