const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Replace Choose Model pull handle
const chooseHandle = '<div onClick={() => { setShowModelMenu(false); setShowProviderFilter(false); }} className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0 cursor-pointer hover:bg-gray-400" />';
const chooseHandleNew = '<div onClick={() => { setShowModelMenu(false); setShowProviderFilter(false); }} className="w-full h-8 flex items-center justify-center cursor-pointer shrink-0" title="Slide down to close"><div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full" /></div>';

if (code.includes(chooseHandle)) {
  code = code.replace(chooseHandle, chooseHandleNew);
  console.log('Replaced Choose handle container');
}

// Replace Compare handle
const compareHandle = '<div onClick={() => setShowCompareSelector(false)} className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0 cursor-pointer hover:bg-gray-400" />';
const compareHandleNew = '<div onClick={() => setShowCompareSelector(false)} className="w-full h-8 flex items-center justify-center cursor-pointer shrink-0" title="Slide down to close"><div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full" /></div>';

if (code.includes(compareHandle)) {
  code = code.replace(compareHandle, compareHandleNew);
  console.log('Replaced Compare handle container');
}

fs.writeFileSync('src/components/AiAgentChat.tsx', code);
