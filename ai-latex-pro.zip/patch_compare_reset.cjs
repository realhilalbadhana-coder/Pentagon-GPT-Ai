const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const compareResetBtn = '<button onClick={() => {}} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300 opacity-0 pointer-events-none">';
const compareResetBtnNew = '<button onClick={() => setCompareSelectedModels([])} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300 transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer">';

if (code.includes(compareResetBtn)) {
  code = code.replace(compareResetBtn, compareResetBtnNew);
  fs.writeFileSync('src/components/AiAgentChat.tsx', code);
  console.log('Successfully patched compare reset button');
} else {
  console.log('Could not find compare reset button');
}
