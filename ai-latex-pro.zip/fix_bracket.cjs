const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');
code = code.replace('{/* Bottom Pill (Copilot style) */}}', '{/* Bottom Pill (Copilot style) */}');
fs.writeFileSync('src/components/AiAgentChat.tsx', code, 'utf8');
