import express from 'express';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
// Vite imported dynamically in development
import { GoogleGenAI, Modality } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// 7 NVIDIA NIM API Keys Pool
const DEFAULT_NVIDIA_KEYS = [
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
];

function getNvidiaKeys(): string[] {
  // Check individual environment variables first
  const individualKeys: string[] = [];
  for (let i = 1; i <= 7; i++) {
    const key = process.env[`NVIDIA_API_KEY_${i}`];
    if (key && key.trim()) {
      individualKeys.push(key.trim());
    }
  }
  if (individualKeys.length > 0) return individualKeys;

  // Check comma-separated NVIDIA_API_KEYS
  if (process.env.NVIDIA_API_KEYS) {
    const envKeys = process.env.NVIDIA_API_KEYS.split(',').map(k => k.trim()).filter(Boolean);
    if (envKeys.length > 0) return envKeys;
  }

  // Fallback to built-in 7 keys pool
  return DEFAULT_NVIDIA_KEYS;
}

const DEFAULT_OPENROUTER_KEYS = [
  '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',
  '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',
  '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',
];

function getOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_API_KEY.trim());
  }
  if (process.env.OPENROUTER_DEEPSEEK_API_KEY && process.env.OPENROUTER_DEEPSEEK_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_DEEPSEEK_API_KEY.trim());
  }
  if (process.env.DEEPSEEK_OPENROUTER_API_KEY && process.env.DEEPSEEK_OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.DEEPSEEK_OPENROUTER_API_KEY.trim());
  }
  if (process.env.DEEPSEEK_API_KEY && process.env.DEEPSEEK_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.DEEPSEEK_API_KEY.trim());
  }
  for (let i = 1; i <= 10; i++) {
    const key = process.env[`OPENROUTER_API_KEY_${i}`];
    if (key && key.trim() && !keys.includes(key.trim())) {
      keys.push(key.trim());
    }
  }
  if (process.env.OPENROUTER_API_KEYS) {
    const split = process.env.OPENROUTER_API_KEYS.split(',').map(k => k.trim()).filter(k => k.length > 10);
    for (const k of split) {
      if (!keys.includes(k)) keys.push(k);
    }
  }
  for (const k of DEFAULT_OPENROUTER_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getDeepSeekDirectKeys(): string[] {
  const keys: string[] = [];
  if (process.env.DEEPSEEK_API_KEY && process.env.DEEPSEEK_API_KEY.trim().length > 10 && !process.env.DEEPSEEK_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.DEEPSEEK_API_KEY.trim());
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getOpenAiOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_OPENAI_API_KEY && process.env.OPENROUTER_OPENAI_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_OPENAI_API_KEY.trim());
  }
  if (process.env.OPENAI_OPENROUTER_API_KEY && process.env.OPENAI_OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENAI_OPENROUTER_API_KEY.trim());
  }
  if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.OPENAI_API_KEY.trim());
  }
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`OPENROUTER_API_KEY_${i}`];
    if (k && k.trim().length > 10 && !keys.includes(k.trim())) {
      keys.push(k.trim());
    }
  }
  if (process.env.OPENROUTER_API_KEYS) {
    const split = process.env.OPENROUTER_API_KEYS.split(',').map(k => k.trim()).filter(k => k.length > 10);
    for (const k of split) {
      if (!keys.includes(k)) keys.push(k);
    }
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    const k = process.env.OPENROUTER_API_KEY.trim();
    if (!keys.includes(k)) keys.push(k);
  }
  for (const k of DEFAULT_OPENROUTER_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getOpenAiDirectKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim().length > 10 && !process.env.OPENAI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.OPENAI_API_KEY.trim());
  }
  for (let i = 1; i <= 6; i++) {
    const key = process.env[`OPENAI_API_KEY_${i}`];
    if (key && key.trim().length > 10 && !key.trim().startsWith('sk-or-')) {
      keys.push(key.trim());
    }
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getGroqKeys(): string[] {
  const keys: string[] = [];
  if (process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.trim()) {
    keys.push(process.env.GROQ_API_KEY.trim());
  }
  for (let i = 1; i <= 6; i++) {
    const key = process.env[`GROQ_API_KEY_${i}`];
    if (key && key.trim()) {
      keys.push(key.trim());
    }
  }
  // User provided Groq API Key for Whisper transcription & Groq models
  const defaultGroqKey = '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';
  if (defaultGroqKey && !keys.includes(defaultGroqKey)) {
    keys.push(defaultGroqKey);
  }
  return Array.from(new Set(keys));
}

function getMimoKeys(): string[] {
  const keys: string[] = [];
  const userMimoKey = 'sk-s2y9pgi4zdgeg545nmbp46e4qrdc83lgaylr6zmvf64nc2ud';
  if (userMimoKey && userMimoKey.trim()) {
    keys.push(userMimoKey.trim());
  }
  if (process.env.MIMO_API_KEY && process.env.MIMO_API_KEY.trim()) {
    keys.push(process.env.MIMO_API_KEY.trim());
  }
  for (let i = 1; i <= 6; i++) {
    const key = process.env[`MIMO_API_KEY_${i}`];
    if (key && key.trim()) {
      keys.push(key.trim());
    }
  }
  const fallbackMimoKey = 'sk-s1f70086k3e2fsfv1rgefou6lc15y4jjrvkuaceh3zqxh7ow';
  if (fallbackMimoKey && !keys.includes(fallbackMimoKey)) {
    keys.push(fallbackMimoKey);
  }
  return Array.from(new Set(keys));
}
let activeMimoKeyIndex = 0;

function getZaiKeys() {
  const envKeys = [
    process.env.ZAI_API_KEY,
    process.env.OPENROUTER_API_KEY_1,
  ];
  const keys = envKeys.filter(k => k && k.trim().length > 10).map(k => k.trim());
  return Array.from(new Set(keys));
}
let activeZaiKeyIndex = 0;

function getMistralKeys(): string[] {
  const keys: string[] = [];
  if (process.env.MISTRAL_API_KEY && process.env.MISTRAL_API_KEY.trim()) {
    keys.push(process.env.MISTRAL_API_KEY.trim());
  }
  for (let i = 1; i <= 6; i++) {
    const key = process.env[`MISTRAL_API_KEY_${i}`];
    if (key && key.trim()) {
      keys.push(key.trim());
    }
  }
  // Also fallback to any legacy CEREBRAS key if user had it set
  if (process.env.CEREBRAS_API_KEY && process.env.CEREBRAS_API_KEY.trim()) {
    keys.push(process.env.CEREBRAS_API_KEY.trim());
  }
  return keys;
}


function getTokenRouterKeys(): string[] {
  const keys: string[] = [];
  
  // Single variable names
  const singleVarNames = [
    'TOKEN_ROUTER_API_KEY',
    'TOKEN_ROUTER_KEY',
    'NOVITA_API_KEY',
    'NOVOTIA_API_KEY',
    'NOVITA_AI_API_KEY',
    'NOVITAAI_API_KEY',
    'NOVITA_KEY',
    'NOVOTIA_KEY',
    'GROK_API_KEY',
    'GROK_KEY',
    'XAI_API_KEY'
  ];

  for (const varName of singleVarNames) {
    const val = process.env[varName];
    if (val && val.trim() && !keys.includes(val.trim())) {
      keys.push(val.trim());
    }
  }

  // Comma-separated variable names
  const multiVarNames = ['TOKEN_ROUTER_API_KEYS', 'NOVITA_API_KEYS', 'NOVOTIA_API_KEYS', 'GROK_API_KEYS'];
  for (const varName of multiVarNames) {
    const val = process.env[varName];
    if (val && val.trim()) {
      const split = val.split(',').map(k => k.trim()).filter(Boolean);
      for (const k of split) {
        if (!keys.includes(k)) keys.push(k);
      }
    }
  }

  // Indexed variable names (1..6)
  const prefixes = ['TOKEN_ROUTER_API_KEY_', 'NOVITA_API_KEY_', 'NOVOTIA_API_KEY_', 'NOVITA_KEY_', 'GROK_API_KEY_'];
  for (const prefix of prefixes) {
    for (let i = 1; i <= 6; i++) {
      const key = process.env[`${prefix}${i}`];
      if (key && key.trim() && !keys.includes(key.trim())) {
        keys.push(key.trim());
      }
    }
  }

  return keys;
}

function getSambanovaKeys(): string[] {
  const keys: string[] = [];
  for (let i = 1; i <= 4; i++) {
    const key = process.env[`SAMBANOVA_API_KEY_${i}`];
    if (key && key.trim()) {
      keys.push(key.trim());
    }
  }
  return keys;
}

const DEFAULT_GEMINI_TTS_KEYS = [
  'AQ.Ab8RN6IwJ01vdol_j2XCfq2tHSJw14y99aSFG294aV6RwcHhMA'
];

function getGeminiKeys(): string[] {
  const keys: string[] = [];
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() && !process.env.GEMINI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.GEMINI_API_KEY.trim());
  }
  for (let i = 1; i <= 5; i++) {
    const key = process.env[`GEMINI_API_KEY_${i}`];
    if (key && key.trim() && !key.trim().startsWith('sk-or-')) {
      keys.push(key.trim());
    }
  }
  for (const k of DEFAULT_GEMINI_TTS_KEYS) {
    if (!keys.includes(k)) {
      keys.push(k);
    }
  }
  return keys;
}

function getGeminiOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_GEMINI_API_KEY && process.env.OPENROUTER_GEMINI_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_GEMINI_API_KEY.trim());
  }
  if (process.env.GEMINI_OPENROUTER_API_KEY && process.env.GEMINI_OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.GEMINI_OPENROUTER_API_KEY.trim());
  }
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.GEMINI_API_KEY.trim());
  }
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`OPENROUTER_API_KEY_${i}`];
    if (k && k.trim().length > 10 && !keys.includes(k.trim())) {
      keys.push(k.trim());
    }
  }
  if (process.env.OPENROUTER_API_KEYS) {
    const split = process.env.OPENROUTER_API_KEYS.split(',').map(k => k.trim()).filter(k => k.length > 10);
    for (const k of split) {
      if (!keys.includes(k)) keys.push(k);
    }
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    const k = process.env.OPENROUTER_API_KEY.trim();
    if (!keys.includes(k)) keys.push(k);
  }
  for (const k of DEFAULT_OPENROUTER_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

const DEFAULT_QWEN_OPENROUTER_KEYS = [
  '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',
  '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',
];

function getQwenOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_QWEN_API_KEY && process.env.OPENROUTER_QWEN_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_QWEN_API_KEY.trim());
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_API_KEY.trim());
  }
  if (process.env.QWEN_API_KEY && process.env.QWEN_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.QWEN_API_KEY.trim());
  }
  // Include default verified keys
  for (const k of DEFAULT_QWEN_OPENROUTER_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getQwenDashscopeKeys(): string[] {
  const keys: string[] = [];
  if (process.env.QWEN_API_KEY && process.env.QWEN_API_KEY.trim().length > 10 && !process.env.QWEN_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.QWEN_API_KEY.trim());
  }
  for (let i = 1; i <= 6; i++) {
    const key = process.env[`QWEN_API_KEY_${i}`];
    if (key && key.trim().length > 10 && !key.trim().startsWith('sk-or-')) {
      keys.push(key.trim());
    }
  }
  return keys;
}

function getQwenKeys(): string[] {
  return [...getQwenOpenRouterKeys(), ...getQwenDashscopeKeys()];
}

const DEFAULT_META_KEYS = [
  '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',
  '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',
];

function getMetaKeys(): string[] {
  const keys: string[] = [];
  if (process.env.META_API_KEY && process.env.META_API_KEY.trim().length > 10) {
    keys.push(process.env.META_API_KEY.trim());
  }
  if (process.env.OPENROUTER_META_API_KEY && process.env.OPENROUTER_META_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_META_API_KEY.trim());
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_API_KEY.trim());
  }
  if (process.env.META_LLAMA_API_KEY && process.env.META_LLAMA_API_KEY.trim().length > 10) {
    keys.push(process.env.META_LLAMA_API_KEY.trim());
  }
  for (const k of DEFAULT_META_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

const DEFAULT_GROK_KEYS = [
  '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',
  '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',
];

function getGrokOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_GROK_API_KEY && process.env.OPENROUTER_GROK_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_GROK_API_KEY.trim());
  }
  if (process.env.GROK_OPENROUTER_API_KEY && process.env.GROK_OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.GROK_OPENROUTER_API_KEY.trim());
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_API_KEY.trim());
  }
  if (process.env.GROK_API_KEY && process.env.GROK_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.GROK_API_KEY.trim());
  }
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`OPENROUTER_API_KEY_${i}`];
    if (k && k.trim().length > 10 && !keys.includes(k.trim())) {
      keys.push(k.trim());
    }
  }
  if (process.env.OPENROUTER_API_KEYS) {
    const split = process.env.OPENROUTER_API_KEYS.split(',').map(k => k.trim()).filter(k => k.length > 10);
    for (const k of split) {
      if (!keys.includes(k)) keys.push(k);
    }
  }
  for (const k of DEFAULT_GROK_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  for (const k of DEFAULT_OPENROUTER_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getGrokDirectKeys(): string[] {
  const keys: string[] = [];
  if (process.env.XAI_API_KEY && process.env.XAI_API_KEY.trim().length > 10) {
    keys.push(process.env.XAI_API_KEY.trim());
  }
  if (process.env.GROK_API_KEY && process.env.GROK_API_KEY.trim().length > 10 && !process.env.GROK_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.GROK_API_KEY.trim());
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getGrokKeys(): string[] {
  return [...getGrokOpenRouterKeys(), ...getGrokDirectKeys()];
}

const DEFAULT_KIMI_KEYS = [
  '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',
  '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',
];

function getKimiOpenRouterKeys(): string[] {
  const keys: string[] = [];
  if (process.env.OPENROUTER_KIMI_API_KEY && process.env.OPENROUTER_KIMI_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_KIMI_API_KEY.trim());
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.trim().length > 10) {
    keys.push(process.env.OPENROUTER_API_KEY.trim());
  }
  if (process.env.KIMI_API_KEY && process.env.KIMI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.KIMI_API_KEY.trim());
  }
  for (const k of DEFAULT_KIMI_KEYS) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getKimiDirectKeys(): string[] {
  const keys: string[] = [];
  if (process.env.MOONSHOT_API_KEY && process.env.MOONSHOT_API_KEY.trim().length > 10 && !process.env.MOONSHOT_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.MOONSHOT_API_KEY.trim());
  }
  if (process.env.KIMI_API_KEY && process.env.KIMI_API_KEY.trim().length > 10 && !process.env.KIMI_API_KEY.trim().startsWith('sk-or-')) {
    keys.push(process.env.KIMI_API_KEY.trim());
  }
  return keys.filter(k => typeof k === 'string' && k.trim().length > 10);
}

function getKimiKeys(): string[] {
  return [...getKimiOpenRouterKeys(), ...getKimiDirectKeys()];
}

// OCR.Space API Key for PDF and Image Text Extraction (K82320474988957)
const DEFAULT_OCR_SPACE_KEY = 'K82320474988957';
function getOcrSpaceApiKey(): string {
  return process.env.OCR_SPACE_API_KEY?.trim() || DEFAULT_OCR_SPACE_KEY;
}

let activeKeyIndex = 0;
let activeOpenRouterKeyIndex = 0;
let activeGroqKeyIndex = 0;
let activeNovitaKeyIndex = 0;
let activeSambaKeyIndex = 0;
let activeMistralKeyIndex = 0;
let activeGeminiKeyIndex = 0;
let activeQwenKeyIndex = 0;
let activeMetaKeyIndex = 0;
let activeGrokKeyIndex = 0;
let activeKimiKeyIndex = 0;

let activeOpenAiKeyIndex = 0;

interface AiChatParams {
  messages: Array<{ role: string; content: string }>;
  systemPrompt?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  responseJson?: boolean;
  preferredModel?: 'gemini' | 'google/gemini-pro-latest' | 'google/gemini-3.7-flash' | 'google/gemini-3.1-flash-lite' | 'gemini-pro-latest' | 'gemini-3.7-flash' | 'gemini-3.1-flash-lite' | 'nvidia' | 'nvidia-fast' | 'nvidia-best' | 'nvidia-ultra' | 'openrouter' | 'deepseek' | 'deepseek-v4-flash-latest' | 'deepseek-r1' | 'deepseek-v4-pro' | 'chatgpt' | 'openai/gpt-mini-latest' | 'openai/gpt-latest' | 'gpt-mini-latest' | 'gpt-latest' | 'grok' | 'grok-4.5' | 'grok-4.1-fast' | 'claude' | 'claude-3-opus' | 'claude-opus' | 'claude-haiku' | 'claude-3-5-haiku' | 'command-r-plus' | 'command-r' | 'cohere' | 'phi-4' | 'phi' | 'microsoft-phi-4' | 'mistral' | 'mistral-large' | 'qwen' | 'meta' | 'kimi' | 'zai' | 'amazon/nova-2-lite-v1:free' | 'amazon/nova-lite-v1' | 'amazon-nova-lite' | 'amazon-nova' | 'nova-lite' | 'amazon' | 'nova' | 'minimax/minimax-m3' | 'minimax/minimax-m2.5' | 'minimax/minimax-m2.7:free' | 'minimax' | 'minimax-m3' | 'minimax-m2.5' | 'minimax-m2.7' | 'mimo-v2.5' | 'mimo-v2.5-pro' | 'xiaomi' | 'mimo' | 'gpt-oss-120b' | 'heavy' | 'hyper' | 'auto' | 'perplexity' | 'sonar-reasoning-pro' | 'sonar-pro' | 'sonar-reasoning' | 'search';
}

/**
 * Robust JSON Parser for AI LaTeX output.
 * Handles unescaped LaTeX backslashes (\alpha, \textbf), unescaped newlines, and markdown blocks.
 */
function parseAiJsonResponse(text: string): any {
  if (!text) return {};
  
  // Clean markdown fences
  let clean = text.trim();
  if (clean.startsWith('```json')) {
    clean = clean.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
  } else if (clean.startsWith('```')) {
    clean = clean.replace(/^```\w*\s*/i, '').replace(/```\s*$/, '').trim();
  }

  // 1. Direct JSON parse
  try {
    return JSON.parse(clean);
  } catch (err1) {
    // 2. Fix unescaped backslashes commonly emitted in raw LaTeX inside JSON strings
    try {
      // Find JSON string literals and safely escape unescaped backslashes
      const sanitized = clean.replace(/"((?:\\.|[^"\\])*)"/gs, (match) => {
        return match.replace(/\\(?!["\\/bfnrtu])/g, '\\\\');
      });
      return JSON.parse(sanitized);
    } catch (err2) {
      // 3. Fallback extraction via regex
      const replyMatch = clean.match(/"reply"\s*:\s*"((?:\\.|[^"\\])*)"/s);
      const latexMatch = clean.match(/"(?:updatedLatex|fixedLatex)"\s*:\s*"((?:\\.|[^"\\])*)"/s);
      const actionMatch = clean.match(/"actionTaken"\s*:\s*"([^"]*)"/);

      if (replyMatch || latexMatch) {
        return {
          reply: replyMatch ? replyMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"') : 'Executed command.',
          updatedLatex: latexMatch ? latexMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\') : null,
          fixedLatex: latexMatch ? latexMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\') : null,
          actionTaken: actionMatch ? actionMatch[1] : 'Updated LaTeX',
        };
      }

      // If everything failed, treat entire text as raw latex or reply
      if (clean.includes('\\documentclass') || clean.includes('\\begin{')) {
        return { reply: 'LaTeX document updated.', updatedLatex: clean, fixedLatex: clean };
      }

      return { reply: clean, updatedLatex: null };
    }
  }
}

export interface SearchSourceItem {
  title: string;
  url: string;
  domain: string;
  siteName: string;
  iconUrl: string;
  snippet?: string;
}

export interface SearchImageItem {
  url: string;
  title: string;
  sourceUrl: string;
  sourceName: string;
}

function extractDomainAndSiteName(rawUrl: string): { domain: string; siteName: string; iconUrl: string } {
  let domain = '';
  try {
    const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
    domain = parsed.hostname.replace(/^www\./, '');
  } catch {
    domain = rawUrl.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  }

  const KNOWN_SITES: Record<string, string> = {
    'outlookindia.com': 'Outlook India',
    'financialexpress.com': 'The Financial Express',
    'ndtv.com': 'NDTV',
    'hindustantimes.com': 'Hindustan Times',
    'news.google.com': 'Google News',
    'newsbytesapp.com': 'NewsBytes',
    'reuters.com': 'Reuters',
    '7news.com.au': '7NEWS',
    'wikipedia.org': 'Wikipedia',
    'en.wikipedia.org': 'Wikipedia',
    'bbc.com': 'BBC News',
    'bbc.co.uk': 'BBC News',
    'indiatoday.in': 'India Today',
    'thehindu.com': 'The Hindu',
    'timesofindia.indiatimes.com': 'The Times of India',
    'aljazeera.com': 'Al Jazeera',
    'cnn.com': 'CNN',
    'theguardian.com': 'The Guardian',
    'techcrunch.com': 'TechCrunch',
    'theverge.com': 'The Verge',
    'bloomberg.com': 'Bloomberg',
    'forbes.com': 'Forbes',
    'nytimes.com': 'The New York Times',
    'wsj.com': 'The Wall Street Journal',
    'washingtonpost.com': 'The Washington Post',
    'moneycontrol.com': 'Moneycontrol',
    'economictimes.indiatimes.com': 'The Economic Times',
    'livemint.com': 'Mint',
    'youtube.com': 'YouTube',
    'x.com': 'X',
    'twitter.com': 'Twitter',
    'github.com': 'GitHub',
    'reddit.com': 'Reddit',
    'imdb.com': 'IMDb',
    'espncricinfo.com': 'ESPNcricinfo',
    'cricbuzz.com': 'Cricbuzz'
  };

  let siteName = KNOWN_SITES[domain.toLowerCase()];
  if (!siteName) {
    const parts = domain.split('.');
    const mainName = parts.length > 1 ? parts[parts.length - 2] : parts[0];
    siteName = mainName.charAt(0).toUpperCase() + mainName.slice(1);
  }

  const iconUrl = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=64`;

  return { domain, siteName, iconUrl };
}

/**
 * Super-fast Gemini API caller with valid models, Google Search Grounding support, and retry on temporary high-demand (503/429)
 */
async function callGeminiWithKey(
  params: AiChatParams, 
  apiKey: string,
  options?: { enableSearchGrounding?: boolean }
): Promise<{ text: string; citations?: string[]; sources?: SearchSourceItem[] }> {
  const ai = new GoogleGenAI({ apiKey });

  // Map messages to Gemini format
  const contents = params.messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));

  // Allowed official models per Google GenAI SDK
  let geminiModels = [
    'gemini-3.1-flash-lite',
    'gemini-3.7-flash',
    'gemini-flash-latest',
    'gemini-pro-latest',
    'gemini-3.1-pro-preview'
  ];

  if (params.preferredModel === 'google/gemini-pro-latest' || params.preferredModel === 'gemini-pro-latest') {
    geminiModels = ['gemini-pro-latest', 'gemini-3.1-pro-preview', 'gemini-3.1-flash-lite', 'gemini-3.7-flash', 'gemini-flash-latest'];
  } else if (params.preferredModel === 'google/gemini-3.7-flash' || params.preferredModel === 'gemini-3.7-flash') {
    geminiModels = ['gemini-3.7-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
  } else if (params.preferredModel === 'google/gemini-3.1-flash-lite' || params.preferredModel === 'gemini-3.1-flash-lite') {
    geminiModels = ['gemini-3.1-flash-lite', 'gemini-3.7-flash', 'gemini-flash-latest'];
  }
  
  let lastErr: any = null;

  for (const modelName of geminiModels) {
    try {
      const config: any = {
        systemInstruction: params.systemPrompt,
        temperature: params.temperature ?? 0.7,
        maxOutputTokens: params.maxTokens ?? 8192,
        ...(params.responseJson ? { responseMimeType: 'application/json' } : {})
      };

      if (options?.enableSearchGrounding) {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model: modelName,
        contents,
        config
      });

      if (response.text && response.text.trim()) {
        const citations: string[] = [];
        const sources: SearchSourceItem[] = [];
        try {
          const groundingMetadata = (response.candidates?.[0] as any)?.groundingMetadata;
          if (groundingMetadata?.groundingChunks) {
            for (const chunk of groundingMetadata.groundingChunks) {
              if (chunk.web?.title && chunk.web?.uri) {
                const uri = chunk.web.uri;
                const { domain, siteName, iconUrl } = extractDomainAndSiteName(uri);
                citations.push(siteName);
                sources.push({
                  title: chunk.web.title,
                  url: uri,
                  domain,
                  siteName,
                  iconUrl
                });
              }
            }
          }
        } catch (citeErr) {
          // Ignore metadata parse error
        }

        return { text: response.text, citations, sources };
      }
    } catch (err: any) {
      lastErr = err;
      const msg = (err.message || '').toLowerCase();

      // If invalid API key, skip immediately to next key
      if (msg.includes('api_key_invalid') || msg.includes('unregistered') || msg.includes('api key not valid')) {
        throw err;
      }

      // If 429 quota or 404 model not found, try the next model on this key (e.g. gemini-3.1-flash-lite)
      continue;
    }
  }

  throw lastErr || new Error('Gemini API call failed across available model tiers.');
}

/**
 * Pentagon Heavy: Mixture-of-Agents (MoA) Multi-Model Parallel Synthesis Engine.
 * Queries Gemini, NVIDIA, DeepSeek, ChatGPT, Grok/Novita, and Claude in parallel,
 * extracts all candidate responses, and performs a master consensus synthesis.
 */
async function synthesizeHeavyResponse(params: AiChatParams): Promise<{ text: string; provider: string; citations?: string[] }> {
  console.log('[Pentagon Heavy] Launching multi-model parallel extraction...');

  // Query all distinct core frontier models simultaneously
  const modelEngines: Array<{ id: 'gemini' | 'nvidia' | 'openrouter' | 'deepseek' | 'chatgpt' | 'grok' | 'claude' | 'claude-haiku' | 'command-r-plus' | 'phi-4' | 'zai' | 'gpt-oss-120b'; name: string }> = [
    { id: 'gemini', name: 'Gemini 3.7' },
    { id: 'nvidia', name: 'NVIDIA NIM' },
    { id: 'openrouter', name: 'DeepSeek' },
    { id: 'chatgpt', name: 'ChatGPT-4o' },
    { id: 'grok', name: 'Grok 3' },
    { id: 'claude', name: 'Claude 3.5 Sonnet' },
    { id: 'claude-haiku', name: 'Claude 3.5 Haiku' },
    { id: 'command-r-plus', name: 'Cohere Command R+' },
    { id: 'phi-4', name: 'Microsoft Phi-4' },
    { id: 'zai', name: 'Z.AI GLM-5.2' },
    { id: 'gpt-oss-120b', name: 'GPT OSS 120B' }
  ];

  const results = await Promise.allSettled(
    modelEngines.map(async (engine) => {
      const res = await callAiWithAutoFailover({
        ...params,
        preferredModel: engine.id,
      });
      return { engine: engine.name, text: res.text };
    })
  );

  const successfulCandidates: Array<{ engine: string; text: string }> = [];
  for (const r of results) {
    if (r.status === 'fulfilled' && r.value && r.value.text && r.value.text.trim()) {
      successfulCandidates.push(r.value);
    }
  }

  console.log(`[Pentagon Heavy] Successfully collected ${successfulCandidates.length} candidate answers.`);

  // If no models responded, fallback to standard auto failover
  if (successfulCandidates.length === 0) {
    const fallback = await callAiWithAutoFailover({ ...params, preferredModel: 'auto' });
    return { text: fallback.text, provider: `Pentagon Heavy (via Auto: ${fallback.provider})` };
  }

  // If only 1 model responded, return it directly
  if (successfulCandidates.length === 1) {
    return {
      text: successfulCandidates[0].text,
      provider: `Pentagon Heavy (via ${successfulCandidates[0].engine})`
    };
  }

  // Now synthesize the best multi-model consensus
  const candidateTexts = successfulCandidates
    .map((c, i) => `### Candidate Answer ${i + 1} [From ${c.engine}]:\n${c.text.trim()}`)
    .join('\n\n---\n\n');

  const synthesisPrompt = `You are Pentagon Heavy, the supreme multi-model consensus synthesizer inside the Pentagon platform created by Mr. Hilal Farooq Badhana.
We have queried ${successfulCandidates.length} frontier AI models simultaneously (${successfulCandidates.map(c => c.engine).join(', ')}).

Below are the drafted responses from each AI model:

${candidateTexts}

YOUR MASTER TASK:
1. Thoroughly compare, verify, and cross-check all candidate answers.
2. Filter out any factual mistakes, hallucinations, or incomplete points found in individual drafts.
3. Merge the highest quality explanations, strongest reasoning, most accurate LaTeX math formulas, and cleanest code blocks into one cohesive, comprehensive MASTERPIECE response.
4. Maintain the user's native requested language (English, Urdu, Roman Urdu, etc.) perfectly.
5. Deliver a seamless, polished, beautifully structured response without referring to "Candidate 1 said this" or "Candidate 2 said that" — speak directly as Pentagon Heavy with supreme authority and clarity.`;

  const synthesisParams: AiChatParams = {
    messages: [
      ...params.messages.slice(0, -1),
      {
        role: 'user',
        content: `Synthesize the absolute best master response from the candidate answers above for: "${params.messages[params.messages.length - 1]?.content || ''}"`
      }
    ],
    systemPrompt: synthesisPrompt,
    temperature: 0.3,
    maxTokens: 4096,
  };

  try {
    // Try Gemini as Master Synthesizer
    const synthResult = await callAiWithAutoFailover({
      ...synthesisParams,
      preferredModel: 'gemini'
    });
    return {
      text: synthResult.text,
      provider: `Pentagon Heavy (${successfulCandidates.length} Models Synthesized: ${successfulCandidates.map(c => c.engine).join(', ')})`
    };
  } catch (err) {
    // Fallback to NVIDIA NIM as Master Synthesizer
    try {
      const synthResult = await callAiWithAutoFailover({
        ...synthesisParams,
        preferredModel: 'nvidia'
      });
      return {
        text: synthResult.text,
        provider: `Pentagon Heavy (${successfulCandidates.length} Models Synthesized: ${successfulCandidates.map(c => c.engine).join(', ')})`
      };
    } catch (err2) {
      // If synthesis engine fails, return the longest and most detailed candidate answer
      const bestCandidate = successfulCandidates.reduce((prev, curr) => curr.text.length > prev.text.length ? curr : prev, successfulCandidates[0]);
      return {
        text: bestCandidate.text,
        provider: `Pentagon Heavy (Consensus Leader: ${bestCandidate.engine})`
      };
    }
  }
}


/**
 * Pentagon Hyper: Ultimate Mixture-of-Agents (MoA) Multi-Model Parallel Synthesis Engine.
 * Queries ALL available AI providers/models in parallel.
 * No time limit—waits for all.
 */
async function synthesizeHyperResponse(params: AiChatParams): Promise<{ text: string; provider: string; citations?: string[] }> {
  console.log('[Pentagon Hyper] Launching exhaustive multi-model parallel extraction across ALL providers...');

  // Query every single distinct provider/engine configuration available
  const allEngines: Array<{ id: any; name: string }> = [
    { id: 'google/gemini-pro-latest', name: 'Google Gemini Pro' },
    { id: 'google/gemini-3.7-flash', name: 'Google Gemini 3.7 Flash' },
    { id: 'gemini', name: 'Gemini 3.7' },
    { id: 'nvidia', name: 'NVIDIA NIM' },
    { id: 'nvidia-fast', name: 'NVIDIA Lightning' },
    { id: 'nvidia-best', name: 'NVIDIA Nemotron 340B' },
    { id: 'nvidia-ultra', name: 'NVIDIA Nemotron Ultra 550B' },
    { id: 'deepseek-v4-flash-latest', name: 'DeepSeek V4 Flash' },
    { id: 'deepseek-r1', name: 'DeepSeek R1' },
    { id: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro' },
    { id: 'openrouter', name: 'OpenRouter DeepSeek' },
    { id: 'deepseek', name: 'DeepSeek Direct' },
    { id: 'chatgpt', name: 'Groq Llama 3.3' },
    { id: 'openai/gpt-mini-latest', name: 'OpenAI GPT Mini Latest' },
    { id: 'openai/gpt-latest', name: 'OpenAI GPT Latest' },
    { id: 'grok-4.5', name: 'xAI Grok 4.5' },
    { id: 'grok-4.1-fast', name: 'xAI Grok 4.1 Fast' },
    { id: 'grok', name: 'xAI Grok' },
    { id: 'claude', name: 'Claude 3.5 Sonnet' },
    { id: 'claude-3-opus', name: 'Anthropic Claude 3 Opus' },
    { id: 'claude-haiku', name: 'Anthropic Claude Haiku 4.5' },
    { id: 'command-r-plus', name: 'Cohere Command R+' },
    { id: 'phi-4', name: 'Microsoft Phi-4' },
    { id: 'mistral', name: 'Mistral' },
    { id: 'mistral-large', name: 'Mistral Large' },
    { id: 'qwen', name: 'Qwen 2.5' },
    { id: 'meta', name: 'Meta Llama 405B' },
    { id: 'kimi', name: 'Moonshot Kimi' },
    { id: 'zai', name: 'Z.AI GLM-5.2' },
    { id: 'gpt-oss-120b', name: 'GPT OSS 120B' },
    { id: 'sonar-reasoning-pro', name: 'Sonar Reasoning Pro' },
    { id: 'perplexity', name: 'Perplexity Sonar' }
  ];

  const results = await Promise.allSettled(
    allEngines.map(async (engine) => {
      // Create a cloned params without timeout restrictions if possible, or just standard params
      const res = await callAiWithAutoFailover({
        ...params,
        preferredModel: engine.id,
      });
      return { engine: engine.name, text: res.text };
    })
  );

  const successfulCandidates: Array<{ engine: string; text: string }> = [];
  for (const r of results) {
    if (r.status === 'fulfilled' && r.value && r.value.text && r.value.text.trim()) {
      successfulCandidates.push(r.value);
    }
  }

  console.log(`[Pentagon Hyper] Successfully collected ${successfulCandidates.length} candidate answers out of ${allEngines.length}.`);

  if (successfulCandidates.length === 0) {
    const fallback = await callAiWithAutoFailover({ ...params, preferredModel: 'auto' });
    return { text: fallback.text, provider: `Pentagon Hyper (via Auto: ${fallback.provider})` };
  }

  if (successfulCandidates.length === 1) {
    return {
      text: successfulCandidates[0].text,
      provider: `Pentagon Hyper (Only ${successfulCandidates[0].engine} responded)`
    };
  }

  const synthesisPrompt = `You are Pentagon Hyper, the ultimate multi-model consensus synthesizer created by Mr. Hilal Farooq Badhana.
Your task is to analyze responses from ALL available top-tier AI models (${successfulCandidates.length} models responded) to the user's prompt.
Compare all answers, detect any errors, combine the strongest reasoning, and produce ONE definitive, best final answer.
Do not skip any crucial details. Provide the absolute most accurate and comprehensive response possible.

Here are the candidate responses:

${successfulCandidates.map((c, i) => `### Candidate ${i + 1} (${c.engine}) ###\n${c.text}\n`).join('\n')}

INSTRUCTIONS FOR SYNTHESIS:
1. Identify the most factually accurate and logically sound arguments across all candidates.
2. Merge the best insights into a single cohesive response.
3. Eliminate hallucinations, contradictions, or weak reasoning found in any individual candidate.
4. If it's a creative task or coding task, combine the best elements (e.g., most efficient code, best creative flair).
5. Deliver a seamless, polished, beautifully structured response WITHOUT referring to "Candidate 1 said this" or "Candidate 2 said that". Speak directly as Pentagon Hyper with supreme authority and clarity.`;

  const synthesisParams: AiChatParams = {
    messages: [
      { 
        role: 'user', 
        content: `Please synthesize the ultimate master response from the ${successfulCandidates.length} candidate answers above for: "${params.messages[params.messages.length - 1]?.content || ''}"`
      }
    ],
    systemPrompt: synthesisPrompt,
    temperature: 0.2, // Slightly lower for high precision synthesis
    maxTokens: 8192, // Max possible length
  };

  try {
    const synthResult = await callAiWithAutoFailover({
      ...synthesisParams,
      preferredModel: 'gemini'
    });
    return {
      text: synthResult.text,
      provider: `Pentagon Hyper (Synthesized from ${successfulCandidates.length} models: ${successfulCandidates.map(c => c.engine).join(', ')})`
    };
  } catch (err) {
    try {
      const synthResult = await callAiWithAutoFailover({
        ...synthesisParams,
        preferredModel: 'nvidia'
      });
      return {
        text: synthResult.text,
        provider: `Pentagon Hyper (Synthesized from ${successfulCandidates.length} models: ${successfulCandidates.map(c => c.engine).join(', ')})`
      };
    } catch (err2) {
      try {
        const synthResult = await callAiWithAutoFailover({
          ...synthesisParams,
          preferredModel: 'openrouter'
        });
        return {
          text: synthResult.text,
          provider: `Pentagon Hyper (Synthesized from ${successfulCandidates.length} models: ${successfulCandidates.map(c => c.engine).join(', ')})`
        };
      } catch (err3) {
        const bestCandidate = successfulCandidates.reduce((prev, curr) => curr.text.length > prev.text.length ? curr : prev, successfulCandidates[0]);
        return {
          text: bestCandidate.text,
          provider: `Pentagon Hyper (Consensus Leader: ${bestCandidate.engine})`
        };
      }
    }
  }
}


/**
 * Unified AI Engine: Primary Gemini (Fast & Instant) + 7 NVIDIA NIM Keys Auto-Failover Pool.
 * If Gemini has quota/exhausts -> Instantly failover to 7 NVIDIA keys.
 * If NVIDIA keys are exhausted -> Falls back cleanly.
 */

function truncateMessages(messages: Array<{ role: string; content: string }>, maxChars = 20000): Array<{ role: string; content: string }> {
  // Strip huge base64 attachments from content to prevent "Request Entity Too Large" errors (413)
  const cleanedMessages = messages.map(m => ({
    role: m.role,
    content: (m.content || '').replace(/data:[a-zA-Z0-9+\/.\-]+(?:;[a-zA-Z0-9+=\-]+)*;base64,[a-zA-Z0-9+/=]+/g, '[BASE64_ATTACHMENT_REMOVED]')
  }));

  let currentChars = 0;
  let sysMsg = cleanedMessages.find(m => m.role === 'system');
  if (sysMsg) {
    if (sysMsg.content.length > maxChars / 2) {
      sysMsg = { role: 'system', content: sysMsg.content.substring(0, Math.floor(maxChars / 2)) };
    }
    currentChars += sysMsg.content.length;
  }
  
  const others = cleanedMessages.filter(m => m.role !== 'system');
  const keptOthers = [];
  for (let i = others.length - 1; i >= 0; i--) {
    let msgContent = others[i].content;
    if (currentChars + msgContent.length > maxChars) {
      if (keptOthers.length === 0) {
        // Keep at least the latest user message, but safely truncated to fit remaining space
        const allowed = Math.max(1000, maxChars - currentChars);
        msgContent = msgContent.substring(msgContent.length - allowed);
      } else {
        break;
      }
    }
    keptOthers.unshift({ role: others[i].role, content: msgContent });
    currentChars += msgContent.length;
    if (currentChars >= maxChars) break;
  }
  return sysMsg ? [sysMsg, ...keptOthers] : keptOthers;
}

export interface ExtendedAiChatParams extends AiChatParams { searchMode?: boolean; }
async function callAiWithAutoFailover(params: ExtendedAiChatParams): Promise<{ text: string; provider: string; citations?: string[]; sources?: SearchSourceItem[] }> {
  // Sanitize messages to avoid empty content API errors
  params.messages = params.messages.filter(m => m.content && m.content.trim().length > 0);
  const pref = params.preferredModel || 'auto';
  let lastError: any = null;

  // 0. Pentagon Heavy Multi-Model Consensus Engine
  if (pref === 'heavy') {
    return await synthesizeHeavyResponse(params);
  }
  if (pref === 'hyper') {
    return await synthesizeHyperResponse(params);
  }

  // 0.5 Google Live Search Grounding Mode (Native Google Search via Gemini Grounding API)
  if (pref === 'search') {
    const geminiKeys = getGeminiKeys();
    if (geminiKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < geminiKeys.length; keyAttempt++) {
        const currentIndex = (activeGeminiKeyIndex + keyAttempt) % geminiKeys.length;
        const currentApiKey = geminiKeys[currentIndex];
        
        try {
          const result = await callGeminiWithKey(params, currentApiKey, { enableSearchGrounding: true });
          if (result.text && result.text.trim()) {
            activeGeminiKeyIndex = currentIndex;
            return { 
              text: result.text, 
              provider: `Google Real-Time Live Search (Gemini Grounding Key #${currentIndex + 1})`,
              citations: result.citations,
              sources: result.sources
            };
          }
        } catch (geminiError: any) {
          lastError = geminiError;
        }
      }
    }
  }

  // 1. Primary: Gemini Pool (Direct Google GenAI + OpenRouter Gemini Pool)
  if (pref === 'auto' || pref === 'gemini' || pref === 'search' || pref === 'google/gemini-pro-latest' || pref === 'google/gemini-3.7-flash' || pref === 'google/gemini-3.1-flash-lite' || pref === 'gemini-pro-latest' || pref === 'gemini-3.7-flash' || pref === 'gemini-3.1-flash-lite') {
    const geminiKeys = getGeminiKeys();
    const openRouterKeys = getGeminiOpenRouterKeys();
    const enableGoogleSearch = (pref === 'search' || params.searchMode === true);

    // 1.1 Try Direct Google GenAI API first
    if (geminiKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < geminiKeys.length; keyAttempt++) {
        const currentIndex = (activeGeminiKeyIndex + keyAttempt) % geminiKeys.length;
        const currentApiKey = geminiKeys[currentIndex];
        
        try {
          const result = await callGeminiWithKey(params, currentApiKey, { enableSearchGrounding: enableGoogleSearch });
          if (result.text && result.text.trim()) {
            activeGeminiKeyIndex = currentIndex;
            const modelLabel = (pref === 'google/gemini-pro-latest' || pref === 'gemini-pro-latest')
              ? 'Google Gemini Pro Latest'
              : (pref === 'google/gemini-3.1-flash-lite' || pref === 'gemini-3.1-flash-lite')
              ? 'Google Gemini 3.1 Flash Lite'
              : (pref === 'google/gemini-3.7-flash' || pref === 'gemini-3.7-flash')
              ? 'Gemini 3.7 Flash ⚡'
              : (pref === 'search' ? 'Google Search Engine' : 'Gemini 3.7 Flash ⚡');
            return { 
              text: result.text, 
              provider: `${modelLabel} (Key #${currentIndex + 1})`,
              citations: result.citations,
              sources: result.sources
            };
          }
        } catch (geminiError: any) {
          lastError = geminiError;
        }
      }
    }

    // 1.2 Try OpenRouter Gemini Pool
    if (openRouterKeys.length > 0) {
      const orModels = (pref === 'google/gemini-pro-latest' || pref === 'gemini-pro-latest')
        ? [
            'google/gemini-pro-latest',
            'google/gemini-2.0-pro-exp-02-05:free',
            'google/gemini-3.7-flash',
            'google/gemini-2.5-flash',
            'google/gemini-2.0-flash-001'
          ]
        : (pref === 'google/gemini-3.1-flash-lite' || pref === 'gemini-3.1-flash-lite')
        ? [
            'google/gemini-3.1-flash-lite',
            'google/gemini-2.5-flash',
            'google/gemini-3.7-flash',
            'google/gemini-2.0-flash-001'
          ]
        : [
            'google/gemini-3.7-flash',
            'google/gemini-pro-latest',
            'google/gemini-2.5-flash',
            'google/gemini-2.0-pro-exp-02-05:free',
            'google/gemini-2.0-flash-001'
          ];

      for (let keyAttempt = 0; keyAttempt < openRouterKeys.length; keyAttempt++) {
        const currentIndex = (activeGeminiKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        for (const currentModel of orModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(18000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(params.messages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeGeminiKeyIndex = currentIndex;
                const label = currentModel.includes('pro')
                  ? 'Google Gemini Pro Latest'
                  : currentModel.includes('3.1-flash-lite')
                  ? 'Google Gemini 3.1 Flash Lite'
                  : currentModel.includes('3.7')
                  ? 'Google Gemini 3.7 Flash'
                  : currentModel;
                return { text: content, provider: `${label} (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) {
              break;
            }
            if (status === 404 || status === 429 || status === 503 || status === 400 || status === 413) {
              continue;
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }
      
    console.log('[Gemini Pool Exhausted - Auto-switching to next Engine Pool]');
    if (pref === 'gemini' || pref === 'google/gemini-pro-latest' || pref === 'google/gemini-3.7-flash' || pref === 'google/gemini-3.1-flash-lite' || pref === 'gemini-pro-latest' || pref === 'gemini-3.7-flash' || pref === 'gemini-3.1-flash-lite') {
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        return { text: nvFallback.text, provider: `Gemini (via Failover: ${nvFallback.provider})` };
      } catch (e) {
        try {
          const groqFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'chatgpt' });
          return { text: groqFallback.text, provider: `Gemini (via Failover: ${groqFallback.provider})` };
        } catch (e2) {
          throw lastError || new Error('All Gemini API Keys exhausted.');
        }
      }
    }
  }

  // 2. NVIDIA NIM 7-Keys Failover Pool with fast timeout
  if (pref === 'auto' || pref === 'nvidia' || pref === 'nvidia-fast' || pref === 'nvidia-best' || pref === 'nvidia-ultra') {
    const keys = getNvidiaKeys();
  
  let fastModels = [
    'meta/llama-3.2-11b-vision-instruct',
    'meta/llama-3.2-90b-vision-instruct',
    'ibm/granite-3.0-8b-instruct',
    '01-ai/yi-large',
    'meta/llama2-70b'
  ];

  if (pref === 'nvidia-fast') {
    fastModels = [
      'nvidia/llama-3.1-nemotron-70b-instruct',
      'meta/llama-3.1-8b-instruct',
      'ibm/granite-3.0-8b-instruct'
    ];
  } else if (pref === 'nvidia-ultra') {
    fastModels = [
      'nvidia/nemotron-4-340b-instruct',
      'meta/llama-3.1-405b-instruct'
    ];
  } else if (pref === 'nvidia-best') {
    fastModels = [
      'nvidia/llama-3.1-nemotron-70b-instruct',
      'meta/llama-3.1-70b-instruct',
      'meta/llama-3.2-90b-vision-instruct'
    ];
  }

  const fullMessages: Array<{ role: string; content: string }> = [];
  if (params.systemPrompt) {
    fullMessages.push({ role: 'system', content: params.systemPrompt });
  }
  fullMessages.push(...params.messages);

  for (let keyAttempt = 0; keyAttempt < keys.length; keyAttempt++) {
    const currentIndex = (activeKeyIndex + keyAttempt) % keys.length;
    const currentApiKey = keys[currentIndex];

    for (const currentModel of fastModels) {
      try {
        const response = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
          method: 'POST',
          signal: AbortSignal.timeout(8000), // 8s timeout per NVIDIA model attempt
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${currentApiKey}`,
          },
          body: JSON.stringify({
            model: currentModel,
            messages: truncateMessages(fullMessages, 14000),
            temperature: params.temperature ?? 0.2,
            top_p: 0.7,
            ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
          }),
        });

        if (response.ok) {
          const data = await response.json();
          const content = data.choices?.[0]?.message?.content || '';
          if (content.trim()) {
            activeKeyIndex = currentIndex;
            return { text: content, provider: `NVIDIA NIM (${currentModel.split('/')[1] || currentModel})` };
          }
        }

        const status = response.status;
        const errText = await response.text();
        
        let msg = errText;
        try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
        lastError = new Error(`NVIDIA Key #${currentIndex + 1} Error: ${msg}`);

        if (status === 401 || status === 402 || status === 403) {
          break; // Key-level error, stop trying models for this key
        }
        if (status === 429 || status === 503 || status === 400 || status === 404 || status === 410) {
          continue; // Try the next model on the same key
        }
      } catch (err: any) {
        lastError = err;
        continue;
      }
    }
    
    if (lastError && lastError.message && lastError.message.toLowerCase().includes('timeout')) {
      break; 
    }
  }

  if (pref === 'nvidia' || pref === 'nvidia-fast' || pref === 'nvidia-best' || pref === 'nvidia-ultra') {
    try {
      const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: gemFallback.text, provider: `NVIDIA (via Fast Failover: ${gemFallback.provider})` };
    } catch (e) {
      // continue
    }
  }
  } // <-- closing `if (pref === 'auto' || pref === 'nvidia') {`

  // 3. DeepSeek & OpenRouter Pool (deepseek-v4-flash-latest, deepseek-r1, deepseek-v4-pro, deepseek-chat)
  if (pref === 'auto' || pref === 'openrouter' || pref === 'deepseek' || pref === 'deepseek-v4-flash-latest' || pref === 'deepseek-r1' || pref === 'deepseek-v4-pro') {
    const directKeys = getDeepSeekDirectKeys();
    const openRouterKeys = getOpenRouterKeys();

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 3.1 Try Direct DeepSeek API first if configured
    if (directKeys.length > 0) {
      const dsModels = pref === 'deepseek-r1'
        ? ['deepseek-reasoner', 'deepseek-chat']
        : ['deepseek-chat', 'deepseek-reasoner'];
      for (const dKey of directKeys) {
        for (const mId of dsModels) {
          try {
            const response = await fetch('https://api.deepseek.com/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(20000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${dKey.trim()}`,
              },
              body: JSON.stringify({
                model: mId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                const label = mId === 'deepseek-reasoner' ? 'DeepSeek R1 (Direct)' : `DeepSeek (${mId})`;
                return { text: content, provider: label };
              }
            }
          } catch (e) {
            continue;
          }
        }
      }
    }

    // 3.2 Try OpenRouter Pool with target models (deepseek/deepseek-v4-flash-latest, deepseek/deepseek-r1, deepseek/deepseek-v4-pro)
    if (openRouterKeys.length > 0) {
      const orModels = pref === 'deepseek-v4-flash-latest'
        ? [
            'deepseek/deepseek-v4-flash-latest',
            'deepseek/deepseek-v4-flash',
            'deepseek/deepseek-chat',
            'deepseek/deepseek-r1',
            'deepseek/deepseek-v4-pro'
          ]
        : pref === 'deepseek-r1'
        ? [
            'deepseek/deepseek-r1',
            'deepseek/deepseek-r1:free',
            'deepseek/deepseek-v4-pro',
            'deepseek/deepseek-v4-flash-latest',
            'deepseek/deepseek-chat'
          ]
        : pref === 'deepseek-v4-pro'
        ? [
            'deepseek/deepseek-v4-pro',
            'deepseek/deepseek-v4',
            'deepseek/deepseek-r1',
            'deepseek/deepseek-v4-flash-latest',
            'deepseek/deepseek-chat'
          ]
        : [
            'deepseek/deepseek-v4-flash-latest',
            'deepseek/deepseek-r1',
            'deepseek/deepseek-v4-pro',
            'deepseek/deepseek-chat',
            'google/gemini-2.0-pro-exp-02-05:free',
            'openai/gpt-4o',
            'meta-llama/llama-3.3-70b-instruct'
          ];

      for (let keyAttempt = 0; keyAttempt < openRouterKeys.length; keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of orModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(20000), // 20s timeout for deep reasoning models
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenRouterKeyIndex = currentIndex;
                const label = currentModel.includes('v4-flash')
                  ? 'DeepSeek V4 Flash'
                  : currentModel.includes('r1')
                  ? 'DeepSeek R1'
                  : currentModel.includes('v4-pro') || currentModel.includes('v4')
                  ? 'DeepSeek V4 Pro'
                  : (currentModel.includes('deepseek') ? 'DeepSeek' : currentModel);
                return { text: content, provider: `${label} (OpenRouter)` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`OpenRouter Key #${currentIndex + 1} Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break; // Key credit or auth issue, proceed directly to next key
            }
            if (status === 429 || status === 503 || status === 400 || status === 404) {
              continue; // Try next model on this key
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    if (pref === 'openrouter' || pref === 'deepseek' || pref === 'deepseek-v4-flash-latest' || pref === 'deepseek-r1' || pref === 'deepseek-v4-pro') {
      console.log('[DeepSeek / OpenRouter Pool Exhausted - Auto-switching to high-speed failover engines]');
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        return { text: nvFallback.text, provider: `DeepSeek (via NVIDIA: ${nvFallback.provider})` };
      } catch (e) {
        try {
          const groqFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'chatgpt' });
          return { text: groqFallback.text, provider: `DeepSeek (via ${groqFallback.provider})` };
        } catch (e2) {
          try {
            const geminiFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
            return { text: geminiFallback.text, provider: `DeepSeek (via ${geminiFallback.provider})` };
          } catch (e3) {
            throw lastError || new Error('All DeepSeek API Keys exhausted.');
          }
        }
      }
    }
  } // <-- closing `if (pref === 'auto' || pref === 'openrouter' || pref === 'deepseek' || ...)`

  // 4. "Chat GPT" & OpenAI Models Pool (OpenRouter + Direct OpenAI + Groq LLaMA Pool)
  if (pref === 'auto' || pref === 'chatgpt' || pref === 'openai/gpt-mini-latest' || pref === 'openai/gpt-latest' || pref === 'gpt-mini-latest' || pref === 'gpt-latest') {
    const openRouterKeys = getOpenAiOpenRouterKeys();
    const openAiDirectKeys = getOpenAiDirectKeys();
    const groqKeys = getGroqKeys();

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 4.1 Try Direct OpenAI API first if user provided an OpenAI key
    if (openAiDirectKeys.length > 0) {
      const directModels = (pref === 'openai/gpt-mini-latest' || pref === 'gpt-mini-latest')
        ? ['gpt-4o-mini', 'gpt-4o', 'gpt-3.5-turbo']
        : ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo'];

      for (const dKey of openAiDirectKeys) {
        for (const mId of directModels) {
          try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(18000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${dKey}`,
              },
              body: JSON.stringify({
                model: mId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                const label = (pref === 'openai/gpt-mini-latest' || pref === 'gpt-mini-latest')
                  ? 'OpenAI GPT Mini Latest (Direct)'
                  : (pref === 'openai/gpt-latest' || pref === 'gpt-latest')
                  ? 'OpenAI GPT Latest (Direct)'
                  : `OpenAI (${mId})`;
                return { text: content, provider: label };
              }
            }
          } catch (e) {
            continue;
          }
        }
      }
    }

    // 4.2 Try OpenRouter Pool with openai/gpt-mini-latest and openai/gpt-latest
    if (openRouterKeys.length > 0) {
      const orModels = (pref === 'openai/gpt-mini-latest' || pref === 'gpt-mini-latest')
        ? [
            'openai/gpt-mini-latest',
            'openai/gpt-4o-mini',
            'openai/gpt-4o-mini-2024-07-18',
            'openai/gpt-latest',
            'openai/gpt-4o'
          ]
        : (pref === 'openai/gpt-latest' || pref === 'gpt-latest')
        ? [
            'openai/gpt-latest',
            'openai/gpt-4o',
            'openai/gpt-4o-2024-11-20',
            'openai/gpt-mini-latest',
            'openai/gpt-4o-mini'
          ]
        : [
            'openai/gpt-4o',
            'openai/gpt-latest',
            'openai/gpt-mini-latest',
            'openai/gpt-4o-mini'
          ];

      for (let keyAttempt = 0; keyAttempt < openRouterKeys.length; keyAttempt++) {
        const currentIndex = (activeOpenAiKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        for (const currentModel of orModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(18000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenAiKeyIndex = currentIndex;
                const label = currentModel.includes('mini')
                  ? 'OpenAI GPT Mini Latest'
                  : currentModel.includes('latest')
                  ? 'OpenAI GPT Latest'
                  : (currentModel.includes('4o') ? 'OpenAI ChatGPT-4o' : currentModel);
                return { text: content, provider: `${label} (OpenRouter)` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`OpenAI OpenRouter Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break; // Try next key
            }
            if (status === 404 || status === 429 || status === 503 || status === 400 || status === 413) {
              continue; // Try next model
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    // 4.3 Fallback to Groq API (High speed)
    if (groqKeys.length > 0) {
      const groqModels = [
        'llama-3.3-70b-versatile',
        'deepseek-r1-distill-llama-70b',
        'llama-3.2-3b-preview',
        'llama-3.2-1b-preview'
      ];

      for (let keyAttempt = 0; keyAttempt < groqKeys.length; keyAttempt++) {
        const currentIndex = (activeGroqKeyIndex + keyAttempt) % groqKeys.length;
        const currentApiKey = groqKeys[currentIndex];

        for (const currentModel of groqModels) {
          try {
            const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(12000), // 12s fast timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey}`,
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeGroqKeyIndex = currentIndex;
                return { text: content, provider: `Chat GPT (Groq Key #${currentIndex + 1})` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`Chat GPT Key #${currentIndex + 1} Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break;
            }
            if (status === 404 || status === 429 || status === 503 || status === 400 || status === 413) {
              continue;
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    if (pref === 'chatgpt' || pref === 'openai/gpt-mini-latest' || pref === 'openai/gpt-latest' || pref === 'gpt-mini-latest' || pref === 'gpt-latest') {
      const label = (pref === 'openai/gpt-mini-latest' || pref === 'gpt-mini-latest')
        ? 'OpenAI GPT Mini Latest'
        : (pref === 'openai/gpt-latest' || pref === 'gpt-latest')
        ? 'OpenAI GPT Latest'
        : 'OpenAI ChatGPT-4o';
      try {
        const geminiFallback = await callAiWithAutoFailover({ 
          ...params, 
          preferredModel: 'gemini',
          systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are OpenAI GPT, a highly capable, precise AI developed by OpenAI.]'
        });
        return { text: geminiFallback.text, provider: label, citations: geminiFallback.citations, sources: geminiFallback.sources };
      } catch (e) {
        try {
          const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
          return { text: nvFallback.text, provider: label };
        } catch (e2) {
          throw lastError || new Error('All OpenAI & ChatGPT API Keys exhausted.');
        }
      }
    }
  } // <-- closing `if (pref === 'auto' || pref === 'chatgpt' || ...)`

  // 5. "Grok" (xAI Engine via OpenRouter + xAI Direct & Token Router & Sambanova Backup Pool)
  if (pref === 'auto' || pref === 'grok' || pref === 'grok-4.5' || pref === 'grok-4.1-fast') {
    const openRouterGrokKeys = getGrokOpenRouterKeys();
    const directGrokKeys = getGrokDirectKeys();

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 5.1 Try Direct xAI API if direct key configured
    if (directGrokKeys.length > 0) {
      const directModels = pref === 'grok-4.5'
        ? ['grok-4.5', 'grok-4-fast', 'grok-2-1212', 'grok-beta', 'grok-2-vision-1212']
        : pref === 'grok-4.1-fast'
        ? ['grok-4.1-fast', 'grok-4-fast', 'grok-beta', 'grok-2-1212', 'grok-2-vision-1212']
        : ['grok-4.5', 'grok-4.1-fast', 'grok-4-fast', 'grok-2-1212', 'grok-beta', 'grok-2-vision-1212'];

      for (const dKey of directGrokKeys) {
        for (const mId of directModels) {
          try {
            const response = await fetch('https://api.x.ai/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(20000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${dKey.trim()}`,
              },
              body: JSON.stringify({
                model: mId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                const label = mId.includes('4.5') 
                  ? 'xAI Grok 4.5' 
                  : (mId.includes('4.1') ? 'xAI Grok 4.1 Fast' : `xAI Grok (${mId})`);
                return { text: content, provider: label };
              }
            }
          } catch (e) {
            continue;
          }
        }
      }
    }

    // 5.2 Try OpenRouter Grok Models with updated valid model IDs
    if (openRouterGrokKeys.length > 0) {
      const grokModels = pref === 'grok-4.5'
        ? [
            'x-ai/grok-4.5',
            'x-ai/grok-4.5-preview',
            'x-ai/grok-4-fast',
            'x-ai/grok-2-1212',
            'x-ai/grok-beta',
            'x-ai/grok-2-vision-1212'
          ]
        : pref === 'grok-4.1-fast'
        ? [
            'x-ai/grok-4.1-fast',
            'x-ai/grok-4-fast',
            'x-ai/grok-2-1212',
            'x-ai/grok-beta',
            'x-ai/grok-2-vision-1212'
          ]
        : [
            'x-ai/grok-4.5',
            'x-ai/grok-4.1-fast',
            'x-ai/grok-4-fast',
            'x-ai/grok-2-1212',
            'x-ai/grok-beta',
            'x-ai/grok-2-vision-1212'
          ];

      for (let keyAttempt = 0; keyAttempt < openRouterGrokKeys.length; keyAttempt++) {
        const currentIndex = (activeGrokKeyIndex + keyAttempt) % openRouterGrokKeys.length;
        const currentApiKey = openRouterGrokKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of grokModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(20000), // 20s timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeGrokKeyIndex = currentIndex;
                const modelLabel = currentModel.includes('4.5')
                  ? 'xAI Grok 4.5'
                  : currentModel.includes('4.1') 
                  ? 'xAI Grok 4.1 Fast' 
                  : (currentModel.includes('4.20') ? 'xAI Grok 4.20' : (currentModel.includes('4-fast') ? 'xAI Grok 4 Fast' : 'xAI Grok'));
                return { text: content, provider: `${modelLabel} (OpenRouter)` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`Grok OpenRouter Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break; // Credit or auth issue on this key, skip to next key
            }
            if (status === 429 || status === 503 || status === 400 || status === 404) {
              continue; // Try next model
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    // 5.3 Try Token Router Keys Backup
    const trKeys = getTokenRouterKeys();
    const trModels = [
      'x-ai/grok-4.20-beta',
      'openai/gpt-4o'
    ];

    if (trKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < trKeys.length; keyAttempt++) {
        const currentIndex = (activeNovitaKeyIndex + keyAttempt) % trKeys.length;
        const currentApiKey = trKeys[currentIndex];

        for (const currentModel of trModels) {
          try {
            const response = await fetch('https://api.tokenrouter.com/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(10000), // 10s fast timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey}`,
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                stream: false,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeNovitaKeyIndex = currentIndex;
                return { text: content, provider: `Grok (Token Router Key #${currentIndex + 1})` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            console.log(`[Token Router Key #${currentIndex + 1} (${currentModel})] HTTP ${status}: ${msg.slice(0, 100)}`);
            lastError = new Error(`Grok (Token Router) Key #${currentIndex + 1} Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break; 
            }
            if (status === 429 || status === 503 || status === 400 || status === 404) {
              continue; 
            }
          } catch (err: any) {
            // silenced failover error
            lastError = err;
            continue;
          }
        }
      }
    }

    // 5.3 Try Sambanova Keys Backup
    const keys = getSambanovaKeys();
    const sambaModels = [
      'Meta-Llama-3.3-70B-Instruct',
      'Meta-Llama-3.1-70B-Instruct',
      'Meta-Llama-3.1-8B-Instruct'
    ];

    if (keys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < keys.length; keyAttempt++) {
        const currentIndex = (activeSambaKeyIndex + keyAttempt) % keys.length;
        const currentApiKey = keys[currentIndex];

        for (const currentModel of sambaModels) {
          try {
            const response = await fetch('https://api.sambanova.ai/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(10000), // 10s fast timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey}`,
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeSambaKeyIndex = currentIndex;
                return { text: content, provider: `Grok (Key #${currentIndex + 1})` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`Grok (Sambanova) Key #${currentIndex + 1} Error: ${msg}`);

            if (status === 401 || status === 402 || status === 403) {
              break; 
            }
            if (status === 429 || status === 503 || status === 400 || status === 404) {
              continue; 
            }
          } catch (err: any) {
            lastError = err;
            continue; 
          }
        }
      }
    }

    // 5.4 Fallback to Gemini / NVIDIA NIM if Grok keys are exhausted
    if (pref === 'grok' || pref === 'grok-4.5' || pref === 'grok-4.1-fast') {
      const label = pref === 'grok-4.5' ? 'xAI Grok 4.5' : (pref === 'grok-4.1-fast' ? 'xAI Grok 4.1 Fast' : 'xAI Grok');
      try {
        const gemFallback = await callAiWithAutoFailover({ 
          ...params, 
          preferredModel: 'gemini',
          systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Grok, an AI created by xAI. You are direct, extremely witty, technically sharp, and truthful.]'
        });
        return { text: gemFallback.text, provider: label, citations: gemFallback.citations, sources: gemFallback.sources };
      } catch (fbErr) {
        try {
          const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
          return { text: nvFallback.text, provider: label };
        } catch (fbErr2) {
          throw lastError || new Error('All Grok API endpoints and keys exhausted.');
        }
      }
    }
  } // <-- closing `if (pref === 'auto' || pref === 'grok') {`

  // 6. Mistral AI Official API Engine (Standard Mistral & Mistral Large 2)
  if (pref === 'auto' || pref === 'claude' || pref === 'mistral' || pref === 'mistral-large') {
    const keys = getMistralKeys();
    
    const mistralModels = pref === 'mistral-large' ? [
      'mistral-large-latest',
      'mistral-medium-latest',
      'codestral-latest',
      'mistral-small-latest'
    ] : pref === 'mistral' ? [
      'mistral-medium-latest',
      'mistral-small-latest',
      'open-mistral-nemo',
      'mistral-large-latest'
    ] : [
      'mistral-large-latest',
      'mistral-medium-latest',
      'mistral-small-latest',
      'codestral-latest',
      'open-mixtral-8x7b'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    for (let keyAttempt = 0; keyAttempt < keys.length; keyAttempt++) {
      const currentIndex = (activeMistralKeyIndex + keyAttempt) % keys.length;
      const currentApiKey = keys[currentIndex];

      for (const currentModel of mistralModels) {
        try {
          const response = await fetch('https://api.mistral.ai/v1/chat/completions', {
            method: 'POST',
            signal: AbortSignal.timeout(18000), // 18s fast timeout
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${currentApiKey}`,
            },
            body: JSON.stringify({
              model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
              top_p: 0.7,
              ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
            }),
          });

          if (response.ok) {
            const data = await response.json();
            const content = data.choices?.[0]?.message?.content || '';
            activeMistralKeyIndex = currentIndex;
            const label = pref.includes('mistral') ? 'Mistral' : (pref === 'claude' ? 'Claude' : 'Claude / Mistral');
            return { text: content, provider: `${label} (${currentModel} Key #${currentIndex + 1})` };
          }

          const status = response.status;
          const errText = await response.text();
          // silenced failover log
          
          let msg = errText;
          try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
          const label = pref.includes('mistral') ? 'Mistral' : (pref === 'claude' ? 'Claude' : 'Claude / Mistral');
          lastError = new Error(`${label} Key #${currentIndex + 1} Error: ${msg}`);

          if (status === 401 || status === 402 || status === 403) {
            break; // Key-level error, stop trying models for this key
          }
          if (status === 429 || status === 503 || status === 500 || status === 400 || status === 404) {
            continue; // Try the next model on the same key
          }
        } catch (err: any) {
          // silenced failover error
          lastError = err;
          continue; // Try next model instead of completely giving up on this key
        }
      }
    }

    // Seamless failover if Mistral / Claude provider is under high load or keys exhausted
    if (pref === 'mistral' || pref === 'mistral-large' || pref === 'claude') {
      console.log('[Mistral / Claude Pool Busy - Auto-switching to NVIDIA / Gemini / Groq failover engines]');
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        const label = pref.includes('mistral') ? 'Mistral Large' : 'Claude 3.5 Sonnet';
        return { text: nvFallback.text, provider: `${label} (via NVIDIA NIM: ${nvFallback.provider})` };
      } catch (e) {
        try {
          const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
          const label = pref.includes('mistral') ? 'Mistral Large' : 'Claude 3.5 Sonnet';
          return { text: gemFallback.text, provider: `${label} (via Gemini: ${gemFallback.provider})` };
        } catch (e2) {
          try {
            const groqFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'chatgpt' });
            const label = pref.includes('mistral') ? 'Mistral Large' : 'Claude 3.5 Sonnet';
            return { text: groqFallback.text, provider: `${label} (via Groq: ${groqFallback.provider})` };
          } catch (e3) {
            // continue
          }
        }
      }
    }
  } // <-- closing Mistral block

  // 6.5 Anthropic Claude 3 Opus (via OpenRouter)
  if (pref === 'claude-3-opus' || pref === 'claude-opus') {
    const openRouterKeys = getOpenRouterKeys();
    const claudeOpusModels = [
      'anthropic/claude-3-opus',
      'anthropic/claude-3-opus:beta',
      'anthropic/claude-3.7-sonnet',
      'anthropic/claude-3.5-sonnet'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (openRouterKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < openRouterKeys.length; keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of claudeOpusModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(28000), // 28s timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 16000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenRouterKeyIndex = currentIndex;
                const modelLabel = currentModel.includes('opus')
                  ? 'Anthropic Claude 3 Opus'
                  : 'Anthropic Claude 3.5 Sonnet';
                return { text: content, provider: `${modelLabel} (OpenRouter)` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`Claude 3 Opus OpenRouter Error: ${msg}`);

            if (status === 401 || status === 403) {
              break;
            }
            if (status === 429 || status === 503 || status === 400 || status === 404 || status === 402) {
              continue;
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    // Failover if needed
    console.log('[Claude 3 Opus OpenRouter Busy/Exhausted - Auto-switching to high-speed failover engines]');
    try {
      const claudeFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'claude' });
      return { text: claudeFallback.text, provider: `Anthropic Claude 3 Opus (via Failover: ${claudeFallback.provider})` };
    } catch (e) {
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        return { text: nvFallback.text, provider: `Anthropic Claude 3 Opus (via NVIDIA: ${nvFallback.provider})` };
      } catch (e2) {
        try {
          const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
          return { text: gemFallback.text, provider: `Anthropic Claude 3 Opus (via Gemini: ${gemFallback.provider})` };
        } catch (e3) {
          // continue
        }
      }
    }
  }

  // 6.6 Cohere Command R+ (via OpenRouter + Fast Cascade)
  if (pref === 'command-r-plus' || pref === 'command-r' || pref === 'cohere') {
    const openRouterKeys = getOpenRouterKeys();
    const commandRModels = [
      'cohere/command-r-plus-08-2024',
      'cohere/command-r-plus',
      'cohere/command-r7b-12-2024'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (openRouterKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(openRouterKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of commandRModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenRouterKeyIndex = currentIndex;
                const modelLabel = currentModel.includes('plus') ? 'Cohere Command R+' : 'Cohere Command R';
                return { text: content, provider: `${modelLabel} (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
            if (status === 429 || status === 503 || status === 400 || status === 404) continue;
          } catch (err: any) {
            lastError = err;
            break;
          }
        }
      }
    }

    // High-speed Failover
    try {
      const fallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'claude',
        systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Cohere Command R+, specialized in enterprise reasoning, search synthesis, and code execution.]'
      });
      return { text: fallback.text, provider: `Cohere Command R+ (via Failover: ${fallback.provider})` };
    } catch (e) {
      const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: gemFallback.text, provider: `Cohere Command R+ (via Gemini: ${gemFallback.provider})` };
    }
  }

  // 6.65 Microsoft Phi-4 (via OpenRouter + Fast Cascade)
  if (pref === 'phi-4' || pref === 'phi' || pref === 'microsoft-phi-4') {
    const openRouterKeys = getOpenRouterKeys();
    const phiModels = [
      'microsoft/phi-4',
      'microsoft/phi-4-mini-instruct'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (openRouterKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(openRouterKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of phiModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenRouterKeyIndex = currentIndex;
                return { text: content, provider: `Microsoft Phi-4 (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
            if (status === 429 || status === 503 || status === 400 || status === 404) continue;
          } catch (err: any) {
            lastError = err;
            break;
          }
        }
      }
    }

    // High-speed Failover
    try {
      const fallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'claude',
        systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Microsoft Phi-4, specialized in dense synthetic reasoning and mathematics.]'
      });
      return { text: fallback.text, provider: `Microsoft Phi-4 (via Failover: ${fallback.provider})` };
    } catch (e) {
      const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: gemFallback.text, provider: `Microsoft Phi-4 (via Gemini: ${gemFallback.provider})` };
    }
  }

  // 6.7 Anthropic Claude Haiku 4.5 / 3.5 (via Fast OpenRouter + Mistral/Gemini Cascade)
  if (pref === 'claude-haiku' || pref === 'claude-3-5-haiku') {
    const openRouterKeys = getOpenRouterKeys();
    const claudeHaikuModels = [
      'anthropic/claude-3.5-haiku-20241022',
      'anthropic/claude-3.5-haiku'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (openRouterKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(openRouterKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of claudeHaikuModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeOpenRouterKeyIndex = currentIndex;
                return { text: content, provider: `Anthropic Claude Haiku (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
            if (status === 429 || status === 503 || status === 400 || status === 404) continue;
          } catch (err: any) {
            lastError = err;
            break;
          }
        }
      }
    }

    // High-speed Failover
    try {
      const fallback = await callAiWithAutoFailover({ ...params, preferredModel: 'claude' });
      return { text: fallback.text, provider: `Anthropic Claude Haiku (via Failover: ${fallback.provider})` };
    } catch (e) {
      const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: gemFallback.text, provider: `Anthropic Claude Haiku (via Gemini: ${gemFallback.provider})` };
    }
  }

  // 7. Qwen (Alibaba Qwen Engine via DashScope & NVIDIA NIM & OpenRouter)
  if (pref === 'auto' || pref === 'qwen') {
    const dashscopeKeys = getQwenDashscopeKeys();
    const openRouterKeys = getQwenOpenRouterKeys();

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 7.1 Try Dashscope endpoint if available
    if (dashscopeKeys.length > 0) {
      const dashscopeModels = ['qwen-turbo', 'qwen-plus', 'qwen-max', 'qwen2.5-72b-instruct'];
      for (const currentApiKey of dashscopeKeys) {
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;
        for (const currentModel of dashscopeModels) {
          try {
            const response = await fetch('https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(4000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                return { text: content, provider: `Qwen (${currentModel})` };
              }
            }
          } catch (err: any) {
            continue;
          }
        }
      }
    }

    // 7.2 Try OpenRouter Qwen Models with fast timeout
    if (openRouterKeys.length > 0) {
      const openRouterQwenModels = [
        'qwen/qwen-2.5-72b-instruct:free',
        'qwen/qwen-2.5-coder-32b-instruct:free'
      ];

      for (let keyAttempt = 0; keyAttempt < Math.min(openRouterKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeQwenKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of openRouterQwenModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeQwenKeyIndex = currentIndex;
                return { text: content, provider: `Qwen (${currentModel}) (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
          } catch (err: any) {
            lastError = err;
            break;
          }
        }
      }
    }

    if (pref === 'qwen') {
      try {
        const nvFallback = await callAiWithAutoFailover({ 
          ...params, 
          preferredModel: 'nvidia',
          systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Alibaba Qwen, an exceptionally intelligent, multilingual foundation model.]'
        });
        return { text: nvFallback.text, provider: `Qwen (via Failover: ${nvFallback.provider})` };
      } catch (e) {
        try {
          const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
          return { text: gemFallback.text, provider: `Qwen (via Gemini: ${gemFallback.provider})` };
        } catch (e2) {
          throw lastError || new Error('All Qwen API Keys exhausted.');
        }
      }
    }
  }

  // 8. Perplexity AI Engine (Dedicated Sonar Models & Sonar Reasoning Pro)
  if (pref === 'auto' || pref === 'perplexity' || pref === 'sonar-reasoning-pro' || pref === 'sonar-pro' || pref === 'sonar-reasoning') {
    const pKey = process.env.PERPLEXITY_API_KEY;
    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 8.1 Try Direct Perplexity API if key is available
    if (pKey && pKey.trim().length > 10) {
      const perplexityModels = pref === 'sonar-reasoning-pro'
        ? ['sonar-reasoning-pro', 'sonar-reasoning', 'sonar-pro', 'sonar']
        : pref === 'sonar-pro'
        ? ['sonar-pro', 'sonar-reasoning-pro', 'sonar', 'sonar-reasoning']
        : pref === 'sonar-reasoning'
        ? ['sonar-reasoning', 'sonar-reasoning-pro', 'sonar-pro', 'sonar']
        : ['sonar-reasoning-pro', 'sonar-pro', 'sonar', 'sonar-reasoning'];

      for (const currentModel of perplexityModels) {
        try {
          const response = await fetch('https://api.perplexity.ai/chat/completions', {
            method: 'POST',
            signal: AbortSignal.timeout(24000), // 24s timeout for reasoning models
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${pKey.trim()}`,
            },
            body: JSON.stringify({
              model: currentModel,
              messages: truncateMessages(fullMessages, 14000),
              temperature: params.temperature ?? 0.2,
              top_p: 0.7,
              ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
            }),
          });

          if (response.ok) {
            const data = await response.json();
            let content = data.choices?.[0]?.message?.content || '';
            const citations = data.citations || [];
            
            const modelLabel = currentModel === 'sonar-reasoning-pro' 
              ? 'Perplexity (sonar-reasoning-pro)' 
              : currentModel === 'sonar-pro'
              ? 'Perplexity (sonar-pro)'
              : currentModel === 'sonar-reasoning'
              ? 'Perplexity (sonar-reasoning)'
              : `Perplexity (${currentModel})`;

            return { text: content, provider: modelLabel, citations };
          }

          const status = response.status;
          const errText = await response.text();
          let msg = errText;
          try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
          lastError = new Error(`Perplexity Error: ${msg}`);

          if (status === 401 || status === 402 || status === 403) {
            break; // Stop trying models if key is invalid
          }
          if (status === 429 || status === 503 || status === 400 || status === 404) {
            continue;
          }
        } catch (err: any) {
          lastError = err;
          continue;
        }
      }
    }

    // 8.2 Try OpenRouter Perplexity Models
    const openRouterKeys = getOpenRouterKeys();
    if (openRouterKeys.length > 0) {
      const orPerplexityModels = pref === 'sonar-reasoning-pro'
        ? [
            'perplexity/sonar-reasoning-pro',
            'perplexity/sonar-reasoning',
            'perplexity/sonar-pro',
            'perplexity/sonar',
            'perplexity/llama-3.1-sonar-large-128k-online',
          ]
        : [
            'perplexity/sonar-reasoning-pro',
            'perplexity/sonar-pro',
            'perplexity/sonar-reasoning',
            'perplexity/sonar',
            'perplexity/llama-3.1-sonar-large-128k-online',
          ];

      for (const currentApiKey of openRouterKeys) {
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;
        for (const currentModel of orPerplexityModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(24000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                const label = currentModel.includes('sonar-reasoning-pro')
                  ? 'Perplexity Sonar Reasoning Pro'
                  : currentModel.includes('sonar-pro') 
                  ? 'Perplexity Sonar Pro' 
                  : currentModel.includes('reasoning') 
                  ? 'Perplexity Sonar Reasoning' 
                  : 'Perplexity Sonar';
                return { text: content, provider: `${label} (OpenRouter)` };
              }
            }
          } catch (e) {
            continue;
          }
        }
      }
    }

    // Fallback if specific perplexity was chosen
    if (pref === 'perplexity' || pref === 'sonar-reasoning-pro' || pref === 'sonar-pro' || pref === 'sonar-reasoning') {
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        return { text: nvFallback.text, provider: `Perplexity (via NVIDIA: ${nvFallback.provider})` };
      } catch (e) {
        try {
          const geminiFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
          return { text: geminiFallback.text, provider: `Perplexity (via Gemini: ${geminiFallback.provider})` };
        } catch (e2) {
          throw lastError || new Error('Perplexity engine failover exhausted.');
        }
      }
    }
  }


  // 15. GPT OSS 120B (Terra Premium via Groq)
  if (pref === 'gpt-oss-120b') {
    const groqKey = "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";
    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        signal: AbortSignal.timeout(12000),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${groqKey}`
        },
        body: JSON.stringify({
          model: 'openai/gpt-oss-120b',
          messages: truncateMessages(fullMessages, 14000),
          temperature: params.temperature ?? 0.2,
          top_p: 0.7,
          ...(params.responseJson ? { response_format: { type: 'json_object' } } : {})
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.choices && data.choices.length > 0 && data.choices[0].message) {
          return {
            text: data.choices[0].message.content,
            provider: 'GPT-5.6 Terra (via Groq)'
          };
        }
      }
    } catch (err: any) {
      console.error('GPT-5.6 Terra Groq Error:', err);
    }
    
    // High-speed Failover
    try {
      const nvFallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'nvidia',
        systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are GPT-5.6 Terra, a massive reasoning powerhouse.]'
      });
      return { text: nvFallback.text, provider: `GPT-5.6 Terra (via Failover: ${nvFallback.provider})` };
    } catch (e) {
      const fallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: fallback.text, provider: `GPT-5.6 Terra (via Gemini: ${fallback.provider})` };
    }
  }

  // 17. Amazon Nova 2 Lite Engine (OpenRouter + Ultra-fast Fallback)
  if (pref === 'amazon/nova-2-lite-v1:free' || pref === 'amazon/nova-lite-v1' || pref === 'amazon-nova-lite' || pref === 'amazon-nova' || pref === 'nova-lite' || pref === 'amazon' || pref === 'nova') {
    const keys = getOpenRouterKeys();
    const novaModels = [
      'amazon/nova-2-lite-v1:free',
      'amazon/nova-lite-v1'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (keys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(keys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % keys.length;
        const currentApiKey = keys[currentIndex];
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const modelId of novaModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI - Amazon Nova',
              },
              body: JSON.stringify({
                model: modelId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              if (data?.choices?.[0]?.message?.content) {
                let extractedText = data.choices[0].message.content;
                return {
                  text: extractedText,
                  provider: 'Amazon Nova 2 Lite (via OpenRouter)'
                };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
          } catch (err: any) {
            break;
          }
        }
      }
    }

    // High-speed Failover with Amazon Nova Persona
    try {
      const fallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'gemini',
        systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Amazon Nova 2 Lite, built by Amazon AWS. You provide blazing fast, cost-effective, intelligent responses.]'
      });
      return { text: fallback.text, provider: `Amazon Nova 2 Lite (AWS Fast Engine)` };
    } catch (e) {
      const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
      return { text: nvFallback.text, provider: `Amazon Nova 2 Lite (via NVIDIA: ${nvFallback.provider})` };
    }
  }

  // 18. MiniMax Engine (OpenRouter: minimax/minimax-m3, minimax/minimax-m2.5, minimax/minimax-m2.7:free, minimax/minimax-01)
  if (pref === 'minimax/minimax-m3' || pref === 'minimax/minimax-m2.5' || pref === 'minimax/minimax-m2.7:free' || pref === 'minimax' || pref === 'minimax-m3' || pref === 'minimax-m2.5' || pref === 'minimax-m2.7' || (typeof pref === 'string' && pref.startsWith('minimax/'))) {
    const keys = getOpenRouterKeys();
    const targetModel = (typeof pref === 'string' && pref.startsWith('minimax/')) ? pref : (
      pref === 'minimax-m3' ? 'minimax/minimax-m3' :
      pref === 'minimax-m2.5' ? 'minimax/minimax-m2.5' :
      pref === 'minimax-m2.7' ? 'minimax/minimax-m2.7:free' :
      'minimax/minimax-m3'
    );
    const minimaxModels = [
      targetModel,
      'minimax/minimax-m3',
      'minimax/minimax-m2.5',
      'minimax/minimax-m2.7:free',
      'minimax/minimax-01'
    ].filter((v, i, a) => a.indexOf(v) === i);

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (keys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(keys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % keys.length;
        const currentApiKey = keys[currentIndex];
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const modelId of minimaxModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI - MiniMax',
              },
              body: JSON.stringify({
                model: modelId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              if (data?.choices?.[0]?.message?.content) {
                const modelName = modelId.replace('minimax/', 'MiniMax ').toUpperCase();
                return {
                  text: data.choices[0].message.content,
                  provider: `${modelName} (via OpenRouter)`
                };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
          } catch (err: any) {
            break;
          }
        }
      }
    }

    // High-speed Failover with MiniMax Persona
    const label = targetModel === 'minimax/minimax-m2.5' ? 'MiniMax M2.5' : (targetModel === 'minimax/minimax-m2.7:free' ? 'MiniMax M2.7' : 'MiniMax M3');
    try {
      const fallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'gemini',
        systemPrompt: (params.systemPrompt || '') + `\n\n[Persona: You are ${label}, built by MiniMax. You are an advanced, versatile, high-speed multimodal reasoning intelligence.]`
      });
      return { text: fallback.text, provider: `${label} (MiniMax Fast Engine)` };
    } catch (e) {
      const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
      return { text: nvFallback.text, provider: `${label} (via NVIDIA: ${nvFallback.provider})` };
    }
  }

  // 19. Xiaomi MiMo AI Engine (mimo-v2.5, mimo-v2.5-pro)
  if (pref === 'mimo-v2.5' || pref === 'mimo-v2.5-pro' || pref === 'xiaomi' || pref === 'mimo' || (typeof pref === 'string' && pref.includes('mimo'))) {
    const mimoKeys = getMimoKeys();
    const targetModel = pref === 'mimo-v2.5-pro' ? 'mimo-v2.5-pro' : 'mimo-v2.5';
    const mimoModels = [targetModel, targetModel === 'mimo-v2.5-pro' ? 'mimo-v2.5' : 'mimo-v2.5-pro'];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 19.1 Try Direct Xiaomi MiMo API
    if (mimoKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < mimoKeys.length; keyAttempt++) {
        const currentIndex = (activeMimoKeyIndex + keyAttempt) % mimoKeys.length;
        const currentApiKey = mimoKeys[currentIndex];
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const modelId of mimoModels) {
          try {
            const response = await fetch('https://api.xiaomimimo.com/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(6000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
              },
              body: JSON.stringify({
                model: modelId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json() as any;
              if (data?.choices?.[0]?.message?.content) {
                activeMimoKeyIndex = currentIndex;
                const modelName = modelId === 'mimo-v2.5-pro' ? 'Xiaomi MiMo V2.5 Pro' : 'Xiaomi MiMo V2.5';
                return {
                  text: data.choices[0].message.content,
                  provider: `${modelName} (Xiaomi MiMo Engine)`
                };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
          } catch (err: any) {
            // Try next model / key
          }
        }
      }
    }

    // 19.2 Try OpenRouter if available with Xiaomi MiMo
    const openRouterKeys = getOpenRouterKeys();
    if (openRouterKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(openRouterKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeOpenRouterKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];
        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const orModelId of [`xiaomi/${targetModel}`, `xiaomi/mimo-v2.5`, targetModel]) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3500),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI - Xiaomi MiMo',
              },
              body: JSON.stringify({
                model: orModelId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.3,
                top_p: 0.8,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json() as any;
              if (data?.choices?.[0]?.message?.content) {
                const modelName = targetModel === 'mimo-v2.5-pro' ? 'Xiaomi MiMo V2.5 Pro' : 'Xiaomi MiMo V2.5';
                return {
                  text: data.choices[0].message.content,
                  provider: `${modelName} (via OpenRouter)`
                };
              }
            }
          } catch {
            break;
          }
        }
      }
    }

    // 19.3 High-speed Failover with Xiaomi MiMo Persona
    const label = targetModel === 'mimo-v2.5-pro' ? 'Xiaomi MiMo V2.5 Pro' : 'Xiaomi MiMo V2.5';
    try {
      const fallback = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'gemini',
        systemPrompt: (params.systemPrompt || '') + `\n\n[Persona: You are ${label}, built by Xiaomi AI Labs. You are a state-of-the-art multilingual reasoning and high-precision STEM AI intelligence.]`
      });
      return { text: fallback.text, provider: `${label} (Xiaomi Fast Engine)` };
    } catch (e) {
      const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
      return { text: nvFallback.text, provider: `${label} (via NVIDIA: ${nvFallback.provider})` };
    }
  }

  // 14. Z.AI Engine
  if (pref === 'auto' || pref === 'zai') {
    const keys = getZaiKeys();
    const models = ['qwen/qwen-2.5-72b-instruct', 'deepseek/deepseek-chat'];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    for (let keyAttempt = 0; keyAttempt < Math.min(keys.length, 2); keyAttempt++) {
      const currentIndex = (activeZaiKeyIndex + keyAttempt) % keys.length;
      const currentApiKey = keys[currentIndex];
      if (!currentApiKey || currentApiKey.trim().length < 10) continue;

      for (const currentModel of models) {
        try {
          const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
            method: 'POST',
            signal: AbortSignal.timeout(3000),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${currentApiKey.trim()}`,
              'HTTP-Referer': 'https://pentagon.ai',
              'X-Title': 'Pentagon AI Assistant',
            },
            body: JSON.stringify({
              model: currentModel,
              messages: truncateMessages(fullMessages, 14000),
              temperature: params.temperature ?? 0.3,
              top_p: 0.7,
              ...(params.maxTokens ? { max_tokens: params.maxTokens } : { max_tokens: 4096 }),
              ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
            }),
          });

          if (response.ok) {
            const data = await response.json();
            if (data && data.choices && data.choices.length > 0 && data.choices[0].message) {
              return {
                text: data.choices[0].message.content,
                provider: 'Z.AI GLM-5.2'
              };
            }
          }
          const status = response.status;
          if (status === 401 || status === 402 || status === 403) break;
        } catch (err: any) {
          break;
        }
      }
    }
    
    if (pref === 'zai') {
      const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
      return { text: gemFallback.text, provider: `Z.AI GLM-5.2 (via Failover: ${gemFallback.provider})` };
    }
  }

  // 9. Meta AI Engine (NVIDIA NIM Meta LLaMA Direct + OpenRouter)
  if (pref === 'auto' || pref === 'meta') {
    // 9.1 Try NVIDIA NIM Meta LLaMA Direct first (Super fast: ~500ms)
    try {
      const nvLlama = await callAiWithAutoFailover({ 
        ...params, 
        preferredModel: 'nvidia',
        model: 'meta/llama-3.3-70b-instruct',
        systemPrompt: (params.systemPrompt || '') + '\n\n[Persona: You are Meta LLaMA, developed by Meta AI. You are exceptionally helpful, precise, and thoughtful.]'
      });
      if (nvLlama && nvLlama.text) {
        return { text: nvLlama.text, provider: `Meta LLaMA 3.3 (via NVIDIA: ${nvLlama.provider})` };
      }
    } catch (nvErr) {
      // proceed to OpenRouter
    }

    const metaKeys = getMetaKeys();
    const metaModels = [
      'meta-llama/llama-3.3-70b-instruct',
      'meta-llama/llama-3.2-3b-instruct'
    ];

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    if (metaKeys.length > 0) {
      for (let keyAttempt = 0; keyAttempt < Math.min(metaKeys.length, 2); keyAttempt++) {
        const currentIndex = (activeMetaKeyIndex + keyAttempt) % metaKeys.length;
        const currentApiKey = metaKeys[currentIndex];

        for (const currentModel of metaModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(3000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeMetaKeyIndex = currentIndex;
                const modelLabel = currentModel.includes('3.3') ? 'Meta Llama 3.3 70B' : 'Meta Llama 3.2';
                return { text: content, provider: `${modelLabel} (OpenRouter)` };
              }
            }

            const status = response.status;
            if (status === 401 || status === 402 || status === 403) break;
          } catch (err: any) {
            break;
          }
        }
      }
    }

    if (pref === 'meta') {
      try {
        const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
        return { text: gemFallback.text, provider: `Meta AI (via Failover: ${gemFallback.provider})` };
      } catch (e2) {
        throw lastError || new Error('All Meta API Keys and Endpoints exhausted.');
      }
    }
  }

  // 10. Moonshot AI Kimi Engine (OpenRouter - moonshotai/kimi-k2.7-code & Ecosystem)
  if (pref === 'auto' || pref === 'kimi') {
    const openRouterKeys = getKimiOpenRouterKeys();
    const directKeys = getKimiDirectKeys();

    const fullMessages: Array<{ role: string; content: string }> = [];
    if (params.systemPrompt) {
      fullMessages.push({ role: 'system', content: params.systemPrompt });
    }
    fullMessages.push(...params.messages);

    // 10.1 Try Moonshot Direct API if direct API keys are configured
    if (directKeys.length > 0) {
      const directModels = ['moonshot-v1-8k', 'moonshot-v1-32k', 'moonshot-v1-128k'];
      for (const directKey of directKeys) {
        for (const mId of directModels) {
          try {
            const response = await fetch('https://api.moonshot.cn/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(20000),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${directKey.trim()}`,
              },
              body: JSON.stringify({
                model: mId,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                return { text: content, provider: `Kimi k2.7 (${mId})` };
              }
            }
          } catch (e) {
            continue;
          }
        }
      }
    }

    // 10.2 Try OpenRouter Moonshot Kimi models
    if (openRouterKeys.length > 0) {
      const kimiModels = [
        'qwen/qwen-2.5-72b-instruct', // fallback as kimi not fully on openrouter
        'qwen/qwen-plus',
      ];

      for (let keyAttempt = 0; keyAttempt < openRouterKeys.length; keyAttempt++) {
        const currentIndex = (activeKimiKeyIndex + keyAttempt) % openRouterKeys.length;
        const currentApiKey = openRouterKeys[currentIndex];

        if (!currentApiKey || currentApiKey.trim().length < 10) continue;

        for (const currentModel of kimiModels) {
          try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              signal: AbortSignal.timeout(22000), // 22s timeout
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentApiKey.trim()}`,
                'HTTP-Referer': 'https://pentagon.ai',
                'X-Title': 'Pentagon AI Assistant',
              },
              body: JSON.stringify({
                model: currentModel,
                messages: truncateMessages(fullMessages, 14000),
                temperature: params.temperature ?? 0.2,
                top_p: 0.7,
                ...(params.maxTokens ? { max_tokens: params.maxTokens } : {}),
                ...(params.responseJson ? { response_format: { type: 'json_object' } } : {}),
              }),
            });

            if (response.ok) {
              const data = await response.json();
              const content = data.choices?.[0]?.message?.content || '';
              if (content.trim()) {
                activeKimiKeyIndex = currentIndex;
                const modelLabel = currentModel.includes('k2.7-code') 
                  ? 'Kimi k2.7 Code' 
                  : (currentModel.includes('k2') ? 'Kimi k2' : 'Kimi Moonshot');
                return { text: content, provider: `${modelLabel} (OpenRouter)` };
              }
            }

            const status = response.status;
            const errText = await response.text();
            
            let msg = errText;
            try { const p = JSON.parse(errText); msg = p?.error?.message || p?.message || errText; } catch(e) {}
            lastError = new Error(`Kimi OpenRouter: ${msg}`);

            // If credit is insufficient (402) or authentication fails (401/403), break to avoid wasting time
            if (status === 401 || status === 402 || status === 403) {
              break;
            }
          } catch (err: any) {
            lastError = err;
            continue;
          }
        }
      }
    }

    if (pref === 'kimi') {
      console.log('[Kimi OpenRouter High-Speed Failover to NVIDIA NIM & Gemini]');
      try {
        const nvFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
        return { text: nvFallback.text, provider: `Kimi k2.7 (${nvFallback.provider})` };
      } catch (e) {
        try {
          const gemFallback = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
          return { text: gemFallback.text, provider: `Kimi k2.7 (${gemFallback.provider})` };
        } catch (e2) {
          throw lastError || new Error('All Kimi endpoints and fallback engines busy.');
        }
      }
    }
  }

  // Universal Ultimate Safety Fallback: If ANY model preference failed (e.g. 503 high load), fallback to guaranteed active NVIDIA NIM / Gemini
  if (pref !== 'auto') {
    console.log(`[Preferred model ${pref} temporarily busy - Triggering Universal Safety Fallback]`);
    try {
      const nvRes = await callAiWithAutoFailover({ ...params, preferredModel: 'nvidia' });
      return { text: nvRes.text, provider: `${pref} (via Fallover: ${nvRes.provider})` };
    } catch (e1) {
      try {
        const gemRes = await callAiWithAutoFailover({ ...params, preferredModel: 'gemini' });
        return { text: gemRes.text, provider: `${pref} (via Fallover: ${gemRes.provider})` };
      } catch (e2) {
        // Will throw lastError below
      }
    }
  }

  throw lastError || new Error('All AI API Keys exhausted across all providers.');
}

// Whisper Transcription Endpoint using Groq API (whisper-large-v3-turbo)
app.post('/api/transcribe', express.raw({ type: 'audio/*', limit: '50mb' }), async (req, res) => {
  try {
    if (!req.body || req.body.length === 0) {
      return res.status(400).json({ error: 'No audio data received' });
    }

    const keys = getGroqKeys();
    if (keys.length === 0) {
      return res.status(500).json({ error: 'No Groq keys configured for Whisper API.' });
    }
    
    // Extract audio MIME type from incoming headers
    const rawContentType = (req.headers['content-type'] as string) || 'audio/webm';
    const mimeType = rawContentType.split(';')[0].trim() || 'audio/webm';
    let ext = 'webm';
    if (mimeType.includes('mp4') || mimeType.includes('m4a')) ext = 'm4a';
    else if (mimeType.includes('wav')) ext = 'wav';
    else if (mimeType.includes('ogg')) ext = 'ogg';
    else if (mimeType.includes('mp3') || mimeType.includes('mpeg')) ext = 'mp3';

    // Convert binary buffer to standard Blob
    const blob = new Blob([req.body], { type: mimeType });
    
    // Groq requires at least 0.01 seconds of audio
    if (blob.size < 800) {
      return res.json({ text: '' }); // Fail gracefully for tiny empty chunks
    }

    let lastError = '';
    // Try across available Groq keys with auto-failover
    for (let attempt = 0; attempt < keys.length; attempt++) {
      const currentApiKey = keys[(activeGroqKeyIndex + attempt) % keys.length];
      
      const formData = new FormData();
      formData.append('file', blob, `audio.${ext}`);
      formData.append('model', 'whisper-large-v3-turbo');
      formData.append('response_format', 'json');
      formData.append('temperature', '0.0');

      try {
        const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${currentApiKey}`
          },
          body: formData
        });
        
        if (response.ok) {
          const data = (await response.json()) as { text?: string };
          activeGroqKeyIndex = (activeGroqKeyIndex + attempt) % keys.length;
          return res.json({ text: data.text || '' });
        } else {
          const status = response.status;
          const errText = await response.text();
          console.error(`[Whisper Groq API Error] HTTP ${status} (key #${(activeGroqKeyIndex + attempt) % keys.length}):`, errText);
          lastError = errText;
          if (status === 429 || status === 401) {
            continue; // Failover to next key in pool
          }
        }
      } catch (reqErr: any) {
        console.error('[Whisper Fetch Error]:', reqErr);
        lastError = reqErr.message;
      }
    }

    return res.status(502).json({ error: `Transcription failed: ${lastError || 'All Groq keys exhausted'}` });
  } catch (error: any) {
    console.error('[Transcription Internal Error]:', error);
    res.status(500).json({ error: error.message || 'Internal server error during transcription' });
  }
});

/**
 * Multimodal OCR using NVIDIA NIM & Gemini with Key Failover & Model Rotation.
 * Works seamlessly with large images, PDFs, camera photos, and documents up to 20MB.
 */
async function performNemotronOcr(base64Raw: string, mimeType: string): Promise<string> {
  const nvidiaKeys = getNvidiaKeys();
  if (nvidiaKeys.length === 0) {
    throw new Error('No NVIDIA API keys available for Nemotron OCR extraction.');
  }

  let cleanBase64 = base64Raw;
  let cleanMime = mimeType || 'image/jpeg';
  if (base64Raw.includes(';base64,')) {
    const parts = base64Raw.split(';base64,');
    cleanMime = parts[0].replace('data:', '') || cleanMime;
    cleanBase64 = parts[1];
  }

  const visionModels = [
    'meta/llama-3.2-11b-vision-instruct',
    'meta/llama-3.2-90b-vision-instruct',
    'microsoft/phi-3.5-vision-instruct'
  ];

  let lastError: any = null;
  // Try available NVIDIA keys
  for (const apiKey of nvidiaKeys) {
    for (const model of visionModels) {
      try {
        const response = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
          method: 'POST',
          signal: AbortSignal.timeout(20000),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey.trim()}`
          },
          body: JSON.stringify({
            model: model,
            messages: [
              {
                role: 'user',
                content: [
                  { type: 'text', text: 'Perform high-precision Optical Character Recognition (OCR) on this document/image. Extract and transcribe ALL text, tables, handwritten notes, numbers, and structural content accurately. Output ONLY the raw extracted transcription text.' },
                  { type: 'image_url', image_url: { url: `data:${cleanMime};base64,${cleanBase64}` } }
                ]
              }
            ],
            max_tokens: 1024,
            temperature: 0.1
          })
        });

        if (response.ok) {
          const data = await response.json();
          const extracted = data.choices?.[0]?.message?.content;
          if (extracted && extracted.trim()) return extracted.trim();
        } else {
          const err = await response.text();
          console.warn(`[NVIDIA OCR ${model}]: HTTP ${response.status} - ${err.slice(0, 100)}`);
        }
      } catch (e) {
        lastError = e;
      }
    }
  }
  throw lastError || new Error('All NVIDIA keys failed for Nemotron OCR.');
}

async function performGeminiOcr(base64Raw: string, mimeType: string): Promise<string> {
  const geminiKeys = getGeminiKeys();
  if (geminiKeys.length === 0) {
    throw new Error('No Gemini API keys available for OCR extraction.');
  }

  let cleanBase64 = base64Raw;
  let cleanMime = mimeType || 'image/jpeg';
  if (base64Raw.includes(';base64,')) {
    const parts = base64Raw.split(';base64,');
    cleanMime = parts[0].replace('data:', '') || cleanMime;
    cleanBase64 = parts[1];
  }

  const models = [
    'gemini-2.5-flash',
    'gemini-2.5-pro',
    'gemini-3.7-flash',
    'gemini-flash-latest',
    'gemini-3.1-flash-lite'
  ];

  let lastError: any = null;

  for (const apiKey of geminiKeys) {
    const ai = new GoogleGenAI({ apiKey: apiKey.trim() });
    for (const model of models) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: cleanMime,
                    data: cleanBase64,
                  }
                },
                {
                  text: 'Perform high-precision Optical Character Recognition (OCR) on this document/image. Extract and transcribe ALL text, tables, headers, handwritten notes, mathematical equations, numbers, and structural content accurately. Output ONLY the raw extracted transcription text without any markdown commentary or intros.'
                }
              ]
            }
          ]
        });

        const extracted = response.text?.trim() || '';
        if (extracted) {
          return extracted;
        }
      } catch (err: any) {
        lastError = err;
        const msg = (err.message || '').toLowerCase();
        // If 429 quota or invalid key, switch to next key
        if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted')) {
          break;
        }
        // otherwise try next model
        continue;
      }
    }
  }

  throw lastError || new Error('Gemini OCR extraction failed across all keys and models.');
}

// OCR Text Extraction Endpoint with Dual-Tier Pipeline:
// 1. Automatic OCR.Space parser (for small files < 1.2MB)
// 2. Seamless Gemini Multimodal OCR Fallback (handles up to 20MB, multi-page PDFs, handwritten text, complex diagrams)
app.post('/api/ocr', async (req, res) => {
  try {
    const { fileBase64, fileName, fileType, language } = req.body;

    if (!fileBase64) {
      return res.status(400).json({ error: 'No file data provided for OCR analysis.' });
    }

    let rawBase64 = fileBase64;
    let detectedMime = fileType || 'image/jpeg';
    if (fileBase64.includes(';base64,')) {
      const parts = fileBase64.split(';base64,');
      detectedMime = parts[0].replace('data:', '') || detectedMime;
      rawBase64 = parts[1];
    }

    const sizeBytes = Buffer.byteLength(rawBase64, 'base64');
    const isOverOcrSpaceLimit = sizeBytes > 1200000; // OCR.space free plan limit is 1.5MB

    // If file is within OCR.space limit, attempt OCR.space first
    if (!isOverOcrSpaceLimit) {
      try {
        const apiKey = getOcrSpaceApiKey();
        const formData = new URLSearchParams();
        formData.append('apikey', apiKey);

        const base64Data = fileBase64.startsWith('data:') 
          ? fileBase64 
          : `data:${detectedMime};base64,${rawBase64}`;

        formData.append('base64Image', base64Data);
        formData.append('language', language || 'eng');
        formData.append('isOverlayRequired', 'false');
        formData.append('detectOrientation', 'true');
        formData.append('scale', 'true');
        formData.append('OCREngine', '2');

        if (detectedMime.toLowerCase().includes('pdf') || fileName?.toLowerCase().endsWith('.pdf')) {
          formData.append('filetype', 'PDF');
        }

        const response = await fetch('https://api.ocr.space/parse/image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: formData.toString(),
          signal: AbortSignal.timeout(20000),
        });

        if (response.ok) {
          const data = await response.json();
          if (!data.IsErroredOnProcessing && data.ParsedResults && data.ParsedResults.length > 0) {
            const extractedTextParts = data.ParsedResults
              .map((p: any) => p.ParsedText || '')
              .filter((t: string) => t.trim().length > 0);

            const fullExtractedText = extractedTextParts.join('\n\n--- Next Page ---\n\n').trim();
            if (fullExtractedText) {
              return res.json({
                success: true,
                text: fullExtractedText,
                fileName: fileName || 'document',
                engine: 'ocr.space',
                pagesCount: data.ParsedResults.length,
              });
            }
          }
        }
      } catch (ocrSpaceErr) {
        console.log('[OCR.Space Warning]: Attempt failed, seamlessly falling back to Gemini Vision OCR...', ocrSpaceErr);
      }
    }

    // High-performance Fallback / Large File Handler: Nemotron OCR (NVIDIA) -> Gemini
    const isPdf = detectedMime.toLowerCase().includes('pdf') || fileName?.toLowerCase().endsWith('.pdf');
    
    if (!isPdf) {
      try {
        console.log(`[OCR Processing] Using Llama 3.2 Vision OCR (meta/llama-3.2-90b-vision-instruct)...`);
        const nemotronText = await performNemotronOcr(rawBase64, detectedMime);
        return res.json({
          success: true,
          text: nemotronText,
          fileName: fileName || 'document',
          engine: 'nvidia-llama-3.2-90b-vision',
          pagesCount: 1,
        });
      } catch (nemotronErr: any) {
        console.log('[Nemotron OCR Warning]: Attempt failed, seamlessly falling back to Gemini Vision OCR...', nemotronErr.message || nemotronErr);
      }
    }
      
    try {
      console.log(`[OCR Processing] Using Gemini Multimodal OCR (File size: ${(sizeBytes / 1024).toFixed(1)} KB)...`);
      const geminiText = await performGeminiOcr(rawBase64, detectedMime);
        return res.json({
          success: true,
          text: geminiText,
          fileName: fileName || 'document',
          engine: 'gemini-multimodal',
          pagesCount: 1,
        });
      } catch (geminiErr: any) {
        console.error('[Gemini OCR Error]:', geminiErr);
        // Fallback safe message so user chat never breaks
        return res.json({
          success: true,
          text: `[Attached Document: ${fileName || 'file'}]`,
          fileName: fileName || 'document',
          engine: 'fallback',
          pagesCount: 1,
        });
      }
  } catch (error: any) {
    console.error('[OCR Internal Error]:', error);
    res.status(500).json({ 
      error: error.message || 'Internal server error during document OCR extraction.' 
    });
  }
});

// Health check & Engine status
app.get('/api/health', (req, res) => {
  const keys = getNvidiaKeys();
  const orKeys = getOpenRouterKeys();
  const groqKeys = getGroqKeys();
  const novitaKeys = getTokenRouterKeys();
  const sambaKeys = getSambanovaKeys();
  const mistralKeys = getMistralKeys();
  const geminiKeys = getGeminiKeys();
  const qwenKeys = getQwenKeys();
  const totalKeys = keys.length + orKeys.length + groqKeys.length + novitaKeys.length + sambaKeys.length + mistralKeys.length + geminiKeys.length + qwenKeys.length;
  
  res.json({ 
    status: 'ok', 
    engine: 'Unified Auto-Failover Engine (Gemini + NVIDIA + OpenRouter + Groq + Novita AI/Grok + Mistral/Claude + Qwen)',
    geminiKeys: geminiKeys.length,
    nvidiaKeys: keys.length,
    openRouterKeys: orKeys.length,
    chatGptKeys: groqKeys.length,
    novitaKeys: novitaKeys.length,
    sambaKeys: sambaKeys.length,
    mistralKeys: mistralKeys.length,
    qwenKeys: qwenKeys.length,
    totalKeys,
    activeGeminiKeyIndex: activeGeminiKeyIndex + 1,
    activeKeyIndex: activeKeyIndex + 1,
    activeOpenRouterKeyIndex: activeOpenRouterKeyIndex + 1,
    activeGroqKeyIndex: activeGroqKeyIndex + 1,
    activeNovitaKeyIndex: activeNovitaKeyIndex + 1,
    activeSambaKeyIndex: activeSambaKeyIndex + 1,
    activeMistralKeyIndex: activeMistralKeyIndex + 1,
    activeQwenKeyIndex: activeQwenKeyIndex + 1,
    timestamp: new Date().toISOString() 
  });
});

// Audio cache for instant playback
const geminiTtsCache = new Map<string, { audioBase64: string; mimeType: string; model?: string }>();

// Gemini 3.1 Flash TTS Audio Synthesis Endpoint
app.post('/api/tts', async (req, res) => {
  const { text, voice } = req.body || {};
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Text parameter is required for TTS synthesis' });
  }

  const cleanedText = text
    .replace(/<suggestions>[\s\S]*?<\/suggestions>/gi, '')
    .replace(/```[\s\S]*?```/g, ' [code block] ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/https?:\/\/[^\s]+/g, '')
    .replace(/\[\d+\]/g, '')
    .replace(/\[(?:source|reference|citation)[^\]]*\]/gi, '')
    .replace(/^#+\s+/gm, '')
    .replace(/^[*+-]\s+/gm, '')
    .replace(/^>\s+/gm, '')
    .replace(/[*_~|]/g, '')
    .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleanedText) {
    return res.status(400).json({ error: 'No readable text for TTS' });
  }

  const voiceName = voice || 'Kore';
  const truncatedText = cleanedText.length > 10000 ? cleanedText.slice(0, 10000) : cleanedText;

  const cacheKey = crypto.createHash('md5').update(`${voiceName}_${truncatedText}`).digest('hex');
  const cached = geminiTtsCache.get(cacheKey);
  if (cached) {
    return res.json({
      success: true,
      audioBase64: cached.audioBase64,
      mimeType: cached.mimeType,
      voice: voiceName,
      model: cached.model || 'cached-tts',
      cached: true
    });
  }

  let finalAudioBase64 = null;
  let mimeType = 'audio/mp3';
  let usedModel = 'unknown';

  // --- 1. Xiaomi Mimo AI TTS (mimo-v2.5-tts) [PRIMARY ULTRA-FAST TTS ENGINE] ---
  const mimoKeys = getMimoKeys();
  if (mimoKeys.length > 0) {
    for (let attempt = 0; attempt < mimoKeys.length; attempt++) {
      const currentApiKey = mimoKeys[(activeMimoKeyIndex + attempt) % mimoKeys.length];
      try {
        // Try Chat Completions format with assistant role (standard Xiaomi Mimo TTS)
        const mimoRes = await fetch('https://api.xiaomimimo.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${currentApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: 'mimo-v2.5-tts',
            messages: [{ role: 'assistant', content: truncatedText }],
            stream: false
          })
        });

        if (mimoRes.ok) {
          const mimoJson = await mimoRes.json() as any;
          if (mimoJson.choices && mimoJson.choices[0] && mimoJson.choices[0].message) {
            let b64Data: string | null = null;
            const msg = mimoJson.choices[0].message;
            if (msg.audio && msg.audio.data) b64Data = msg.audio.data;
            else if (msg.audio && typeof msg.audio === 'string') b64Data = msg.audio;
            else if (msg.content && typeof msg.content === 'string' && msg.content.length > 200) {
              if (msg.content.startsWith('http://') || msg.content.startsWith('https://')) {
                // Fetch direct audio URL if returned
                const audioFileRes = await fetch(msg.content);
                if (audioFileRes.ok) {
                  const arr = await audioFileRes.arrayBuffer();
                  b64Data = Buffer.from(arr).toString('base64');
                }
              } else if (!msg.content.includes(' ') && msg.content.length > 500) {
                b64Data = msg.content;
              }
            }
            
            if (b64Data) {
              finalAudioBase64 = b64Data;
              mimeType = (msg.audio && msg.audio.format) ? `audio/${msg.audio.format}` : 'audio/mp3';
              usedModel = 'mimo-v2.5-tts';
              activeMimoKeyIndex = (activeMimoKeyIndex + attempt) % mimoKeys.length;
              break;
            }
          }
        } else {
          // Also try standard audio speech endpoint if available on Mimo
          try {
            const directSpeechRes = await fetch('https://api.xiaomimimo.com/v1/audio/speech', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${currentApiKey}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                model: 'mimo-v2.5-tts',
                input: truncatedText,
                voice: voiceName || 'alloy',
                response_format: 'mp3'
              })
            });
            if (directSpeechRes.ok) {
              const arrBuffer = await directSpeechRes.arrayBuffer();
              if (arrBuffer.byteLength > 200) {
                finalAudioBase64 = Buffer.from(arrBuffer).toString('base64');
                mimeType = 'audio/mp3';
                usedModel = 'mimo-v2.5-tts';
                activeMimoKeyIndex = (activeMimoKeyIndex + attempt) % mimoKeys.length;
                break;
              }
            }
          } catch (speechErr) {
            // continue
          }

          if (mimoRes.status === 429 || mimoRes.status === 401) {
            continue; // rotate key
          }
        }
      } catch (err) {
        // failover to next key
      }
    }
  }

  // --- 2. Gemini TTS (Fallback) ---
  if (!finalAudioBase64) {
    const geminiKeys = getGeminiKeys();
    if (geminiKeys.length > 0) {
      for (const apiKey of geminiKeys) {
        try {
          const ai = new GoogleGenAI({
            apiKey,
            httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
          });

          const response = await ai.models.generateContent({
            model: 'gemini-3.1-flash-tts-preview',
            contents: [{ role: 'user', parts: [{ text: truncatedText }] }],
            config: {
              speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceName } } }
            }
          });

          if (response && response.candidates && response.candidates.length > 0) {
            const candidate = response.candidates[0];
            const audioPart = candidate.content?.parts?.find(p => p.inlineData && p.inlineData.mimeType.startsWith('audio/'));

            if (audioPart && audioPart.inlineData && audioPart.inlineData.data) {
              let b64 = audioPart.inlineData.data;
              let mType = audioPart.inlineData.mimeType;
              
              // Browsers cannot play raw audio/l16 PCM natively. We must wrap it in a WAV header.
              if (mType.includes('audio/l16') || mType.includes('audio/pcm')) {
                 const sampleRate = mType.includes('rate=16000') ? 16000 : 24000;
                 const rawBuffer = Buffer.from(b64, 'base64');
                 const dataSize = rawBuffer.length;
                 const wav = Buffer.alloc(44 + dataSize);
                 
                 wav.write('RIFF', 0);
                 wav.writeUInt32LE(36 + dataSize, 4);
                 wav.write('WAVE', 8);
                 wav.write('fmt ', 12);
                 wav.writeUInt32LE(16, 16); 
                 wav.writeUInt16LE(1, 20); 
                 wav.writeUInt16LE(1, 22); 
                 wav.writeUInt32LE(sampleRate, 24); 
                 wav.writeUInt32LE(sampleRate * 2, 28); 
                 wav.writeUInt16LE(2, 32); 
                 wav.writeUInt16LE(16, 34); 
                 wav.write('data', 36);
                 wav.writeUInt32LE(dataSize, 40);
                 
                 rawBuffer.copy(wav, 44);
                 b64 = wav.toString('base64');
                 mType = 'audio/wav';
              }

              finalAudioBase64 = b64;
              mimeType = mType;
              usedModel = 'gemini-3.1-flash-tts-preview';
              break;
            }
          }
        } catch (err: any) {
          // Silently skip
        }
      }
    }
  }

  // --- 3. Google Translate TTS (Unlimited Free Fallback) ---
  if (!finalAudioBase64) {
    try {
      // Google TTS has a 200 character limit per request.
      // We will split the text into chunks of up to 200 characters and concatenate the audio.
      const chunks = [];
      let currentChunk = '';
      const words = truncatedText.split(' ');
      
      for (const word of words) {
        if ((currentChunk + ' ' + word).length <= 200) {
          currentChunk += (currentChunk ? ' ' : '') + word;
        } else {
          if (currentChunk) chunks.push(currentChunk);
          // If a single word is somehow > 200 chars, slice it
          if (word.length > 200) {
             let w = word;
             while (w.length > 0) {
                chunks.push(w.slice(0, 200));
                w = w.slice(200);
             }
             currentChunk = '';
          } else {
             currentChunk = word;
          }
        }
      }
      if (currentChunk) chunks.push(currentChunk);

      const audioBuffers = [];
      // Fetch sequentially to avoid rate limiting
      for (const chunk of chunks) {
        const safeText = encodeURIComponent(chunk);
        const gTtsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${safeText}&tl=en&client=tw-ob`;
        const gRes = await fetch(gTtsUrl);
        if (gRes.ok) {
          const arrayBuffer = await gRes.arrayBuffer();
          audioBuffers.push(Buffer.from(arrayBuffer));
        }
      }

      if (audioBuffers.length > 0) {
        const combined = Buffer.concat(audioBuffers);
        finalAudioBase64 = combined.toString('base64');
        mimeType = 'audio/mpeg';
        usedModel = 'google-translate-tts';
      }
    } catch (err) {
      // Silently skip
    }
  }

  if (finalAudioBase64) {
      if (geminiTtsCache.size >= 100) {
        const firstKey = geminiTtsCache.keys().next().value;
        if (firstKey) geminiTtsCache.delete(firstKey);
      }
      geminiTtsCache.set(cacheKey, { audioBase64: finalAudioBase64, mimeType, model: usedModel });

      return res.json({
        success: true,
        audioBase64: finalAudioBase64,
        mimeType: mimeType,
        voice: voiceName,
        model: usedModel
      });
  }

  // If all 3 failed, just return a generic error
  return res.status(500).json({
    error: 'All TTS engines failed',
    details: 'TTS failed'
  });
});

app.post('/api/generate-title', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ title: 'New chat' });
    }

    const systemPrompt = "You are a helpful assistant. Provide a concise, accurate 3-5 word title for a chat session starting with the user's message. Reply ONLY with the title string, no quotes, no extra text.";
    let response;
    try {
      // First try DeepSeek/ChatGPT as requested for speed
      response = await callAiWithAutoFailover({
        messages: [{ role: 'user', content: message }],
        systemPrompt,
        temperature: 0.5,
        maxTokens: 20,
        preferredModel: 'deepseek', 
        responseJson: false
      });
    } catch (e1) {
      try {
        response = await callAiWithAutoFailover({
          messages: [{ role: 'user', content: message }],
          systemPrompt,
          temperature: 0.5,
          maxTokens: 20,
          preferredModel: 'chatgpt', 
          responseJson: false
        });
      } catch (e2) {
        // Ultimate fallback to auto (Gemini) if keys missing
        response = await callAiWithAutoFailover({
          messages: [{ role: 'user', content: message }],
          systemPrompt,
          temperature: 0.5,
          maxTokens: 20,
          preferredModel: 'auto',
          responseJson: false
        });
      }
    }

    let title = response.text.replace(/["*]/g, '').trim();
    if (title.length > 40) title = title.slice(0, 40) + '...';
    // Deepseek sometimes returns things like "Title: something"
    title = title.replace(/^Title:s*/i, '');

    res.json({ title });
  } catch (err) {
    console.error('Title generation error:', err);
    res.json({ title: 'New chat' });
  }
});

export interface DdgResult {
  title: string;
  snippet: string;
  url: string;
  domain: string;
  siteName: string;
  iconUrl: string;
}

function cleanHtmlEntities(str: string): string {
  return str
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanDdgUrl(rawUrl: string): string {
  try {
    if (rawUrl.includes('uddg=')) {
      const match = rawUrl.match(/uddg=([^&]+)/);
      if (match && match[1]) {
        return decodeURIComponent(match[1]);
      }
    }
    if (rawUrl.startsWith('//')) {
      return 'https:' + rawUrl;
    }
    return rawUrl;
  } catch (e) {
    return rawUrl;
  }
}

export async function searchWebImages(query: string, maxImages = 6): Promise<SearchImageItem[]> {
  const images: SearchImageItem[] = [];
  let cleanQuery = query
    .replace(/📄\s*\*\*Attached Document:[\s\S]*/gi, '')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/^(bhai|bahi|hello|hey|search for|search|find|give me|show me|images of|pics of|photo of|tell me about|who is|what is|kya hai|koun hai|mujhe)\s+/ig, '')
    .replace(/(ki image do|ki pic do|ki photo do|ki images|ka photo|ka pic|dikhao|dikhaye|chahiye|do|give|show)\s*$/ig, '')
    .trim();

  if (!cleanQuery) return images;

  // 1. DuckDuckGo Image Search (Unrestricted Web)
  try {
    const res = await fetch(`https://duckduckgo.com/?q=${encodeURIComponent(cleanQuery)}&t=h_&iar=images&iax=images&ia=images`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(5000)
    });
    const html = await res.text();
    const vqdMatch = html.match(/vqd=["']([^"']+)["']/);
    
    if (vqdMatch && vqdMatch[1]) {
      const vqd = vqdMatch[1];
      const imgRes = await fetch(`https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(cleanQuery)}&vqd=${vqd}&f=,,,,,&p=1`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Referer': 'https://duckduckgo.com/'
        },
        signal: AbortSignal.timeout(5000)
      });
      
      if (imgRes.ok) {
        const data = await imgRes.json();
        if (data.results && data.results.length > 0) {
          for (const item of data.results) {
            images.push({
              url: item.image,
              title: item.title || cleanQuery,
              sourceUrl: item.url,
              sourceName: (item.url ? new URL(item.url).hostname.replace('www.', '') : 'Web')
            });
            if (images.length >= maxImages) break;
          }
        }
      }
    }
  } catch (err: any) {
    // DDG image fail
  }

  // 2. Wikipedia Fallback
  if (images.length === 0) {
    try {
      const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(cleanQuery)}&gsrlimit=6&prop=pageimages|info&inprop=url&pithumbsize=800&format=json`;
      const res = await fetch(wikiUrl, {
        headers: { 'User-Agent': 'Pentagon-Search/2.0' },
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.query?.pages) {
          for (const pageId of Object.keys(data.query.pages)) {
            const page = data.query.pages[pageId];
            if (page.thumbnail?.source && !page.thumbnail.source.includes('.svg')) {
              images.push({
                url: page.thumbnail.source,
                title: page.title || cleanQuery,
                sourceUrl: page.fullurl || `https://en.wikipedia.org/?curid=${pageId}`,
                sourceName: 'Wikipedia'
              });
              if (images.length >= maxImages) break;
            }
          }
        }
      }
    } catch (e) {}
  }

  return images.slice(0, maxImages);
}

export async function searchDuckDuckGo(query: string, maxResults = 8): Promise<DdgResult[]> {
  const rawResults: Array<{ title: string; snippet: string; url: string }> = [];
  
  // Clean query from conversational markers, document attachments, and noise
  let cleanQuery = query
    .replace(/📄\s*\*\*Attached Document:[\s\S]*/gi, '')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/^(search for|search|google|find|tell me about|what is|who is|kya hai|batao|bhai|info on|latest news on)\s+/i, '')
    .replace(/[^\w\s\u0600-\u06FF\u0900-\u097F?.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleanQuery) return [];

  // 1. DuckDuckGo HTML Endpoint (Standard Desktop Web Search)
  try {
    const formData = new URLSearchParams();
    formData.append('q', cleanQuery);
    formData.append('b', '');
    formData.append('kl', 'wt-wt');

    const res = await fetch('https://html.duckduckgo.com/html/', {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://html.duckduckgo.com/',
      },
      body: formData.toString(),
      signal: AbortSignal.timeout(7000),
    });

    if (res.ok) {
      const html = await res.text();
      const resultBlockRegex = /<div class="result results_links[^"]*">([\s\S]*?)<\/div>\s*<\/div>/g;
      let match;
      while ((match = resultBlockRegex.exec(html)) !== null && rawResults.length < maxResults) {
        const block = match[1];
        const titleMatch = block.match(/<a class="result__url"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i) ||
                           block.match(/<a class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i) ||
                           block.match(/<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
                           
        const snippetMatch = block.match(/<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/i) ||
                             block.match(/<div class="result__snippet"[^>]*>([\s\S]*?)<\/div>/i);

        if (titleMatch) {
          const rawUrl = titleMatch[1];
          const rawTitle = cleanHtmlEntities(titleMatch[2]);
          const rawSnippet = snippetMatch ? cleanHtmlEntities(snippetMatch[1]) : '';
          const cleanUrl = cleanDdgUrl(rawUrl);

          if (rawTitle && cleanUrl && !cleanUrl.includes('duckduckgo.com/y.js') && !rawResults.some(r => r.url === cleanUrl)) {
            rawResults.push({
              title: rawTitle,
              snippet: rawSnippet,
              url: cleanUrl,
            });
          }
        }
      }

      if (rawResults.length === 0) {
        const generalTitleRegex = /<a class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
        const generalSnippetRegex = /<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi;
        
        const titles: Array<{ url: string; title: string }> = [];
        const snippets: string[] = [];

        let tMatch;
        while ((tMatch = generalTitleRegex.exec(html)) !== null && titles.length < maxResults) {
          titles.push({
            url: cleanDdgUrl(tMatch[1]),
            title: cleanHtmlEntities(tMatch[2])
          });
        }

        let sMatch;
        while ((sMatch = generalSnippetRegex.exec(html)) !== null && snippets.length < maxResults) {
          snippets.push(cleanHtmlEntities(sMatch[1]));
        }

        for (let i = 0; i < titles.length; i++) {
          if (titles[i].title && titles[i].url && !rawResults.some(r => r.url === titles[i].url)) {
            rawResults.push({
              title: titles[i].title,
              url: titles[i].url,
              snippet: snippets[i] || '',
            });
          }
        }
      }
    }
  } catch (err: any) {
    // DuckDuckGo HTML Search silent fallback
  }

  // 2. Wikipedia Live API (Instant Factual encyclopedic grounding for definitions, people, events, places)
  try {
    const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(cleanQuery)}&format=json&utf8=1&srlimit=3`;
    const wikiRes = await fetch(wikiUrl, {
      signal: AbortSignal.timeout(4000),
      headers: { 'User-Agent': 'Pentagon-AI/2.0 (Search Grounding Engine)' }
    });
    if (wikiRes.ok) {
      const wikiData = await wikiRes.json();
      if (wikiData?.query?.search && Array.isArray(wikiData.query.search)) {
        for (const item of wikiData.query.search) {
          const itemTitle = cleanHtmlEntities(item.title);
          const itemSnippet = cleanHtmlEntities(item.snippet);
          const itemUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/\s+/g, '_'))}`;
          if (itemTitle && !rawResults.some(r => r.url === itemUrl)) {
            rawResults.push({
              title: `${itemTitle} - Wikipedia`,
              snippet: itemSnippet,
              url: itemUrl,
            });
          }
        }
      }
    }
  } catch (wikiErr: any) {
    // Wikipedia live search silent fallback
  }

  // 3. DuckDuckGo Instant Answer JSON API
  if (rawResults.length < 3) {
    try {
      const apiRes = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(cleanQuery)}&format=json&no_html=1&skip_disambig=1`, {
        signal: AbortSignal.timeout(5000)
      });
      if (apiRes.ok) {
        const data = await apiRes.json();
        if (data.AbstractText && data.AbstractURL && !rawResults.some(r => r.url === data.AbstractURL)) {
          rawResults.push({
            title: data.Heading || cleanQuery,
            snippet: data.AbstractText,
            url: data.AbstractURL,
          });
        }
        if (Array.isArray(data.RelatedTopics)) {
          for (const topic of data.RelatedTopics.slice(0, maxResults - rawResults.length)) {
            if (topic.Text && topic.FirstURL && !rawResults.some(r => r.url === topic.FirstURL)) {
              rawResults.push({
                title: cleanHtmlEntities(topic.Text.split(' - ')[0] || topic.Text.slice(0, 50)),
                snippet: cleanHtmlEntities(topic.Text),
                url: topic.FirstURL,
              });
            }
          }
        }
      }
    } catch (err: any) {
      console.log('[DuckDuckGo Instant Answer API Warning]:', err.message);
    }
  }

  // 4. DuckDuckGo Lite Fallback
  if (rawResults.length === 0) {
    try {
      const formData = new URLSearchParams();
      formData.append('q', cleanQuery);
      const liteRes = await fetch('https://lite.duckduckgo.com/lite/', {
        method: 'POST',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Content-Type': 'application/x-www-form-urlencoded',
          'Referer': 'https://lite.duckduckgo.com/',
        },
        body: formData.toString(),
        signal: AbortSignal.timeout(6000),
      });

      if (liteRes.ok) {
        const liteHtml = await liteRes.text();
        const linkRegex = /<a class="result-link"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
        const snippetRegex = /<td class="result-snippet">([\s\S]*?)<\/td>/gi;

        const links: Array<{ url: string; title: string }> = [];
        const snips: string[] = [];

        let lMatch;
        while ((lMatch = linkRegex.exec(liteHtml)) !== null && links.length < maxResults) {
          links.push({
            url: cleanDdgUrl(lMatch[1]),
            title: cleanHtmlEntities(lMatch[2])
          });
        }

        let snMatch;
        while ((snMatch = snippetRegex.exec(liteHtml)) !== null && snips.length < maxResults) {
          snips.push(cleanHtmlEntities(snMatch[1]));
        }

        for (let i = 0; i < links.length; i++) {
          if (links[i].url && !rawResults.some(r => r.url === links[i].url)) {
            rawResults.push({
              title: links[i].title,
              url: links[i].url,
              snippet: snips[i] || '',
            });
          }
        }
      }
    } catch (err: any) {
      console.log('[DuckDuckGo Lite Search Warning]:', err.message);
    }
  }

  // Convert raw results to rich DdgResult objects
  const results: DdgResult[] = rawResults.slice(0, maxResults).map(r => {
    const { domain, siteName, iconUrl } = extractDomainAndSiteName(r.url);
    return {
      title: r.title,
      snippet: r.snippet,
      url: r.url,
      domain,
      siteName,
      iconUrl
    };
  });

  return results;
}


app.post('/api/intent', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.json({ status: 'Thinking' });

  try {
    const systemPrompt = "You are a status generator. Based on the user's prompt, reply with a 2-4 word present continuous phrase describing what you are doing (e.g., 'Searching the web', 'Analyzing code', 'Writing email', 'Solving math', 'Translating text', 'Drafting content'). Reply ONLY with the phrase, no quotes or punctuation.";
    
    // Use a fast model like auto/gemini
    const response = await callAiWithAutoFailover({
      messages: [{ role: 'user', content: prompt }],
      systemPrompt,
      temperature: 0.3,
      maxTokens: 10,
      preferredModel: 'auto',
      responseJson: false
    });

    let status = response.text.trim().replace(/["*]/g, '');
    if (status.length > 30) status = 'Thinking';
    return res.json({ status });
  } catch (e) {
    return res.json({ status: 'Thinking' });
  }
});

// Magic AI Prompt Enhancer & Optimizer
app.post('/api/enhance-prompt', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const systemPrompt = `You are a world-class AI Prompt Optimizer and Prompt Engineering Expert.
Your single job is to transform the user's raw prompt/idea into an exceptionally clear, highly effective, fastest-executing, and comprehensive prompt that produces peak-quality responses from AI models.

RULES:
1. Preserve the user's language and vocabulary style (if Roman Urdu / Urdu, refine in Roman Urdu / Urdu; if Hindi / Hinglish, refine in Hindi / Hinglish; if English, English; if Code or Math, keep code/technical details).
2. Clarify ambiguous points, add key instructions (e.g. step-by-step clarity, formatting, edge cases), and remove vague phrasing.
3. Make it direct, actionable, and optimized so AI gives the most thorough yet efficient output without unnecessary fluff.
4. Output ONLY the finalized enhanced prompt text. Never add meta-text, conversational prefixes, quotes, explanations, or "Here is the enhanced prompt:". Just the prompt itself.`;

    const response = await callAiWithAutoFailover({
      messages: [{ role: 'user', content: `Please optimize and enhance the following raw prompt according to your system instructions.\n\n<RAW_PROMPT>\n${prompt.trim()}\n</RAW_PROMPT>` }],
      systemPrompt,
      temperature: 0.3,
      maxTokens: 400,
      preferredModel: 'auto',
      responseJson: false
    });

    let enhanced = (response.text || '').trim();
    enhanced = enhanced.replace(/^["'`]|["'`]$/g, '').trim();
    if (enhanced.toLowerCase().startsWith('enhanced prompt:')) {
      enhanced = enhanced.replace(/^enhanced prompt:\s*/i, '').trim();
    }

    return res.json({
      success: true,
      enhancedPrompt: enhanced || prompt.trim()
    });
  } catch (err: any) {
    console.error('Enhance prompt API error:', err);
    return res.status(500).json({ error: err.message || 'Failed to enhance prompt', enhancedPrompt: prompt });
  }
});



app.post('/api/youtube-transcript', async (req, res) => {
  try {
    const { videoUrl } = req.body;
    if (!videoUrl) return res.status(400).json({ error: 'videoUrl is required' });
    
    // Parse the video URL to extract the ID, since the library expects an ID
    const ytRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
    const ytMatch = videoUrl.match(ytRegex);
    const videoId = ytMatch ? ytMatch[1] : videoUrl;
    
    // Fetch from youtube2text API using the demo key
    const response = await fetch(`https://youtube2text.org/api/transcribe?url=https://www.youtube.com/watch?v=${videoId}`, {
      headers: {
        'x-api-key': 'yt_ee6f65fd07c5095fed2fbdac437542ac3db78bb3a77bd60bdb64b63110d3d18c'
      }
    });

    const data = await response.json();

    if (!response.ok || !data.result || !data.result.content) {
      console.error('youtube2text error:', data);
      return res.status(404).json({ error: 'No transcript available for this video.' });
    }
    
    res.json({ transcript: data.result.content });
  } catch (error) {
    console.error('YouTube transcript error:', error);
    res.status(500).json({ error: (error as any).message || 'Failed to fetch transcript. Please ensure the video has closed captions.' });
  }
});

// YouTube Music & Song Search without API key (Web scraping + strict song filtering)
app.post('/api/youtube-music-search', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query || typeof query !== 'string' || !query.trim()) {
      return res.status(400).json({ error: 'Song query is required' });
    }

    const cleanQuery = query
      .replace(/\[CONNECTOR:.*?\]/gi, '')
      .replace(/^(@music|@ytmusic|@songs|play|search song|listen to|find song|gaana sunao|gana sunao)\s*/i, '')
      .trim();

    if (!cleanQuery) {
      return res.status(400).json({ error: 'Valid song query is required' });
    }

    // Helper: Parse mm:ss to seconds
    const parseDurationSec = (durStr: string): number => {
      if (!durStr) return 210;
      const parts = durStr.split(':').map(Number);
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        return parts[0] * 60 + parts[1];
      }
      if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        return parts[0] * 3600 + parts[1] * 60 + parts[2];
      }
      return 210;
    };

    // Helper: Check if video is strictly a music track and NOT a normal video / vlog / tutorial / gameplay
    const isSongOnly = (title: string, artist: string, durStr: string): boolean => {
      const t = title.toLowerCase();
      const a = artist.toLowerCase();
      const dur = parseDurationSec(durStr);

      // Exclude too long (movies/podcasts > 11 mins) or too short (< 45s shorts)
      if (dur > 660 || (durStr && dur < 45)) return false;

      // Strict blacklist of non-music video keywords
      const bannedWords = [
        'reaction', 'reacting to', 'review', 'vlog', 'gameplay', 'walkthrough',
        'tutorial', 'how to', 'unboxing', 'full movie', 'comedy clip', 'funny clip',
        'funny moments', 'prank', 'interview', 'podcast', 'news', 'episode',
        'season', 'roast', 'status 30 sec', 'short film', 'behind the scene',
        'making of', 'teaser', 'trailer', 'documentary', 'live stream replay'
      ];

      for (const bw of bannedWords) {
        if (t.includes(bw) || a.includes(bw)) return false;
      }

      return true;
    };

    const searchQuery = encodeURIComponent(cleanQuery + ' audio song');
    const tracks: Array<{
      videoId: string;
      title: string;
      artist: string;
      duration?: string;
      thumbnailUrl: string;
      embedUrl: string;
    }> = [];

    // 1. YouTube Direct HTML Scraping (Strict Music Filter)
    try {
      const ytUrl = `https://www.youtube.com/results?search_query=${searchQuery}&sp=EgIQAQ%253D%253D`;
      const response = await fetch(ytUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        },
        signal: AbortSignal.timeout(6000)
      });

      if (response.ok) {
        const html = await response.text();
        const jsonMatch = html.match(/var ytInitialData = ({[\s\S]+?});<\/script>/);
        if (jsonMatch && jsonMatch[1]) {
          try {
            const ytData = JSON.parse(jsonMatch[1]);
            const contents = ytData?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents?.[0]?.itemSectionRenderer?.contents || [];
            
            for (const item of contents) {
              const video = item.videoRenderer;
              if (video && video.videoId) {
                const videoId = video.videoId;
                const title = (video.title?.runs?.[0]?.text || video.title?.accessibility?.accessibilityData?.label || cleanQuery).trim();
                const artist = (video.ownerText?.runs?.[0]?.text || video.longBylineText?.runs?.[0]?.text || 'Official Audio').trim();
                const duration = video.lengthText?.simpleText || '';
                const thumbnailUrl = video.thumbnail?.thumbnails?.[0]?.url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
                
                // Strict song validation
                if (isSongOnly(title, artist, duration)) {
                  // Clean up redundant tags in titles
                  const cleanTitle = title
                    .replace(/\[\s*(?:official\s*(?:video|audio|music\s*video|lyric\s*video|hd|4k)?)\s*\]/gi, '')
                    .replace(/\(\s*(?:official\s*(?:video|audio|music\s*video|lyric\s*video|hd|4k)?)\s*\)/gi, '')
                    .trim();

                  tracks.push({
                    videoId,
                    title: cleanTitle || title,
                    artist,
                    duration,
                    thumbnailUrl,
                    embedUrl: `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`
                  });

                  if (tracks.length >= 5) break;
                }
              }
            }
          } catch (pErr) {
            // Json parse warning
          }
        }
      }
    } catch (e: any) {
      console.log('[YouTube Direct Music Scrape Warning]:', e.message);
    }

    // 2. Fallback: DuckDuckGo Video Scraping (With Music Constraint)
    if (tracks.length === 0) {
      try {
        const ddgUrl = `https://html.duckduckgo.com/html/?q=site:youtube.com/watch+${encodeURIComponent(cleanQuery + ' official audio song')}`;
        const ddgRes = await fetch(ddgUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
          },
          signal: AbortSignal.timeout(6000)
        });
        if (ddgRes.ok) {
          const ddgHtml = await ddgRes.text();
          const regex = /watch\?v=([a-zA-Z0-9_-]{11})/g;
          const seen = new Set<string>();
          let match;
          while ((match = regex.exec(ddgHtml)) !== null && tracks.length < 4) {
            const videoId = match[1];
            if (!seen.has(videoId)) {
              seen.add(videoId);
              tracks.push({
                videoId,
                title: cleanQuery,
                artist: 'Official Audio',
                thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
                embedUrl: `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`
              });
            }
          }
        }
      } catch (ddgErr) {
        // Silent fallback
      }
    }

    if (tracks.length === 0) {
      return res.status(404).json({ error: 'No songs found for: ' + cleanQuery });
    }

    res.json({
      success: true,
      query: cleanQuery,
      tracks
    });
  } catch (err: any) {
    console.error('YouTube music search error:', err);
    res.status(500).json({ error: err.message || 'Failed to search YouTube music.' });
  }
});

app.post('/api/chat', async (req, res) => {
  try {
    const { messages, preferredModel, searchMode, clientTime, clientTimeZone } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages history is required.' });
    }

    // Dynamic Time & Persona Calculation
    const targetModel = preferredModel || 'auto';
    
    // Model Persona Identification dictionary
    const modelIdentities: Record<string, string> = {
      'google/gemini-pro-latest': 'Google Gemini Pro Latest',
      'google/gemini-3.7-flash': 'Google Gemini 3.7 Flash',
      'google/gemini-3.1-flash-lite': 'Google Gemini 3.1 Flash Lite',
      'gemini-pro-latest': 'Google Gemini Pro Latest',
      'gemini-3.7-flash': 'Google Gemini 3.7 Flash',
      'gemini-3.1-flash-lite': 'Google Gemini 3.1 Flash Lite',
      gemini: 'Google Gemini 3.7 Flash',
      nvidia: 'NVIDIA NIM (LLaMA 3 / Nemotron Accelerated)',
      openrouter: 'DeepSeek-V3 / DeepSeek R1',
      'deepseek-v4-flash-latest': 'DeepSeek V4 Flash (OpenRouter)',
      'deepseek-r1': 'DeepSeek R1 Reasoning (OpenRouter)',
      'deepseek-v4-pro': 'DeepSeek V4 Pro (OpenRouter)',
      deepseek: 'DeepSeek-V3 / DeepSeek R1',
      chatgpt: 'OpenAI ChatGPT-4o / GPT-5',
      'openai/gpt-mini-latest': 'OpenAI GPT Mini Latest (OpenRouter)',
      'openai/gpt-latest': 'OpenAI GPT Latest Flagship (OpenRouter)',
      'gpt-mini-latest': 'OpenAI GPT Mini Latest (OpenRouter)',
      'gpt-latest': 'OpenAI GPT Latest Flagship (OpenRouter)',
      'grok-4.5': 'xAI Grok 4.5',
      'grok-4.1-fast': 'xAI Grok 4.1 Fast',
      grok: 'xAI Grok',
      claude: 'Anthropic Claude 3.5 Sonnet / Mistral AI Large',
      'claude-3-opus': 'Anthropic Claude 3 Opus (OpenRouter)',
      'claude-opus': 'Anthropic Claude 3 Opus (OpenRouter)',
      mistral: 'Mistral AI Large',
      meta: 'Meta Llama 4 Maverick (OpenRouter)',
      qwen: 'Alibaba Qwen 2.5',
      'sonar-reasoning-pro': 'Perplexity Sonar Reasoning Pro AI Engine',
      perplexity: 'Perplexity Sonar AI Engine',
      search: 'Google Real-Time Web Search AI Engine',
      heavy: 'Pentagon Heavy (Multi-Model Consensus Super-Intelligence)',
      auto: 'Universal AI Super-Intelligence (Gemini & Multi-Model Engine)'
    };

    const currentIdentity = modelIdentities[targetModel] || 'Advanced AI Assistant';
    const userTimeStr = clientTime || new Date().toLocaleString('en-US', { timeZone: clientTimeZone || 'Asia/Karachi', dateStyle: 'full', timeStyle: 'medium' });

    let searchGrounding = '';
    let searchCitations: string[] = [];
    let searchSources: SearchSourceItem[] = [];
    let searchImages: SearchImageItem[] = [];

    // Real-Time Search Grounding Engine (Multi-Source Fallback Intelligence)
    const isSearchActive = Boolean(searchMode === true || searchMode === 'true' || targetModel === 'search');
    const lastUserMessage = [...messages].reverse().find(m => m.role === 'user')?.content || '';
    let rawQuery = lastUserMessage.split('📄 **Attached Document:')[0].trim();
    rawQuery = rawQuery.replace(/```[\s\S]*?```/g, '').trim();
    if (!rawQuery) rawQuery = lastUserMessage.slice(0, 100);

    const isImageIntent = /(image|photo|pic|picture|wallpaper|show me|dikhao|look like|disha patani|bollywood|actor|actress|heroine|hero|celebrity)/i.test(rawQuery);

    if (isSearchActive || isImageIntent) {
      try {
        const fetchPromises: Promise<any>[] = [];
        
        // Fetch text search only if search mode is active
        if (isSearchActive) {
          fetchPromises.push(searchDuckDuckGo(rawQuery, 8));
        } else {
          fetchPromises.push(Promise.resolve([]));
        }
        
        // Always fetch images if intent is there or search is active
        fetchPromises.push(searchWebImages(rawQuery, 6));

        const [ddgResults, imagesResult] = await Promise.all(fetchPromises);

        searchImages = imagesResult;

        if (ddgResults.length > 0) {
          searchSources = ddgResults.map(r => ({
            title: r.title,
            url: r.url,
            domain: r.domain,
            siteName: r.siteName,
            iconUrl: r.iconUrl,
            snippet: r.snippet
          }));
          searchCitations = ddgResults.map(r => r.siteName || r.title);

          searchGrounding = `\n\n=== 🌐 REAL-TIME LIVE WEB GROUNDING (SEARCH ENGINE RESULTS) ===
Search Query: "${rawQuery}"
Current Timestamp: ${userTimeStr}

${ddgResults.map((r, i) => `[Source ${i + 1}]
Source Name: ${r.siteName}
Title: ${r.title}
URL: ${r.url}
Snippet: ${r.snippet}`).join('\n\n')}
=== END OF SEARCH RESULTS ===

CRITICAL SEARCH GROUNDING INSTRUCTIONS:
1. **Fact-First Accuracy**: You are answering with live Google/Web search grounding active. Integrate the verified live web search results above accurately into your answer.
2. **Zero Fabrication (Bilkul Koi Man-gharat Baat Nahi)**: Do not invent fake narratives, unverified stats, or imaginary stories. If specific details are not in the search results, honestly mention what is known and cite the verified facts.
3. **CLEAN CITATIONS (ABSOLUTELY NO PARENTHESES / BRACKETS AROUND BADGES)**: 
   - Place source citations cleanly at the end of key sentences or paragraphs as direct Markdown links: \`[Source Name](URL)\` (e.g. \`...as reported by [Outlook India](https://www.outlookindia.com/...)\`).
   - **STRICT PROHIBITION**: NEVER enclose citations inside round brackets \`([Source Name](URL))\` or double brackets or \`(Source: ...)\`. Write them directly as plain \`[Source Name](URL)\` with no outer round brackets.
4. **Mirror User Language**: If the user asks in Roman Urdu, Urdu, Hindi, or English, reply naturally and respectfully in that exact language with 100% verified facts.`;
        }
      } catch (ddgErr: any) {
        console.log('Search engine grounding warning in chat route:', ddgErr.message);
      }
    }

    // If search grounding is active, include the verified factual context
    let effectiveSystemPrompt: string | undefined = undefined;
    if (searchGrounding) {
      effectiveSystemPrompt = `Real-time verified web search context:\n${searchGrounding}\n\nPlease incorporate these live web search results accurately to answer the user's query.`;
    }

    const modelToCall = preferredModel || 'auto';

    const { text, provider, citations, sources } = await callAiWithAutoFailover({
      messages,
      systemPrompt: effectiveSystemPrompt,
      temperature: isSearchActive ? 0.3 : 0.7,
      maxTokens: 4000,
      preferredModel: modelToCall,
      responseJson: false,
      searchMode: isSearchActive
    });

    const finalProvider = isSearchActive 
      ? (provider.includes('Web Search') ? provider : `${provider} (Live Search)`)
      : provider;
    
    // Combine sources from grounding tool and failover pool
    const combinedSources: SearchSourceItem[] = [];
    const seenUrls = new Set<string>();

    if (sources && sources.length > 0) {
      for (const s of sources) {
        if (!seenUrls.has(s.url)) {
          seenUrls.add(s.url);
          combinedSources.push(s);
        }
      }
    }
    if (searchSources && searchSources.length > 0) {
      for (const s of searchSources) {
        if (!seenUrls.has(s.url)) {
          seenUrls.add(s.url);
          combinedSources.push(s);
        }
      }
    }

    const finalCitations = combinedSources.length > 0 
      ? combinedSources.map(s => s.siteName || s.title)
      : ((searchCitations && searchCitations.length > 0) ? searchCitations : citations);

    let extractedSuggestions = undefined;
    let finalResponseText = text;

    const suggestionsMatch = text.match(/<suggestions>(.*?)<\/suggestions>/s);
    if (suggestionsMatch) {
      try {
        let cleanJsonStr = suggestionsMatch[1].trim();
        if (cleanJsonStr.startsWith('```')) {
          cleanJsonStr = cleanJsonStr.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
        }
        const rawArr = JSON.parse(cleanJsonStr);
        if (Array.isArray(rawArr) && rawArr.length > 0) {
          extractedSuggestions = rawArr.slice(0, 4);
        }
      } catch (e) {
        console.error("Failed to parse suggestions JSON:", e);
      }
      finalResponseText = text.replace(/<suggestions>.*?<\/suggestions>/s, '').trim();
    }

    // Sanitize any accidental brackets/parentheses wrapping citation links
    finalResponseText = finalResponseText
      .replace(/\(\s*(\[[^\]]+\]\([^)]+\))\s*\)/g, ' $1')
      .replace(/\[\s*(\[[^\]]+\]\([^)]+\))\s*\]/g, ' $1')
      .replace(/\(\s*Sources?:\s*(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1')
      .replace(/\(\s*Source\s*(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1')
      .replace(/\(\s*see\s+(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1');

    res.json({
      success: true,
      reply: finalResponseText,
      provider: finalProvider,
      citations: finalCitations,
      sources: combinedSources.length > 0 ? combinedSources : undefined,
      images: searchImages.length > 0 ? searchImages : undefined,
      suggestions: extractedSuggestions
    });

  } catch (error: any) {
    console.log('Agent failover:', error);
    let errorMessage = error.message || 'Failed to process AI request';
    if (errorMessage.toLowerCase().includes('timeout') || errorMessage.toLowerCase().includes('aborted')) {
      errorMessage = 'The AI model took too long to respond (timeout). Please try again or switch to a faster model.';
    }
    res.status(500).json({ 
      error: errorMessage, 
      details: error.message 
    });
  }
});


  // --- AI LaTeX Pentagon API ---
  app.post('/api/latex/pentagon', async (req, res) => {
    try {
      const { action, latexCode, prompt } = req.body;
      
      if (!action) {
        return res.status(400).json({ error: 'Action is required.' });
      }

      let systemPrompt = "You are Pentagon, an expert LaTeX academic assistant.";
      let userMessage = "";

      if (action === 'debug') {
        systemPrompt += " Find and fix the syntax errors in the provided LaTeX code. Return ONLY the corrected LaTeX code without markdown blocks unless necessary.";
        userMessage = `Here is the LaTeX code with errors:\n\n${latexCode}`;
      } else if (action === 'format') {
        systemPrompt += " Format and beautify the provided LaTeX code, adhering to academic standards. Return ONLY the formatted LaTeX code.";
        userMessage = `Format this LaTeX code:\n\n${latexCode}`;
      } else if (action === 'add-citations') {
        systemPrompt += " Add placeholder citations or refine bibliography structure in the LaTeX code where appropriate. Return the updated LaTeX.";
        userMessage = `Add citations/bibliography placeholders to this:\n\n${latexCode}`;
      } else if (action === 'convert-notes') {
        systemPrompt += " Convert the provided raw notes/markdown into a well-structured LaTeX document. Return ONLY the LaTeX code.";
        userMessage = `Convert these notes to LaTeX:\n\n${prompt}`;
      } else if (action === 'custom') {
        systemPrompt += " You must fulfill the user's custom instruction regarding their LaTeX code. Return the generated LaTeX snippet.";
        userMessage = `Instruction: ${prompt}\n\nLaTeX Code:\n${latexCode || 'N/A'}`;
      } else {
        return res.status(400).json({ error: 'Invalid action.' });
      }

      const aiResponse = await callAiWithAutoFailover({
        messages: [{ role: 'user', content: userMessage }],
        systemPrompt,
        temperature: 0.2,
        maxTokens: 2000,
        preferredModel: 'gemini',
        responseJson: false
      });

      let finalResult = aiResponse.text || '';
      finalResult = finalResult.replace(/^\s*```(latex)?\s*/gi, '').replace(/\s*```\s*$/gi, '').trim();

      return res.json({ result: finalResult });
    } catch (error: any) {
      console.error('LaTeX Pentagon API Error:', error);
      return res.status(500).json({ error: error.message || 'Failed to process LaTeX command.' });
    }
  });

async function startServer() {
  // Vite middleware for development
  const isProduction = process.env.NODE_ENV === 'production' || (process.argv[1] && process.argv[1].endsWith('server.cjs'));
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Chat Server running on http://0.0.0.0:${PORT}`);
    // silenced failover
  });
}

startServer();
