const fs = require('fs');

let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Replace Text Colors
content = content.replace(/text-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, 'text-[#323130]');
content = content.replace(/text-(?:blue|indigo|cyan|sky)-\d+/g, 'text-[#0078D4]');
content = content.replace(/text-(?:emerald|green|teal)-\d+/g, 'text-[#107C10]');
content = content.replace(/text-(?:red|rose|pink)-\d+/g, 'text-[#D13438]');
content = content.replace(/text-(?:amber|yellow|orange)-\d+/g, 'text-[#323130]'); // Map to dark text
content = content.replace(/text-\[\#323130\]\/(\d+)/g, 'text-[#323130]/$1'); // Preserve any opacities if they exist

// Replace Background Colors
// Main background classes to White
content = content.replace(/bg-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|black)/g, 'bg-[#FFFFFF]');
content = content.replace(/bg-white/g, 'bg-[#FFFFFF]');

// Glass/Accent Backgrounds (Primary Blue)
content = content.replace(/bg-(?:blue|indigo|cyan|sky)-\d+/g, 'bg-[#0078D4]');
// We will manually fix hover/glass effects by adding opacity modifiers or replacing specific ones.

// Success/Alert Backgrounds
content = content.replace(/bg-(?:emerald|green|teal)-\d+/g, 'bg-[#107C10]');
content = content.replace(/bg-(?:red|rose|pink)-\d+/g, 'bg-[#D13438]');
content = content.replace(/bg-(?:amber|yellow|orange)-\d+/g, 'bg-[#FFFFFF]');

// Replace Border Colors
content = content.replace(/border-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, 'border-[#323130]/15');
content = content.replace(/border-(?:blue|indigo|cyan|sky)-\d+/g, 'border-[#0078D4]');
content = content.replace(/border-(?:emerald|green|teal)-\d+/g, 'border-[#107C10]');
content = content.replace(/border-(?:red|rose|pink)-\d+/g, 'border-[#D13438]');

// Ring Colors
content = content.replace(/ring-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, 'ring-[#323130]/20');
content = content.replace(/ring-(?:blue|indigo|cyan|sky)-\d+/g, 'ring-[#0078D4]');

// Fill / Stroke
content = content.replace(/fill-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, 'fill-[#323130]');
content = content.replace(/stroke-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, 'stroke-[#323130]');


// Fixes for hierarchy (We don't want literally EVERYTHING white without distinction)
// So let's make sure things like 'hover:bg-[#FFFFFF]' on buttons that are already white get a subtle gray.
// But wait, the user said "White - Background ke liye, taaki text aur icons clearly visible rahen"
// If we replace ALL grays with White, we lose hover states and secondary cards.
// We can use `#323130`/5 or `#323130`/10 for secondary backgrounds.

fs.writeFileSync('src/components/AiAgentChat.tsx.tmp', content, 'utf8');
