const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Fix User Message Bubble (from bg-[#FFFFFF] to bg-[#0078D4])
// Find the div containing textToDisplay for user messages.
content = content.replace(/className="bg-\[\#FFFFFF\] text-\[\#323130\](?=\s+rounded-\[22px\] px-5 py-3)/g, 'className="bg-[#0078D4] text-[#FFFFFF]"');

// Fix input area background
// It might be white too, which is fine, but maybe add a border or slightly different bg? No, white bg + border is fine.
// Ensure main bg is #FFFFFF and texts are #323130.

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
