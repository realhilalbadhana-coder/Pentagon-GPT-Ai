const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

content = content.replace(/Claude 3\.5 Sonnet/g, 'Sonnet 5');
content = content.replace(/NVIDIA Nemotron Ultra 550B/g, 'NVIDIA Nemotron Ultra');
content = content.replace(/\(Free\)/ig, '');
content = content.replace(/:free/ig, ''); // just in case it's in the display name, but we shouldn't change the ID if it breaks things.

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
