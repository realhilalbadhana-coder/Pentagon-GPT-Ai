const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// The sidebar mapping starts with:
// {[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).sort((a, b) => {
const target = '{[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).sort((a, b) => {';
const replacement = '{[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).filter(s => !(isTemporary && s.id === currentSessionId)).sort((a, b) => {';

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/AiAgentChat.tsx', code);
  console.log('Successfully patched sidebar to hide active incognito chat');
} else {
  console.log('Could not find sidebar target');
}
