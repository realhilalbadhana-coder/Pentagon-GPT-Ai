const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const target1 = `<MessageCircleDashed className={\`w-3.5 h-3.5 \${isTemporary ? 'text-white' : 'text-gray-500'}\`} />
              <span>Temporary</span>`;
const replacement1 = `<img src="https://assets.streamlinehq.com/image/private/w_300,h_300,ar_1/f_auto/v1/icons/programming/incognito-mode-1zc89s3cpkne0tlowp0dco.png/incognito-mode-ccox9jk0t5anw3q5sea1ji.png?_a=DATAiZAAZAA0" alt="Incognito" className={\`w-3.5 h-3.5 object-contain \${isTemporary ? 'invert dark:invert' : 'dark:invert opacity-70'}\`} />
              <span>Incognito</span>`;

code = code.replace(target1, replacement1);

const target2 = `title="Temporary chat (not saved to history)"`;
const replacement2 = `title="Incognito chat (not saved to history)"`;

code = code.replace(target2, replacement2);

const target3 = `<h2 className="text-3xl font-bold text-[#1A1A1A] dark:text-white mb-3">Temporary chat</h2>`;
const replacement3 = `<h2 className="text-3xl font-bold text-[#1A1A1A] dark:text-white mb-3">Incognito</h2>`;

code = code.replace(target3, replacement3);

const target4 = `{/* Temporary Chat Toggle: Visible on home/empty chat OR when temporary mode is on */}`;
const replacement4 = `{/* Incognito Chat Toggle: Visible on home/empty chat OR when incognito mode is on */}`;
code = code.replace(target4, replacement4);

fs.writeFileSync('src/components/AiAgentChat.tsx', code);
console.log('Patched Incognito UI');
