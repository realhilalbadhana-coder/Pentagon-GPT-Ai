const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const dictationHook = `
  const {
    isListening: isDictating,
    isTranscribing: isDictatingTranscribing,
    startListening: startDictating,
    stopListening: stopDictating
  } = useSpeechRecognition({
    onTranscriptUpdate: (fullText) => {
      setInput(fullText);
    }
  });

  const toggleDictation = () => {
    if (isDictating) {
      stopDictating();
    } else {
      startDictating(input);
    }
  };
`;

code = code.replace(
  "  const toggleMicListening = () => {",
  dictationHook + "\n  const toggleMicListening = () => {"
);

fs.writeFileSync('src/components/AiAgentChat.tsx', code, 'utf8');
