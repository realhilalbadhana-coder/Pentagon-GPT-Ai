const fs = require('fs');
let content = fs.readFileSync('src/components/ModelLogos.tsx', 'utf8');

// Add progem URL and update gemini URL
content = content.replace(
  /gemini: 'https:\/\/ik\.imagekit\.io\/j33n0ehll\/gemini',/g, 
  "gemini: 'https://ik.imagekit.io/j33n0ehll/Gem',\n  progem: 'https://ik.imagekit.io/j33n0ehll/progem',"
);

// Define GeminiProLogo
const geminiProComponent = `export const GeminiProLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.progem} 
    alt="Google Gemini Pro" 
    className={\`\${className} object-contain inline-block shrink-0\`} 
    referrerPolicy="no-referrer"
  />
);

// 1. Google Gemini Official Logo`;

content = content.replace(/\/\/ 1\. Google Gemini Official Logo/g, geminiProComponent);

// Add dispatcher condition for gemini-pro-latest
const dispatcherCondition = `  if (m === 'google/gemini-pro-latest' || m === 'gemini-pro-latest') {
    return <GeminiProLogo className={className} />;
  }
  if (m.includes('gemini') || m.includes('google')) {`;

content = content.replace(/  if \(m\.includes\('gemini'\) \|\| m\.includes\('google'\)\) \{/g, dispatcherCondition);

fs.writeFileSync('src/components/ModelLogos.tsx', content, 'utf8');
