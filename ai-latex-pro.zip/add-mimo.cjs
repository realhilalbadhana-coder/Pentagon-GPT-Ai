const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

content = content.replace(/\| 'Open Source';/g, "| 'Open Source'\n  | 'Xiaomi';");
content = content.replace(/{ id: 'Open Source', label: 'Open Source' },/g, "{ id: 'Open Source', label: 'Open Source' },\n  { id: 'Xiaomi', label: 'Xiaomi' },");

const mimoModels = `
  {
    id: 'mimo-v2.5-pro',
    name: 'Xiaomi MiMo V2.5 Pro',
    tagline: 'Flagship multilingual reasoning',
    group: 'engines',
    provider: 'Xiaomi',
    renderIcon: () => <ModelLogo model="mimo-v2.5-pro" className="w-5 h-5" />,
  },
  {
    id: 'mimo-v2.5',
    name: 'Xiaomi MiMo V2.5',
    tagline: 'High-speed reasoning',
    group: 'engines',
    provider: 'Xiaomi',
    renderIcon: () => <ModelLogo model="mimo-v2.5" className="w-5 h-5" />,
  },`;

content = content.replace(/const ALL_MODELS: ModelOption\[\] = \[/g, `const ALL_MODELS: ModelOption[] = [${mimoModels}`);

content = content.replace(/const LATEST_IDS = \[/g, `const LATEST_IDS = [\n    'mimo-v2.5-pro',\n    'mimo-v2.5',`);

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
