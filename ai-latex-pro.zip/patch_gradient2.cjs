const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const targetClosing = '                  )}\n                </div>\n              </div>\n            </div>\n          </div>\n      </main>';

if (code.includes(targetClosing)) {
  const replacementClosing = '                  )}\n                </div>\n              </div>\n            </div>\n          </div>\n          </div>\n      </main>';
  code = code.replace(targetClosing, replacementClosing);
  fs.writeFileSync('src/components/AiAgentChat.tsx', code);
  console.log('Successfully patched AiAgentChat.tsx ending tags');
} else {
  console.log('Could not find closing target');
}
