export async function searchDuckDuckGo(query: string, maxResults = 8) {
  const rawResults: Array<{ title: string; snippet: string; url: string }> = [];
  let cleanQuery = query.trim();

  // 1. DuckDuckGo HTML Endpoint (Standard Desktop Web Search)
  try {
    const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(cleanQuery)}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
      }
    });
    
    if (res.ok) {
      const html = await res.text();
      const resultBlocks = html.split('class="result ');
      
      for (let i = 1; i < resultBlocks.length; i++) {
        const block = resultBlocks[i];
        
        const titleMatch = block.match(/<a class="result__url" href="[^"]*">([^<]+)<\/a>/i) || 
                           block.match(/<a class="result__snippet[^"]*"[^>]*>(.*?)<\/a>/i);
        const snippetMatch = block.match(/<a class="result__snippet[^"]*"[^>]*>(.*?)<\/a>/i);
        const urlMatch = block.match(/<a class="result__url" href="([^"]*)">/i);

        if (titleMatch && snippetMatch && urlMatch) {
          const title = titleMatch[1].replace(/<[^>]+>/g, '').trim();
          const snippet = snippetMatch[1].replace(/<[^>]+>/g, '').trim();
          let rawUrl = urlMatch[1];
          if (rawUrl.startsWith('//')) {
             rawUrl = 'https:' + rawUrl;
          } else if (rawUrl.startsWith('/url?q=')) {
             rawUrl = decodeURIComponent(rawUrl.split('/url?q=')[1].split('&')[0]);
          }
          
          if (title && snippet && rawUrl) {
            rawResults.push({ title, snippet, url: rawUrl });
          }
        }
      }
    }
  } catch (err: any) {}
  
  if(rawResults.length === 0) {
    console.log("Empty results, trying lite...");
  }
  return rawResults.slice(0, maxResults);
}

searchDuckDuckGo("disha patani news").then(r => console.log(r));
