import fs from 'fs';
import dotenv from 'dotenv';
dotenv.config();
const groqKeys = (process.env.GROQ_API_KEYS || process.env.GROQ_API_KEY || '').split(',').map(k => k.trim()).filter(k => k);
if (groqKeys.length > 0) {
  fetch('https://api.groq.com/openai/v1/models', {
    headers: { 'Authorization': `Bearer ${groqKeys[0]}` }
  }).then(r => r.json()).then(d => {
    if (d.data) {
      console.log(d.data.map(m => m.id).join('\\n'));
    } else {
      console.log('Error', d);
    }
  });
} else {
  console.log('No Groq keys');
}
