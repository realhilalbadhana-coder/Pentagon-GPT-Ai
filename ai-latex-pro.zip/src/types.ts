export type LayoutType = 'two-column' | 'single-column';

export type PaperCategory = 
  | 'conference' 
  | 'journal' 
  | 'preprint' 
  | 'thesis' 
  | 'report' 
  | 'cv' 
  | 'math';

export interface LatexTemplate {
  id: string;
  name: string;
  category: PaperCategory;
  description: string;
  layout: LayoutType;
  docClass: string;
  tags: string[];
  code: string;
}

export interface LintIssue {
  line: number;
  type: 'error' | 'warning' | 'suggestion';
  message: string;
  fix?: string;
}

export interface ParsedSection {
  id: string;
  title: string;
  level: 1 | 2 | 3;
  numberString?: string;
  content: string;
}

export interface DocumentMetadata {
  title: string;
  authors: string;
  affiliation?: string;
  date?: string;
  abstract?: string;
  keywords?: string[];
  docClass?: string;
}

export interface EditorSettings {
  fontSize: number;
  autoCompile: boolean;
  twoColumnPreview: boolean;
  showPageMarginGuides: boolean;
  zoomLevel: number;
  theme: 'dark' | 'light' | 'academic';
}

export interface AiGenerationParams {
  topic: string;
  paperType: string;
  authors: string;
  institution: string;
  abstractPrompt?: string;
  keywords: string;
  mathDensity: 'low' | 'medium' | 'high' | 'ultra';
  numSections: number;
  additionalInstructions?: string;
}

export interface AttachedDoc {
  id: string;
  name: string;
  size: number;
  type: string;
  previewUrl?: string;
  extractedText?: string;
  status: 'processing' | 'ready' | 'error';
  errorMessage?: string;
}

export interface SearchSource {
  title: string;
  url: string;
  domain: string;
  siteName: string;
  iconUrl: string;
  snippet?: string;
}

export interface SearchImage {
  url: string;
  title: string;
  sourceUrl: string;
  sourceName: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  displayContent?: string;
  attachments?: AttachedDoc[];
  timestamp: string;
  updatedLatex?: string;
  snippet?: string;
  actionTaken?: string | null;
  emailDraft?: { to: string, subject: string, body: string };
  isApplied?: boolean;
  model?: string;
  thinkingSteps?: string[];
  feedback?: 'up' | 'down';
  isStopped?: boolean;
  citations?: string[];
  sources?: SearchSource[];
  images?: SearchImage[];
  suggestions?: string[];
  connector?: string;
  comparisonResults?: any[];
  musicTracks?: Array<{
    videoId: string;
    title: string;
    artist: string;
    duration?: string;
    thumbnailUrl: string;
    embedUrl: string;
  }>;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  model?: string;
  preferredModel?: string;
  createdAt: number;
  updatedAt: number;
  isPinned?: boolean;
  projectId?: string;
}

export interface UserProfile {
  name: string;
  dob: string;
  onboardedAt: number;
}

export interface ExportOptions {
  format: 'pdf-direct' | 'pdf-canvas' | 'tex' | 'zip' | 'bib';
  paperSize: 'a4' | 'letter';
  includeCoverPage: boolean;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
}

export type TaskCategory = 'academic' | 'latex' | 'personal' | 'timer' | 'urgent';

export interface ScheduledTask {
  id: string;
  title: string;
  description?: string;
  scheduledTime: number; // timestamp in ms
  timeLabel: string; // e.g. "9:10 PM", "Tomorrow 8:00 AM"
  category: TaskCategory;
  soundEnabled: boolean;
  systemNotification: boolean;
  status: 'pending' | 'triggered' | 'completed' | 'snoozed';
  createdAt: number;
  triggeredAt?: number;
  sessionId?: string;
}
