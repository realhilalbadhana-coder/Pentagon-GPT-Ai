import { initializeApp, getApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  signInWithCredential,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
  GoogleAuthProvider, 
  GithubAuthProvider, 
  OAuthProvider,
  onAuthStateChanged, 
  User, 
  signOut 
} from 'firebase/auth';
import { 
  getFirestore, 
  initializeFirestore,
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy, 
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { ChatSession, Project, UserProfile } from '../types';

// Initialize Firebase App
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firestore (with long polling auto-detect to ensure rock-solid connection inside iframe/proxy environments)
const dbId = (firebaseConfig as any).firestoreDatabaseId && (firebaseConfig as any).firestoreDatabaseId !== '(default)'
  ? (firebaseConfig as any).firestoreDatabaseId
  : undefined;

let firestoreInstance;
try {
  firestoreInstance = initializeFirestore(app, {
    experimentalAutoDetectLongPolling: true,
  }, dbId);
} catch {
  firestoreInstance = dbId ? getFirestore(app, dbId) : getFirestore(app);
}

export const db = firestoreInstance;

// Configure Google Provider for standard authentication (email + profile)
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Configure GitHub Provider
export const githubProvider = new GithubAuthProvider();
githubProvider.addScope('read:user');
githubProvider.addScope('user:email');

// Configure Microsoft Provider
export const microsoftProvider = new OAuthProvider('microsoft.com');
microsoftProvider.setCustomParameters({
  prompt: 'select_account',
});

let cachedAccessToken: string | null = null;
let activeAuthPromise: Promise<{ user: User | null; accessToken: string | null }> | null = null;

/**
 * Sign in using Google ID Token (from Google Identity Services One Tap / Bottom Sheet)
 */
export const signInWithGoogleIdToken = async (idToken: string): Promise<{ user: User; accessToken: string | null }> => {
  try {
    const credential = GoogleAuthProvider.credential(idToken);
    const result = await signInWithCredential(auth, credential);
    
    if (result.user) {
      await saveUserProfileToFirestore(result.user);
    }
    return { user: result.user, accessToken: null };
  } catch (error: any) {
    if (error?.code !== 'auth/popup-closed-by-user' && error?.code !== 'auth/cancelled-popup-request') {
      console.warn('[Firebase Auth] Google One Tap Sign in error:', error);
    }
    throw error;
  }
};

/**
 * Render native Google Identity Services embedded button with Account Chooser UI
 */
export const renderGoogleSignInButton = (
  element: HTMLElement,
  onSuccess?: (user: User) => void,
  options: {
    theme?: 'outline' | 'filled_blue' | 'filled_black';
    size?: 'large' | 'medium' | 'small';
    text?: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
    shape?: 'rectangular' | 'pill' | 'circle' | 'square';
    width?: string;
  } = {}
): boolean => {
  if (typeof window === 'undefined' || !element) return false;

  const clientId = (firebaseConfig as any).oAuthClientId;
  if (!clientId) return false;

  const tryRender = () => {
    const google = (window as any).google;
    if (google?.accounts?.id) {
      try {
        google.accounts.id.initialize({
          client_id: clientId,
          callback: async (response: any) => {
            if (response?.credential) {
              try {
                const res = await signInWithGoogleIdToken(response.credential);
                if (res.user && onSuccess) {
                  onSuccess(res.user);
                }
              } catch (err) {
                console.warn('[Google Identity Services] Auth error:', err);
              }
            }
          },
          auto_select: false,
          cancel_on_tap_outside: true,
          itp_support: true,
          use_fedcm_for_prompt: false,
        });

        // Render official embedded Google button inside element
        google.accounts.id.renderButton(element, {
          type: 'standard',
          theme: options.theme || 'outline',
          size: options.size || 'large',
          text: options.text || 'continue_with',
          shape: options.shape || 'rectangular',
          logo_alignment: 'left',
          width: options.width || (element.clientWidth ? `${element.clientWidth}` : '320'),
        });
        return true;
      } catch (err) {
        console.warn('[Google Identity Services] Render button error:', err);
        return false;
      }
    }
    return false;
  };

  if ((window as any).google?.accounts?.id) {
    return tryRender();
  } else {
    const interval = setInterval(() => {
      if ((window as any).google?.accounts?.id) {
        clearInterval(interval);
        tryRender();
      }
    }, 200);
    setTimeout(() => clearInterval(interval), 4000);
    return false;
  }
};

/**
 * Initialize Google One Tap / In-App Bottom Sheet Prompt safely
 */
export const initGoogleOneTap = (onSuccess?: (user: User) => void): void => {
  if (typeof window === 'undefined') return;
  
  // If running inside an iframe, browsers restrict FedCM / Identity Credentials
  const isInIframe = window.self !== window.top;
  if (isInIframe) {
    return;
  }

  const clientId = (firebaseConfig as any).oAuthClientId;
  if (!clientId) return;

  const tryInit = () => {
    const google = (window as any).google;
    if (google?.accounts?.id) {
      try {
        google.accounts.id.initialize({
          client_id: clientId,
          callback: async (response: any) => {
            if (response?.credential) {
              try {
                const res = await signInWithGoogleIdToken(response.credential);
                if (res.user && onSuccess) {
                  onSuccess(res.user);
                }
              } catch (err) {
                console.warn('[Google One Tap] Auth error:', err);
              }
            }
          },
          auto_select: false,
          cancel_on_tap_outside: true,
          itp_support: true,
          use_fedcm_for_prompt: false,
        });

        // Trigger in-app One Tap bottom sheet
        google.accounts.id.prompt((notification: any) => {
          if (notification.isNotDisplayed?.()) {
            // Silently ignore expected reasons in sandboxed environments
          } else if (notification.isSkippedMoment?.()) {
            // Silently ignore skipped
          }
        });
      } catch (err) {
        // Silently catch GSI initializations in unsupported frames
      }
    }
  };

  if ((window as any).google?.accounts?.id) {
    tryInit();
  } else {
    // Wait for script to load
    const interval = setInterval(() => {
      if ((window as any).google?.accounts?.id) {
        clearInterval(interval);
        tryInit();
      }
    }, 250);
    setTimeout(() => clearInterval(interval), 3000);
  }
};

/**
 * Helper to execute auth popup safely without collision
 */
const executeAuthWithPopup = async (
  providerName: string,
  provider: GoogleAuthProvider | GithubAuthProvider | OAuthProvider
): Promise<{ user: User; accessToken: string | null }> => {
  if (activeAuthPromise) {
    // Return the active ongoing popup attempt instead of opening colliding popups
    return activeAuthPromise as Promise<{ user: User; accessToken: string | null }>;
  }

  activeAuthPromise = (async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      
      let token: string | null = null;
      if (provider instanceof GoogleAuthProvider) {
        const credential = GoogleAuthProvider.credentialFromResult(result);
        token = credential?.accessToken || null;
      } else if (provider instanceof GithubAuthProvider) {
        const credential = GithubAuthProvider.credentialFromResult(result);
        token = credential?.accessToken || null;
      } else if (provider instanceof OAuthProvider) {
        const credential = OAuthProvider.credentialFromResult(result);
        token = credential?.accessToken || null;
      }

      cachedAccessToken = token;

      if (result.user) {
        await saveUserProfileToFirestore(result.user);
      }

      return { user: result.user, accessToken: cachedAccessToken };
    } catch (error: any) {
      // Suppress normal user cancellation logs
      if (
        error?.code === 'auth/cancelled-popup-request' ||
        error?.code === 'auth/popup-closed-by-user' ||
        error?.code === 'auth/user-cancelled'
      ) {
        console.info(`[Firebase Auth] ${providerName} popup was closed or superseded.`);
      } else {
        console.error(`[Firebase Auth] ${providerName} sign in error:`, error);
      }
      throw error;
    } finally {
      activeAuthPromise = null;
    }
  })();

  return activeAuthPromise as Promise<{ user: User; accessToken: string | null }>;
};

/**
 * Google Sign In with Popup
 */
export const signInWithGoogle = async (): Promise<{ user: User; accessToken: string | null }> => {
  return executeAuthWithPopup('Google', googleProvider);
};

/**
 * GitHub Sign In with Popup
 */
export const signInWithGithub = async (): Promise<{ user: User; accessToken: string | null }> => {
  return executeAuthWithPopup('GitHub', githubProvider);
};

/**
 * Microsoft Sign In with Popup
 */
export const signInWithMicrosoft = async (): Promise<{ user: User; accessToken: string | null }> => {
  return executeAuthWithPopup('Microsoft', microsoftProvider);
};

/**
 * Email & Password Sign In (100% In-App, Zero Redirection)
 */
export const signInWithEmailPassword = async (email: string, password: string): Promise<{ user: User }> => {
  try {
    const res = await signInWithEmailAndPassword(auth, email, password);
    if (res.user) {
      await saveUserProfileToFirestore(res.user);
    }
    return { user: res.user };
  } catch (error: any) {
    console.error('[Firebase Auth] Email sign in error:', error);
    throw error;
  }
};

/**
 * Email & Password Sign Up (100% In-App, Zero Redirection)
 */
export const signUpWithEmailPassword = async (email: string, password: string, displayName?: string): Promise<{ user: User }> => {
  try {
    const res = await createUserWithEmailAndPassword(auth, email, password);
    if (displayName && res.user) {
      await updateProfile(res.user, { displayName });
    }
    if (res.user) {
      await saveUserProfileToFirestore(res.user, displayName ? { name: displayName } : undefined);
    }
    return { user: res.user };
  } catch (error: any) {
    console.error('[Firebase Auth] Email sign up error:', error);
    throw error;
  }
};

/**
 * Send Password Reset Email
 */
export const sendResetPasswordEmail = async (email: string): Promise<void> => {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error: any) {
    console.error('[Firebase Auth] Reset password error:', error);
    throw error;
  }
};

/**
 * Sign Out (Works for Google, GitHub, Microsoft, Email)
 */
export const logOutFromGoogle = async (): Promise<void> => {
  try {
    await signOut(auth);
    cachedAccessToken = null;
  } catch (error) {
    console.error('[Firebase Auth] Sign out error:', error);
    throw error;
  }
};

/**
 * Listen to Auth State Changes
 */
export const onAuthStatusChanged = (callback: (user: User | null, token: string | null) => void) => {
  return onAuthStateChanged(auth, async (user) => {
    callback(user, cachedAccessToken);
  });
};

/**
 * Save User Profile to Firestore
 */
export const saveUserProfileToFirestore = async (user: User, extraProfile?: Partial<UserProfile>): Promise<void> => {
  try {
    if (!user || !user.uid) return;
    const userRef = doc(db, 'users', user.uid);
    
    const profileData: Record<string, any> = {
      uid: user.uid,
      displayName: user.displayName || user.email?.split('@')[0] || 'User',
      email: user.email || '',
      photoURL: user.photoURL || '',
      lastLoginAt: Date.now(),
      updatedAt: Date.now(),
      ...(extraProfile?.name ? { name: extraProfile.name } : {}),
      ...(extraProfile?.dob !== undefined ? { dob: extraProfile.dob } : {}),
      ...(extraProfile?.onboardedAt ? { onboardedAt: extraProfile.onboardedAt } : {}),
      ...extraProfile,
    };

    // Strip undefined keys to prevent Firestore write rejection
    Object.keys(profileData).forEach(key => profileData[key] === undefined && delete profileData[key]);

    await setDoc(userRef, profileData, { merge: true });
  } catch (error) {
    console.warn('[Firestore] Note: Could not sync user profile to cloud immediately:', error);
  }
};

/**
 * Save a Chat Session to Firestore
 */
export const saveSessionToFirestore = async (userId: string, session: ChatSession): Promise<void> => {
  try {
    if (!userId || !session || !session.id) return;
    const sessionRef = doc(db, 'users', userId, 'sessions', session.id);
    
    // Clean undefined fields to avoid Firestore errors
    const cleanedSession = JSON.parse(JSON.stringify(session));
    await setDoc(sessionRef, {
      ...cleanedSession,
      updatedAt: session.updatedAt || Date.now(),
    }, { merge: true });
  } catch (error) {
    console.error('[Firestore] Failed to save session:', error);
  }
};

/**
 * Save All Chat Sessions to Firestore (Batch/Parallel)
 */
export const saveAllSessionsToFirestore = async (userId: string, sessions: ChatSession[]): Promise<void> => {
  try {
    if (!userId || !sessions) return;
    const promises = sessions.slice(0, 50).map(s => saveSessionToFirestore(userId, s));
    await Promise.all(promises);
  } catch (error) {
    console.error('[Firestore] Failed to batch save sessions:', error);
  }
};

/**
 * Load Chat Sessions from Firestore
 */
export const loadSessionsFromFirestore = async (userId: string): Promise<ChatSession[]> => {
  try {
    if (!userId) return [];
    const sessionsCol = collection(db, 'users', userId, 'sessions');
    const q = query(sessionsCol, orderBy('updatedAt', 'desc'));
    const snapshot = await getDocs(q);
    
    const sessions: ChatSession[] = [];
    snapshot.forEach(docSnap => {
      sessions.push(docSnap.data() as ChatSession);
    });
    return sessions;
  } catch (error) {
    console.error('[Firestore] Failed to load sessions:', error);
    return [];
  }
};

/**
 * Delete a Chat Session from Firestore
 */
export const deleteSessionFromFirestore = async (userId: string, sessionId: string): Promise<void> => {
  try {
    if (!userId || !sessionId) return;
    const sessionRef = doc(db, 'users', userId, 'sessions', sessionId);
    await deleteDoc(sessionRef);
  } catch (error) {
    console.error('[Firestore] Failed to delete session:', error);
  }
};

/**
 * Save Project to Firestore
 */
export const saveProjectToFirestore = async (userId: string, project: Project): Promise<void> => {
  try {
    if (!userId || !project || !project.id) return;
    const projectRef = doc(db, 'users', userId, 'projects', project.id);
    await setDoc(projectRef, project, { merge: true });
  } catch (error) {
    console.error('[Firestore] Failed to save project:', error);
  }
};

/**
 * Load Projects from Firestore
 */
export const loadProjectsFromFirestore = async (userId: string): Promise<Project[]> => {
  try {
    if (!userId) return [];
    const projectsCol = collection(db, 'users', userId, 'projects');
    const snapshot = await getDocs(projectsCol);
    const projects: Project[] = [];
    snapshot.forEach(docSnap => {
      projects.push(docSnap.data() as Project);
    });
    return projects;
  } catch (error) {
    console.error('[Firestore] Failed to load projects:', error);
    return [];
  }
};

/**
 * Delete Project from Firestore
 */
export const deleteProjectFromFirestore = async (userId: string, projectId: string): Promise<void> => {
  try {
    if (!userId || !projectId) return;
    const projectRef = doc(db, 'users', userId, 'projects', projectId);
    await deleteDoc(projectRef);
  } catch (error) {
    console.error('[Firestore] Failed to delete project:', error);
  }
};
