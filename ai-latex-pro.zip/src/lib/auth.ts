import { User } from 'firebase/auth';
import { 
  auth, 
  signInWithGoogle, 
  logOutFromGoogle, 
  onAuthStatusChanged 
} from './firebase';

export { auth };

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStatusChanged((user, token) => {
    if (user) {
      if (onAuthSuccess) onAuthSuccess(user, token || '');
    } else {
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  const res = await signInWithGoogle();
  return { user: res.user, accessToken: res.accessToken || '' };
};

export const getAccessToken = async (): Promise<string | null> => {
  return null;
};

export const logout = async () => {
  await logOutFromGoogle();
};
