/**
 * Studio-Grade Synthesized Audio Sound Effects using native Web Audio API.
 * 100% reliable, zero external MP3 dependencies, zero latency.
 */

export function playMicStartSound() {
  // Sound disabled as per user request
}

export function playMicStopSound() {
  // Sound disabled as per user request
}

export function playSpeechRecognizedPop() {
  // Sound disabled as per user request
}

export function playSuccessChime() {
  // Sound disabled as per user request
}

export function playMessageSentPop() {
  // Sound disabled as per user request
}

export function playAgentResponsePop() {
  // Sound disabled as per user request
}

export function playMicErrorSound() {
  // Sound disabled as per user request
}
