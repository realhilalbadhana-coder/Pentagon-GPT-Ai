import { 
  parseMarkdownToAst, 
  compileAstToLuaLatex, 
  executeLuaLatexPdfPipeline, 
  exportVectorPdfNative,
  openVectorPdfPreviewTab,
  generateVectorHtmlDocument,
  ContentAST 
} from './latexAstPipeline';

/**
 * 🌟 100% True Vector PDF Export (Selectable Text & Math, Infinite Zoom, Smart Page Breaks)
 * Triggers native high-fidelity Vector PDF generator with full KaTeX math glyphs & academic pagination.
 */
export async function exportVectorPdf(content: string, filename?: string): Promise<void> {
  const cleanTitle = filename ? filename.replace(/\.pdf$/i, '').replace(/_/g, ' ') : undefined;
  await exportVectorPdfNative(content, cleanTitle);
}

/**
 * Executes the Smart LuaLaTeX AST Vector Pipeline with step progress and triggers PDF export.
 */
export async function downloadPdfFile(
  content: string, 
  filename?: string,
  onProgress?: (step: number, message: string) => void
): Promise<void> {
  try {
    const cleanTitle = filename ? filename.replace(/\.pdf$/i, '').replace(/_/g, ' ') : undefined;
    await executeLuaLatexPdfPipeline(content, cleanTitle, onProgress);
  } catch (error: any) {
    console.error('LuaLaTeX PDF Pipeline Error:', error);
    try {
      await exportVectorPdfNative(content, filename);
    } catch {}
  }
}

/**
 * Opens a dedicated standalone Academic Vector Document preview in a new tab with Print/Save toolbar.
 */
export function openAcademicPdfPreview(content: string, filename?: string): void {
  const cleanTitle = filename ? filename.replace(/\.pdf$/i, '').replace(/_/g, ' ') : undefined;
  openVectorPdfPreviewTab(content, cleanTitle);
}

/**
 * Generates and downloads the raw LuaLaTeX (.tex) source code for Overleaf / TeXLive
 */
export function downloadLatexSourceFile(content: string, filename?: string): void {
  try {
    const ast = parseMarkdownToAst(content);
    if (filename) ast.title = filename.replace(/\.tex$/i, '').replace(/_/g, ' ');
    const latexSource = compileAstToLuaLatex(ast);

    const blob = new Blob([latexSource], { type: 'text/x-tex;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const cleanName = (ast.title.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().replace(/\s+/g, '_') || 'document') + '.tex';
    
    link.href = url;
    link.download = cleanName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Download LaTeX Error:', error);
  }
}

/**
 * Copies the compiled LuaLaTeX source code to clipboard
 */
export async function copyLatexCodeToClipboard(content: string): Promise<string> {
  const ast = parseMarkdownToAst(content);
  const latexSource = compileAstToLuaLatex(ast);
  await navigator.clipboard.writeText(latexSource);
  return latexSource;
}

/**
 * Exports raw markdown as a .md download file
 */
export function exportMarkdownFile(content: string, filename?: string): void {
  try {
    const rawName = (filename?.replace(/\.md$/i, '') || 'Pentagon_Response').replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().replace(/\s+/g, '_');
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${rawName}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Export Markdown Error:', error);
  }
}

/**
 * Exports content as a formatted Microsoft Word (.docx/.doc) document with clean tables, headings and formulas
 */
export function exportDocxFile(content: string, filename?: string): void {
  try {
    const ast = parseMarkdownToAst(content);
    const rawName = (filename?.replace(/\.docx?$/i, '') || ast.title || 'Pentagon_Response').replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().replace(/\s+/g, '_');
    
    // Generate clean Word-compatible HTML
    const htmlDoc = generateVectorHtmlDocument(ast, { showInteractiveBar: false });
    const wordHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>${ast.title}</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
      </head>
      <body>
        ${htmlDoc}
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + wordHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${rawName}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Export DOCX Error:', error);
  }
}

export { 
  parseMarkdownToAst, 
  compileAstToLuaLatex, 
  executeLuaLatexPdfPipeline, 
  exportVectorPdfNative,
  openVectorPdfPreviewTab,
  generateVectorHtmlDocument,
  type ContentAST 
};
