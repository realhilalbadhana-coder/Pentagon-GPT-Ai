import { useState, useCallback, useRef, useEffect } from 'react';

export function useTextToSpeech() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const speak = useCallback(async (text: string, onEnd?: () => void) => {
    // Stop any ongoing speech
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    
    if (!text) return;

    // Strip out markdown, asterisks, emojis for better speech reading
    const cleanText = text
      .replace(/[\*\#\_\`\~]/g, '') // Remove markdown symbols
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1') // Extract link text
      .trim();

    if (!cleanText) return;

    try {
      setIsSpeaking(true);
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanText })
      });

      if (!res.ok) {
        throw new Error('TTS failed');
      }

      const data = await res.json();
      if (data.audioBase64) {
        const audioSrc = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
        const audio = new Audio(audioSrc);
        audioRef.current = audio;
        
        audio.onended = () => {
          setIsSpeaking(false);
          if (onEnd) onEnd();
        };
        
        audio.onerror = () => {
          setIsSpeaking(false);
          if (onEnd) onEnd();
        };

        await audio.play();
      } else {
        setIsSpeaking(false);
        if (onEnd) onEnd();
      }
    } catch (error) {
      console.error("Speech synthesis error", error);
      setIsSpeaking(false);
      if (onEnd) onEnd();
    }
  }, []);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsSpeaking(false);
  }, []);

  return { speak, stop, isSpeaking };
}
