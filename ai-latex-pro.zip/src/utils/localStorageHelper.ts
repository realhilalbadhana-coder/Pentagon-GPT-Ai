import { ChatMessage, ChatSession, UserProfile } from '../types';

const STORAGE_KEYS = {
  SESSIONS: 'pentagon_chat_sessions_v1',
  CURRENT_SESSION_ID: 'pentagon_current_session_id_v1',
  PREFERRED_MODEL: 'pentagon_preferred_model_v1',
  DRAFT_INPUT: 'pentagon_draft_input_v1',
  PERPLEXITY_COUNT: 'perplexity_count',
  PERPLEXITY_DATE: 'perplexity_date',
  SEARCH_MODE: 'pentagon_search_mode_v1',
  USER_PROFILE: 'pentagon_user_profile_v1',
  ONBOARDED: 'pentagon_user_onboarded_v1',
};

export const localStorageHelper = {
  // Load all sessions
  
  getProjects(): import('../types').Project[] {
    try {
      const data = localStorage.getItem('ai_agent_projects');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveProjects(projects: import('../types').Project[]): void {
    localStorage.setItem('ai_agent_projects', JSON.stringify(projects));
  },
  createProject(name: string): import('../types').Project {
    const newProject = {
      id: Date.now().toString(),
      name,
      createdAt: Date.now()
    };
    const projects = this.getProjects();
    projects.unshift(newProject);
    this.saveProjects(projects);
    return newProject;
  },

  getSessions(): ChatSession[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
      return [];
    } catch (e) {
      console.error('[LocalStorage] Failed to parse sessions:', e);
      return [];
    }
  },

  // Save all sessions (with safety limit to avoid exceeding quota)
  saveSessions(sessions: ChatSession[]): void {
    try {
      // Keep up to 50 most recent sessions
      const trimmed = sessions.slice(0, 50);
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(trimmed));
    } catch (e) {
      console.error('[LocalStorage] Failed to save sessions (quota exceeded):', e);
      try {
        // Fallback: trim to 15 sessions if storage is full
        const fallback = sessions.slice(0, 15);
        localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(fallback));
      } catch (fallbackError) {
        console.error('[LocalStorage] Critical save failure:', fallbackError);
      }
    }
  },

  // Get current active session ID
  getCurrentSessionId(): string | null {
    try {
      return localStorage.getItem(STORAGE_KEYS.CURRENT_SESSION_ID);
    } catch (e) {
      return null;
    }
  },

  // Save current active session ID
  saveCurrentSessionId(id: string | null): void {
    try {
      if (id) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_SESSION_ID, id);
      } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_SESSION_ID);
      }
    } catch (e) {}
  },

  // Get saved preferred model
  getPreferredModel(fallback: string = 'auto'): string {
    try {
      return localStorage.getItem(STORAGE_KEYS.PREFERRED_MODEL) || fallback;
    } catch (e) {
      return fallback;
    }
  },

  // Save preferred model
  savePreferredModel(model: string): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PREFERRED_MODEL, model);
    } catch (e) {}
  },

  // Get saved search mode
  getSearchMode(fallback: boolean = false): boolean {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.SEARCH_MODE);
      return val !== null ? val === 'true' : fallback;
    } catch (e) {
      return fallback;
    }
  },

  // Save search mode
  saveSearchMode(enabled: boolean): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SEARCH_MODE, enabled ? 'true' : 'false');
    } catch (e) {}
  },

  // Get draft input
  getDraftInput(): string {
    try {
      return localStorage.getItem(STORAGE_KEYS.DRAFT_INPUT) || '';
    } catch (e) {
      return '';
    }
  },

  // Save draft input
  saveDraftInput(text: string): void {
    try {
      if (text) {
        localStorage.setItem(STORAGE_KEYS.DRAFT_INPUT, text);
      } else {
        localStorage.removeItem(STORAGE_KEYS.DRAFT_INPUT);
      }
    } catch (e) {}
  },

  // Create new session
  createNewSession(model: string = 'auto'): ChatSession {
    const newSession: ChatSession = {
      id: 'session_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      title: 'New Chat',
      messages: [],
      model,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    return newSession;
  },

  // Delete a specific session
  deleteSession(sessionId: string): ChatSession[] {
    const sessions = this.getSessions().filter(s => s.id !== sessionId);
    this.saveSessions(sessions);
    return sessions;
  },

  // User Profile & Onboarding
  getUserProfile(): UserProfile | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  saveUserProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
      localStorage.setItem(STORAGE_KEYS.ONBOARDED, 'true');
    } catch (e) {}
  },

  isOnboarded(): boolean {
    return true;
  },

  setOnboarded(value: boolean): void {
    try {
      if (value) {
        localStorage.setItem(STORAGE_KEYS.ONBOARDED, 'true');
      } else {
        localStorage.removeItem(STORAGE_KEYS.ONBOARDED);
      }
    } catch (e) {}
  },

  // Clear all sessions and data
  clearAll(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.SESSIONS);
      localStorage.removeItem(STORAGE_KEYS.CURRENT_SESSION_ID);
      localStorage.removeItem(STORAGE_KEYS.DRAFT_INPUT);
    } catch (e) {}
  }
};
