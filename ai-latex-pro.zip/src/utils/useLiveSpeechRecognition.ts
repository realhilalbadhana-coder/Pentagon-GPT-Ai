import { useState, useCallback, useRef, useEffect } from 'react';

interface UseLiveSpeechOptions {
  onTranscriptChange?: (interim: string, isFinal: boolean) => void;
}

export function useLiveSpeechRecognition({ onTranscriptChange }: UseLiveSpeechOptions = {}) {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  const isStartingOrListeningRef = useRef(false);
  const onTranscriptChangeRef = useRef(onTranscriptChange);

  useEffect(() => {
    onTranscriptChangeRef.current = onTranscriptChange;
  }, [onTranscriptChange]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        isStartingOrListeningRef.current = true;
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (onTranscriptChangeRef.current) {
          onTranscriptChangeRef.current(interimTranscript || finalTranscript, !!finalTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        // 'aborted' happens normally when stopped or cancelled by user, 'no-speech' happens during silence
        if (event.error === 'aborted' || event.error === 'no-speech') {
          return;
        }
        console.warn('Live speech notice:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setIsListening(false);
          isStartingOrListeningRef.current = false;
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        isStartingOrListeningRef.current = false;
      };

      recognitionRef.current = recognition;
    }
    
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore cleanup abort errors
        }
        recognitionRef.current = null;
        isStartingOrListeningRef.current = false;
      }
    };
  }, []);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isStartingOrListeningRef.current) {
      try {
        isStartingOrListeningRef.current = true;
        recognitionRef.current.start();
      } catch {
        isStartingOrListeningRef.current = false;
      }
    }
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isStartingOrListeningRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore stop error
      }
      isStartingOrListeningRef.current = false;
      setIsListening(false);
    }
  }, []);

  return { isListening, startListening, stopListening, isSupported: !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition) };
}
