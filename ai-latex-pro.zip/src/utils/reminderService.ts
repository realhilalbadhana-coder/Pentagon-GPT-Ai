import { ScheduledTask, TaskCategory } from '../types';

const REMINDERS_STORAGE_KEY = 'pentagon_scheduled_reminders_v1';

/**
 * Check if the browser supports standard Web Notifications
 */
export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

/**
 * Get current browser notification permission status
 */
export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

/**
 * Request notification permission from user
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!isNotificationSupported()) return 'denied';
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (e) {
    console.error('Error requesting notification permission:', e);
    return Notification.permission;
  }
}

/**
 * Play a high-quality multi-tone harmonic notification chime using Web Audio API
 */
export function playNotificationChime(type: 'reminder' | 'success' | 'alert' = 'reminder') {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;

    if (type === 'reminder' || type === 'alert') {
      // Elegant 3-tone chime (E5 -> G#5 -> B5 -> E6)
      const frequencies = [659.25, 830.61, 987.77, 1318.51];
      frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.12);

        gain.gain.setValueAtTime(0, now + idx * 0.12);
        gain.gain.linearRampToValueAtTime(0.28, now + idx * 0.12 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.6);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.12);
        osc.stop(now + idx * 0.12 + 0.65);
      });
    } else {
      // Soft 2-tone success chime
      const frequencies = [587.33, 880.0];
      frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0, now + idx * 0.1);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.1 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.55);
      });
    }
  } catch (err) {
    console.warn('Could not play web audio notification chime:', err);
  }
}

/**
 * Send OS-level / browser native Notification
 */
export function sendSystemNotification(title: string, options?: { body?: string; icon?: string; tag?: string; onClick?: () => void }) {
  if (!isNotificationSupported() || Notification.permission !== 'granted') {
    return null;
  }

  try {
    const notif = new Notification(title, {
      body: options?.body || 'Your scheduled Pentagon task is due now!',
      icon: options?.icon || 'https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/svg/minimax.svg',
      tag: options?.tag || 'pentagon-task',
      requireInteraction: true,
      silent: false
    });

    notif.onclick = () => {
      window.focus();
      if (options?.onClick) options.onClick();
      notif.close();
    };

    return notif;
  } catch (e) {
    console.error('Failed to trigger native notification:', e);
    return null;
  }
}

/**
 * Load all tasks from local storage
 */
export function loadScheduledTasks(): ScheduledTask[] {
  try {
    const raw = localStorage.getItem(REMINDERS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error('Error loading tasks:', e);
    return [];
  }
}

/**
 * Save all tasks to local storage
 */
export function saveScheduledTasks(tasks: ScheduledTask[]) {
  try {
    localStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(tasks));
  } catch (e) {
    console.error('Error saving tasks:', e);
  }
}

/**
 * Create and persist a new task
 */
export function createScheduledTask(params: {
  title: string;
  description?: string;
  scheduledTime: number;
  timeLabel?: string;
  category?: TaskCategory;
  soundEnabled?: boolean;
  systemNotification?: boolean;
  sessionId?: string;
}): ScheduledTask {
  const tasks = loadScheduledTasks();
  const dateObj = new Date(params.scheduledTime);
  const timeLabel = params.timeLabel || dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

  const newTask: ScheduledTask = {
    id: 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    title: params.title.trim() || 'Scheduled Task',
    description: params.description,
    scheduledTime: params.scheduledTime,
    timeLabel,
    category: params.category || 'personal',
    soundEnabled: params.soundEnabled ?? true,
    systemNotification: params.systemNotification ?? true,
    status: 'pending',
    createdAt: Date.now(),
    sessionId: params.sessionId
  };

  const updated = [newTask, ...tasks];
  saveScheduledTasks(updated);
  return newTask;
}

/**
 * Update task status (e.g. triggered, snoozed, completed)
 */
export function updateTaskStatus(taskId: string, status: ScheduledTask['status'], extra?: Partial<ScheduledTask>): ScheduledTask[] {
  const tasks = loadScheduledTasks();
  const updated = tasks.map(t => {
    if (t.id === taskId) {
      return { ...t, status, ...extra };
    }
    return t;
  });
  saveScheduledTasks(updated);
  return updated;
}

/**
 * Snooze a task by X minutes
 */
export function snoozeTask(taskId: string, minutes: number = 5): ScheduledTask[] {
  const tasks = loadScheduledTasks();
  const newScheduledTime = Date.now() + minutes * 60 * 1000;
  const newDate = new Date(newScheduledTime);
  const timeLabel = newDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

  const updated = tasks.map(t => {
    if (t.id === taskId) {
      return {
        ...t,
        scheduledTime: newScheduledTime,
        timeLabel,
        status: 'pending' as const,
        triggeredAt: undefined
      };
    }
    return t;
  });
  saveScheduledTasks(updated);
  return updated;
}

/**
 * Delete a task
 */
export function deleteTask(taskId: string): ScheduledTask[] {
  const tasks = loadScheduledTasks();
  const updated = tasks.filter(t => t.id !== taskId);
  saveScheduledTasks(updated);
  return updated;
}

/**
 * Format relative time remaining (e.g. "In 8m 32s" or "Overdue by 2m")
 */
export function formatTimeRemaining(scheduledTime: number): string {
  const diffMs = scheduledTime - Date.now();
  if (diffMs <= 0) {
    const overSec = Math.floor(Math.abs(diffMs) / 1000);
    if (overSec < 60) return `Just now (${overSec}s ago)`;
    const overMin = Math.floor(overSec / 60);
    return `${overMin}m ago`;
  }

  const totalSec = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSec / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `In ${days}d ${hours % 24}h`;
  }
  if (hours > 0) {
    return `In ${hours}h ${minutes}m`;
  }
  if (minutes > 0) {
    return `In ${minutes}m ${seconds}s`;
  }
  return `In ${seconds}s`;
}

/**
 * Natural language parser for reminder prompts
 * Parses requests like:
 * - "Remind me at 9:10pm to finish my latex paper"
 * - "muje 9:10 pm par notification bejan"
 * - "set reminder for 10 minutes to submit homework"
 * - "notify me tomorrow at 8:00 AM"
 * - "alert me in 30 seconds"
 */
export function parseReminderFromPrompt(prompt: string): {
  isReminder: boolean;
  title: string;
  scheduledTime: number;
  timeLabel: string;
  category: TaskCategory;
} | null {
  if (!prompt || typeof prompt !== 'string') return null;
  const p = prompt.trim();
  const lower = p.toLowerCase();

  // Check if intent is reminder/notification/task/alarm
  const reminderKeywords = [
    'remind', 'notification', 'notify', 'reminder', 'alarm', 'task',
    'bhejna', 'bejan', 'yad dilana', 'yaad dilana', 'alert', 'timer'
  ];
  const hasReminderIntent = reminderKeywords.some(k => lower.includes(k));
  if (!hasReminderIntent) return null;

  const now = new Date();
  let targetDate = new Date();
  let isParsed = false;
  let timeLabel = '';
  let taskTitle = '';

  // 1. Check relative minutes / seconds (e.g. "in 10 minutes", "10 minute baad", "after 5 mins", "in 30 seconds")
  const minMatch = lower.match(/(?:in|after|for)\s+(\d+)\s*(?:minutes?|mins?|min|minute|m\b)/) ||
                   lower.match(/(\d+)\s*(?:minute|min|m|mint)\s*(?:baad|ke baad|after|mein|main)/);
  const secMatch = lower.match(/(?:in|after|for)\s+(\d+)\s*(?:seconds?|secs?|sec|s\b)/) ||
                   lower.match(/(\d+)\s*(?:second|sec)\s*(?:baad|ke baad|after|mein|main)/);
  const hourMatch = lower.match(/(?:in|after|for)\s+(\d+)\s*(?:hours?|hrs?|hr|ghante|ghanta)/) ||
                    lower.match(/(\d+)\s*(?:hour|hr|ghanta|ghante)\s*(?:baad|ke baad|after|mein|main)/);

  if (minMatch) {
    const mins = parseInt(minMatch[1], 10);
    targetDate = new Date(now.getTime() + mins * 60 * 1000);
    timeLabel = `In ${mins} minute${mins > 1 ? 's' : ''}`;
    isParsed = true;
  } else if (secMatch) {
    const secs = parseInt(secMatch[1], 10);
    targetDate = new Date(now.getTime() + secs * 1000);
    timeLabel = `In ${secs} second${secs > 1 ? 's' : ''}`;
    isParsed = true;
  } else if (hourMatch) {
    const hrs = parseInt(hourMatch[1], 10);
    targetDate = new Date(now.getTime() + hrs * 60 * 60 * 1000);
    timeLabel = `In ${hrs} hour${hrs > 1 ? 's' : ''}`;
    isParsed = true;
  }

  // 2. Check exact clock time (e.g. "9:10pm", "9:10 pm", "9:10", "at 9 pm", "8:30 am par", "9 baje")
  if (!isParsed) {
    const timeMatch = lower.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)/i) ||
                      lower.match(/(?:at|par|ko|baje)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i) ||
                      lower.match(/(\d{1,2}):(\d{2})/);

    if (timeMatch) {
      let hours = parseInt(timeMatch[1], 10);
      const minutes = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
      const meridiem = timeMatch[3]?.toLowerCase();

      if (meridiem) {
        if (meridiem.includes('pm') && hours < 12) hours += 12;
        if (meridiem.includes('am') && hours === 12) hours = 0;
      } else {
        // If no AM/PM provided and hour is < current hour, assume PM or next cycle
        if (hours < 12 && (hours < now.getHours() % 12 || (hours === now.getHours() % 12 && minutes <= now.getMinutes()))) {
          if (hours + 12 < 24) hours += 12;
        }
      }

      targetDate.setHours(hours, minutes, 0, 0);

      // If scheduled time has already passed today, schedule for tomorrow
      if (targetDate.getTime() <= now.getTime()) {
        targetDate.setDate(targetDate.getDate() + 1);
        timeLabel = `Tomorrow at ${targetDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}`;
      } else {
        timeLabel = `Today at ${targetDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}`;
      }

      isParsed = true;
    }
  }

  if (!isParsed) return null;

  // Clean task title from prompt
  taskTitle = p
    .replace(/(?:remind me|notify me|set reminder|send notification|notification bhejna|bejan|yad dilana|yaad dilana|mujhe|muje|ko|par|at|in|after|for)/gi, '')
    .replace(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)/gi, '')
    .replace(/\d+\s*(?:minutes?|mins?|seconds?|secs?|hours?|ghante|baad|ke baad|mein)/gi, '')
    .replace(/(?:to|that|ke|ki|for)\s+/i, '')
    .replace(/[.,!?]+$/, '')
    .trim();

  if (!taskTitle || taskTitle.length < 2) {
    taskTitle = 'Scheduled Task Reminder';
  }

  // Detect category
  let category: TaskCategory = 'personal';
  if (/latex|paper|thesis|compile|bibtex|document|pdf|math/i.test(p)) {
    category = 'latex';
  } else if (/study|class|assignment|exam|quiz|lecture|research/i.test(p)) {
    category = 'academic';
  } else if (/urgent|asap|important|deadline/i.test(p)) {
    category = 'urgent';
  } else if (/timer|stopwatch|count/i.test(p)) {
    category = 'timer';
  }

  return {
    isReminder: true,
    title: taskTitle,
    scheduledTime: targetDate.getTime(),
    timeLabel,
    category
  };
}
