import { useState, useRef, useEffect, useCallback } from 'react';
import {
  playMicStartSound,
  playMicStopSound,
  playSpeechRecognizedPop,
  playMicErrorSound,
} from './audioSoundEffects';

interface UseSpeechRecognitionOptions {
  onTranscriptUpdate?: (fullText: string, newText: string) => void;
}

export function useSpeechRecognition({
  onTranscriptUpdate,
}: UseSpeechRecognitionOptions = {}) {
  const [isListening, setIsListening] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const baseTextRef = useRef<string>('');

  const transcribeFinalAudio = async () => {
    if (audioChunksRef.current.length === 0) return;

    setIsTranscribing(true);
    try {
      const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
      const blob = new Blob(audioChunksRef.current, { type: mimeType });

      // Avoid sending empty/too short recordings
      if (blob.size < 2000) {
        setIsTranscribing(false);
        return;
      }

      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': mimeType },
        body: blob
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.text?.trim() || '';

        if (text) {
          playSpeechRecognizedPop();
          if (onTranscriptUpdate) {
            const separator = baseTextRef.current && !baseTextRef.current.endsWith(' ') && !baseTextRef.current.endsWith('\n') ? ' ' : '';
            const fullOutput = baseTextRef.current + (text ? separator + text : '');
            onTranscriptUpdate(fullOutput, text);
          }
        }
      }
    } catch (err) {
      console.warn('[Whisper API Error]:', err);
    } finally {
      setIsTranscribing(false);
      audioChunksRef.current = [];
    }
  };

  const startListening = useCallback(
    async (existingText: string = '') => {
      setError(null);
      baseTextRef.current = existingText;
      audioChunksRef.current = [];

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        let mimeType = 'audio/webm';
        if (typeof MediaRecorder.isTypeSupported === 'function') {
          if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'audio/mp4';
            if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = '';
          }
        } else {
          mimeType = '';
        }

        const mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
        mediaRecorderRef.current = mediaRecorder;

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        // Trigger transcription exactly when recording fully stops
        mediaRecorder.onstop = () => {
          transcribeFinalAudio();
        };

        mediaRecorder.onstart = () => {
          setIsListening(true);
          playMicStartSound();
        };

        mediaRecorder.start();
      } catch (err: any) {
        console.error('[SpeechRecognition Start Error]:', err);
        setError('Microphone permission denied.');
        playMicErrorSound();
        setIsListening(false);
      }
    },
    [onTranscriptUpdate]
  );

  const stopListening = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop(); // This triggers onstop -> transcribeFinalAudio
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }

    setIsListening(false);
    playMicStopSound();
  }, []);

  const cancelListening = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.onstop = null; // Prevent transcription on cancel
      mediaRecorderRef.current.stop();
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }

    setIsListening(false);
    audioChunksRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) mediaStreamRef.current.getTracks().forEach(t => t.stop());
    };
  }, []);

  return {
    isListening,
    isTranscribing,
    error,
    startListening,
    stopListening,
    cancelListening,
  };
}
