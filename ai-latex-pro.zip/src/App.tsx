import React, { useState } from 'react';
import { AiAgentChat } from './components/AiAgentChat';

export default function App() {
  const [theme, setTheme] = useState('Day');

  return (
    <div className={`flex flex-col h-[100dvh] w-full overflow-hidden font-sans relative ${theme === 'Night' ? 'dark bg-[#11141A]' : 'bg-[#FAF9F6]'}`}>
      <div className="flex-1 flex overflow-hidden relative">
        <AiAgentChat theme={theme} onThemeChange={setTheme} />
      </div>
    </div>
  );
}
