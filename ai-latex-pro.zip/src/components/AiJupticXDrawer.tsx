import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  Wrench, 
  Sigma, 
  Table, 
  BookOpen, 
  Languages, 
  Maximize2, 
  Send, 
  Check, 
  Copy,
  ArrowRight,
  HelpCircle,
  FileEdit
} from 'lucide-react';

interface AiPentagonDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentCode: string;
  onApplyCode: (newCode: string) => void;
  onInsertSnippet: (snippet: string) => void;
}

export const AiPentagonDrawer: React.FC<AiPentagonDrawerProps> = ({
  isOpen,
  onClose,
  currentCode,
  onApplyCode,
  onInsertSnippet,
}) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [applied, setApplied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickActions = [
    {
      id: 'fix-syntax',
      label: 'Fix Syntax & Syntax Errors',
      icon: <Wrench className="w-4 h-4 text-emerald-400" />,
      desc: 'Fixes unclosed braces, bad math delimiters, invalid packages, and broken environments.',
    },
    {
      id: 'polish-academic-tone',
      label: 'Polish to IEEE/Nature Academic Standard',
      icon: <Languages className="w-4 h-4 text-indigo-400" />,
      desc: 'Rewrites selected text or paper into authoritative, clear academic English.',
    },
    {
      id: 'add-equation',
      label: 'Generate Complex Math / Proof',
      icon: <Sigma className="w-4 h-4 text-amber-400" />,
      desc: 'Creates aligned systems, matrix equations, calculus integrals, or mathematical proofs.',
    },
    {
      id: 'format-table',
      label: 'Generate Academic Table (booktabs)',
      icon: <Table className="w-4 h-4 text-teal-400" />,
      desc: 'Converts raw data or metrics into high-standard LaTeX booktabs tables.',
    },
    {
      id: 'generate-bibtex',
      label: 'Generate BibTeX Citations',
      icon: <BookOpen className="w-4 h-4 text-violet-400" />,
      desc: 'Creates accurate BibTeX entries or \\bibitem tags for specified papers.',
    },
    {
      id: 'convert-notes',
      label: 'Convert Raw Notes/Markdown to LaTeX',
      icon: <FileEdit className="w-4 h-4 text-rose-400" />,
      desc: 'Transforms raw markdown notes or text into properly formatted LaTeX markup.',
    },
  ];

  const handleRunAction = async (actionId: string, customPrompt?: string) => {
    setLoading(true);
    setActiveAction(actionId);
    setError(null);
    setResult(null);
    setApplied(false);

    try {
      const response = await fetch('/api/latex/pentagon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: actionId,
          latexCode: currentCode,
          prompt: customPrompt || prompt,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to execute pentagon command.');
      }

      setResult(data.result);
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleCustomPromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    handleRunAction('custom', prompt.trim());
  };

  const handleCopyResult = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  const handleApplyFullCode = () => {
    if (!result) return;
    onApplyCode(result);
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  const handleInsertSnippet = () => {
    if (!result) return;
    onInsertSnippet(result);
    setApplied(true);
    setTimeout(() => setApplied(false), 2000);
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[480px] bg-slate-950 border-l border-slate-800 shadow-2xl z-40 flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-indigo-600/30 border border-indigo-500/40 rounded-lg text-indigo-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">AI LaTeX Pentagon</h3>
            <p className="text-[11px] text-slate-400">Smart editing, debugging & academic refinement</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-slate-300">
        {/* Quick Actions List */}
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            One-Click Pentagon Actions
          </span>
          <div className="grid grid-cols-1 gap-2">
            {quickActions.map((act) => (
              <button
                key={act.id}
                onClick={() => handleRunAction(act.id)}
                disabled={loading}
                className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition-all text-left group disabled:opacity-50"
              >
                <div className="p-2 bg-slate-950 rounded border border-slate-800 shrink-0 mt-0.5 group-hover:border-indigo-500/50">
                  {act.icon}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-slate-200 group-hover:text-indigo-300 transition-colors">
                    {act.label}
                  </div>
                  <div className="text-[11px] text-slate-400 leading-snug mt-0.5">{act.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Prompt Box */}
        <div className="pt-2 border-t border-slate-800">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            Custom Instruction / Question
          </span>
          <form onSubmit={handleCustomPromptSubmit} className="space-y-2">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. Add a section explaining the loss function with L2 regularization; or format my raw benchmark results into a table..."
              rows={3}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-slate-200 focus:outline-none focus:border-indigo-500 resize-none text-xs"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="w-full flex items-center justify-center gap-2 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg shadow-sm transition-colors disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Processing with Gemini...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Execute AI Instruction</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Errors */}
        {error && (
          <div className="p-3 bg-red-950/60 border border-red-800 rounded-lg text-red-200 text-xs">
            {error}
          </div>
        )}

        {/* AI Result View */}
        {result && (
          <div className="p-4 bg-slate-900 rounded-xl border border-indigo-500/40 shadow-inner space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-semibold text-indigo-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Pentagon Output
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleCopyResult}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-[11px] flex items-center gap-1"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Code Output Window */}
            <div className="max-h-60 overflow-y-auto bg-slate-950 p-3 rounded border border-slate-800 font-mono text-[11px] text-slate-200 whitespace-pre-wrap leading-relaxed">
              {result}
            </div>

            {/* Apply Actions */}
            <div className="flex items-center gap-2 pt-1">
              {result.includes('\\documentclass') ? (
                <button
                  onClick={handleApplyFullCode}
                  className="flex-1 flex items-center justify-center gap-1.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded text-xs transition-colors"
                >
                  {applied ? <Check className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                  <span>{applied ? 'Replaced Document!' : 'Replace Entire Code'}</span>
                </button>
              ) : (
                <button
                  onClick={handleInsertSnippet}
                  className="flex-1 flex items-center justify-center gap-1.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded text-xs transition-colors"
                >
                  {applied ? <Check className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                  <span>{applied ? 'Inserted!' : 'Insert at Cursor'}</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
