import React from 'react';

// Exact Pixel-Accurate SVG Icons matching Pentagon (Fluent System Icons) and Official AI Models

// 1. Thumbs Up
export const PentagonThumbUpIcon: React.FC<{ className?: string; filled?: boolean }> = ({ className = 'w-5 h-5', filled }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    {filled ? (
      <path d="M15.06 9q.69-2.13.69-3.75c0-2.4-.94-4.25-2.5-4.25-.85 0-1.11.5-1.44 1.75a65 65 0 0 1-.77 2.72L8.17 9.95a6 6 0 0 1-2.85 2.33l-1.26.48c-.8.3-1.25 1.13-1.09 1.97l.69 3.54c.16.86.82 1.54 1.67 1.75l8.25 2.03a4.75 4.75 0 0 0 5.73-3.44l1.58-6.18A2.75 2.75 0 0 0 18.22 9z" />
    ) : (
      <path d="M16.5 5.2c0-2.44-1.14-4.2-3-4.2-1.03 0-1.39.6-1.75 2l-.15.57-.56 1.9-2.87 4.48a6 6 0 0 1-2.85 2.33l-.47.18a2.75 2.75 0 0 0-1.72 3.1l.4 2.08a3.3 3.3 0 0 0 2.42 2.54l7.63 1.87a4.75 4.75 0 0 0 5.73-3.44l1.42-5.55A3.25 3.25 0 0 0 17.58 9h-1.83q.75-2.44.75-3.8M4.6 15.27c-.11-.6.21-1.2.78-1.4l.47-.19a7.4 7.4 0 0 0 3.59-2.92l2.86-4.48q.14-.22.2-.46l.7-2.43c.19-.73.28-.89.3-.89.86 0 1.5.99 1.5 2.7q0 1.34-.98 4.32c-.17.48.2.98.7.98h2.86a1.75 1.75 0 0 1 1.7 2.19l-1.42 5.55a3.25 3.25 0 0 1-3.93 2.35l-7.62-1.87A1.8 1.8 0 0 1 5 17.35z" />
    )}
  </svg>
);

// 2. Thumbs Down
export const PentagonThumbDownIcon: React.FC<{ className?: string; filled?: boolean }> = ({ className = 'w-5 h-5', filled }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    {filled ? (
      <path d="M15.06 14.18q.69 2.14.69 3.76c0 2.4-.94 4.24-2.5 4.24-.8 0-1.08-.45-1.38-1.54l-.27-1.02-.56-1.9-2.87-4.49a6 6 0 0 0-2.85-2.32l-1.26-.48a1.75 1.75 0 0 1-1.09-1.97l.69-3.54c.16-.86.82-1.55 1.67-1.76l8.25-2.02a4.75 4.75 0 0 1 5.73 3.44l1.58 6.17a2.75 2.75 0 0 1-2.67 3.43z" />
    ) : (
      <path d="M16.5 17.99c0 2.44-1.14 4.2-3 4.2-.98 0-1.35-.55-1.7-1.8l-.2-.77-.56-1.9-2.87-4.49a6 6 0 0 0-2.85-2.32l-.47-.18a2.75 2.75 0 0 1-1.72-3.1l.4-2.08A3.3 3.3 0 0 1 5.95 3l7.63-1.87a4.75 4.75 0 0 1 5.73 3.44l1.42 5.55a3.25 3.25 0 0 1-3.15 4.05h-1.83q.75 2.46.75 3.8M4.6 7.92c-.11.6.21 1.19.78 1.4l.47.19a7.4 7.4 0 0 1 3.59 2.92l2.86 4.48q.14.21.2.46l.56 1.92.21.79a2 2 0 0 0 .22.6c.87 0 1.51-.98 1.51-2.7q0-1.33-.98-4.31a.75.75 0 0 1 .7-.99h2.86a1.75 1.75 0 0 0 1.7-2.18l-1.42-5.55a3.25 3.25 0 0 0-3.93-2.35L6.31 4.47c-.67.16-1.17.7-1.3 1.36z" />
    )}
  </svg>
);

// 3. Share
export const PentagonShareIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12.53 2.22a.75.75 0 0 0-1.06 0L6.22 7.47a.75.75 0 0 0 1.06 1.06l3.97-3.97v10.69a.75.75 0 0 0 1.5 0V4.56l3.97 3.97a.75.75 0 1 0 1.06-1.06zM3.75 11c.41 0 .75.34.75.75v6c0 .97.78 1.75 1.75 1.75h11.5c.97 0 1.75-.78 1.75-1.75v-6a.75.75 0 0 1 1.5 0v6c0 1.8-1.46 3.25-3.25 3.25H6.25A3.25 3.25 0 0 1 3 17.75v-6c0-.41.34-.75.75-.75" />
  </svg>
);

// 4. Copy / Duplicate
export const PentagonCopyIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M8.5 8.5H6.25c-.97 0-1.75.78-1.75 1.75v7.5c0 .97.78 1.75 1.75 1.75h5c.88 0 1.6-.65 1.73-1.5h1.5a3.25 3.25 0 0 1-3.23 3h-5A3.25 3.25 0 0 1 3 17.75v-7.5C3 8.45 4.46 7 6.25 7H8.5zM17.75 3C19.55 3 21 4.46 21 6.25v7.5c0 1.8-1.46 3.25-3.25 3.25h-5a3.25 3.25 0 0 1-3.25-3.25v-7.5C9.5 4.45 10.96 3 12.75 3zm-5 1.5c-.97 0-1.75.78-1.75 1.75v7.5c0 .97.78 1.75 1.75 1.75h5c.97 0 1.75-.78 1.75-1.75v-7.5c0-.97-.78-1.75-1.75-1.75z" />
  </svg>
);

// 5. Speaker / Read Aloud
export const PentagonVolumeIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M15 4.25a1.25 1.25 0 0 0-2.08-.93L8.42 7.3a.8.8 0 0 1-.49.19H4.25C3.01 7.5 2 8.5 2 9.75v4.5c0 1.24 1 2.25 2.25 2.25h3.68q.28 0 .5.19l4.49 3.99c.8.72 2.08.14 2.08-.93zM9.42 8.43l4.08-3.62v14.38l-4.08-3.63A2.3 2.3 0 0 0 7.93 15H4.25a.75.75 0 0 1-.75-.75v-4.5c0-.42.34-.75.75-.75h3.68c.55 0 1.08-.2 1.5-.57M19 5.9a.75.75 0 0 1 1.05.15 10 10 0 0 1 0 11.9.75.75 0 1 1-1.2-.9 8.5 8.5 0 0 0 0-10.1.75.75 0 0 1 .15-1.05m-1.85 2.47a.75.75 0 0 1 1.02.3 7 7 0 0 1 0 6.66.75.75 0 0 1-1.32-.72 5.5 5.5 0 0 0 0-5.22.75.75 0 0 1 .3-1.02" />
  </svg>
);

// 6. Three-dot More Menu
export const PentagonMoreIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M7.75 12a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0m6 0a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0M18 13.75a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5" />
  </svg>
);

// Others
export const PentagonSmartAsteriskIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="#1F1F1F" strokeWidth="2" strokeLinecap="round">
    <line x1="12" y1="2" x2="12" y2="22" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
    <line x1="19.07" y1="4.93" x2="4.93" y2="19.07" />
  </svg>
);

export const PentagonThinkDeeperIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="#1F1F1F" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);

export const PentagonStudyIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="#1F1F1F" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
    <path d="M6 12v5c3 3 9 3 12 0v-5" />
  </svg>
);

export const PentagonSearchIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="#1F1F1F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

// ==========================================
// OFFICIAL AI MODEL SVG LOGOS (from Wikimedia)
// ==========================================

export const LOGO_URLS = {
  gemini: 'https://ik.imagekit.io/j33n0ehll/Gem',
  progem: 'https://ik.imagekit.io/j33n0ehll/progem',
  nvidia: '/logos/nvidia.svg',
  chatgpt: '/logos/chatgpt.svg',
  terra: 'https://ik.imagekit.io/j33n0ehll/ChatGpt',
  deepseek: '/logos/deepseek.svg',
  claude: '/logos/claude.svg',
  fable: 'https://ik.imagekit.io/j33n0ehll/Claude',
  anthropic: '/logos/anthropic.svg',
  mistral: '/logos/mistral.svg',
  xai: '/logos/xai.svg',
  qwen: '/logos/qwen.svg',
  meta: '/logos/meta.svg',
  kimi: '/logos/kimi.png',
  perplexity: '/logos/perplexity.svg',
  search: '/logos/search.svg',
  google: '/logos/google.svg',
  zai: '/logos/zai.svg',
  gptoss: 'https://ik.imagekit.io/j33n0ehll/ChatGpt',
  cohere: 'https://cohere.com/favicon-32x32.png',
  phi4: 'https://upload.wikimedia.org/wikipedia/commons/f/f3/Microsoft-copilot-2026-seeklogo.svg',
  amazon: 'https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original',
  minimax: 'https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/svg/minimax.svg',
  xiaomi: 'https://raw.githubusercontent.com/lobehub/lobe-icons/refs/heads/master/packages/static-avatar/avatars/xiaomimimo.webp',
  pentagon: 'https://ik.imagekit.io/qe76xsswb/file_000000001be48211939a1c0eec994ae5.png'
};

// Pentagon Official Logo
export const PentagonLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.pentagon} 
    alt="Pentagon" 
    className={`${className} object-contain inline-block shrink-0 rounded-xs`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/pentagon.svg';
    }}
  />
);

export const GeminiProLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.progem} 
    alt="Google Gemini Pro" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
  />
);

// 1. Google Gemini Official Icon
export const GeminiLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.gemini} 
    alt="Google Gemini" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      // Local fallback
      e.currentTarget.src = '/logos/gemini.svg';
    }}
  />
);

// 2. NVIDIA Official Logo
export const NvidiaLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.nvidia} 
    alt="NVIDIA" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/nvidia.svg';
    }}
  />
);

// 3. ChatGPT / OpenAI Official Logo (Default SVG for all standard ChatGPT models)
export const ChatGPTLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.chatgpt} 
    alt="ChatGPT" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/chatgpt.svg';
    }}
  />
);

// Special GPT Terra Logo (Only for GPT-5.6 Terra)
export const TerraLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.terra} 
    alt="GPT Terra" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/chatgpt.svg';
    }}
  />
);
export const GptOssLogo = TerraLogo;

// 4. DeepSeek Official Logo
export const DeepSeekLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.deepseek} 
    alt="DeepSeek" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/deepseek.svg';
    }}
  />
);

// 5. Claude AI Official Symbol
export const ClaudeLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.claude} 
    alt="Claude AI" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/claude.svg';
    }}
  />
);

// 6. Mistral AI Official Logo (2025)
export const MistralLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.mistral} 
    alt="Mistral AI" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/mistral.svg';
    }}
  />
);

// 7. xAI / Grok Official Logo
export const XAILogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.xai} 
    alt="xAI Grok" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/xai.svg';
    }}
  />
);

// 8. Alibaba Qwen Official Logo
export const QwenLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.qwen} 
    alt="Qwen" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/qwen.svg';
    }}
  />
);

// 9. Meta AI Official Logo (2026 Official Wikimedia SVG)
export const MetaLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.meta} 
    alt="Meta AI" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Meta_AI_Logo_%282026%29.svg';
    }}
  />
);

// 10. Moonshot Kimi AI Official Logo
export const KimiLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.kimi} 
    alt="Kimi AI" 
    className={`${className} object-contain inline-block shrink-0 rounded-sm`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://ik.imagekit.io/j33n0ehll/kimi';
    }}
  />
);

// 11. Perplexity AI Official Symbol Logo
export const PerplexityLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.perplexity} 
    alt="Perplexity AI" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://unpkg.com/simple-icons@v14/icons/perplexity.svg';
    }}
  />
);

// 12. Google Real-Time Search Official Logo (2025 Google Favicon)
export const SearchLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.search} 
    alt="Google Search" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://upload.wikimedia.org/wikipedia/commons/3/3c/Google_Favicon_2025.svg';
    }}
  />
);

export const DuckDuckGoLogo = SearchLogo;

// 15. Anthropic Official Logo (Geometric 'A')
export const AnthropicLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg 
    viewBox="0 0 24 24" 
    className={`${className} inline-block shrink-0 fill-black dark:fill-white`}
  >
    <path d="M13.827 3.528h3.696L24 20.472h-3.696l-1.571-3.696H11.27l-1.571 3.696H6L13.827 3.528zm3.01 10.37-2.316-5.45-2.316 5.45h4.632zM3.696 20.472H0L6.477 5.23h3.696L3.696 20.472z"/>
  </svg>
);

// Special Fable 5 Logo (Exclusive ImageKit Claude logo for Fable 5 only)
export const FableLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.fable} 
    alt="Fable 5" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/claude.svg';
    }}
  />
);

// 13. Z.AI Official Logo
export const ZaiLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.zai} 
    alt="Z.AI" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://upload.wikimedia.org/wikipedia/commons/f/f4/Z.ai_%28company_logo%29.svg';
    }}
  />
);

// 14. Cohere Command R+ Official SVG Icon
export const CohereLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.cohere} 
    alt="Cohere Command R+" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = '/logos/cohere.svg';
    }}
  />
);

// 15. Microsoft Phi-4 Official SVG Icon
export const Phi4Logo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.phi4} 
    alt="Microsoft Phi-4" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://upload.wikimedia.org/wikipedia/commons/f/f3/Microsoft-copilot-2026-seeklogo.svg';
    }}
  />
);

// 16. Amazon Nova / AWS Official Logo
export const AmazonLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.amazon} 
    alt="Amazon Web Services" 
    className={`${className} object-contain inline-block shrink-0`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg';
    }}
  />
);

// 17. MiniMax Official Logo
export const MiniMaxLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.minimax} 
    alt="MiniMax" 
    className={`${className} object-contain inline-block shrink-0 rounded-xs`} 
    referrerPolicy="no-referrer"
    onError={(e) => {
      e.currentTarget.src = 'https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/svg/minimax.svg';
    }}
  />
);

// 18. Xiaomi / MiMo Official Logo
export const XiaomiLogo: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <img 
    src={LOGO_URLS.xiaomi} 
    alt="Xiaomi MiMo" 
    className={`${className} object-contain inline-block shrink-0 rounded-xs`} 
    referrerPolicy="no-referrer"
  />
);

// General Dynamic ModelLogo Dispatcher
export const ModelLogo: React.FC<{ model?: string; modelId?: string; className?: string }> = ({ model, modelId, className = "w-4 h-4" }) => {
  const m = (model || modelId || "").toLowerCase();
  
  if (m.includes('mimo') || m.includes('xiaomi')) {
    return <XiaomiLogo className={className} />;
  }

  if (m.includes('minimax') || m.includes('mini-max')) {
    return <MiniMaxLogo className={className} />;
  }

  if (m.includes('amazon') || m.includes('nova') || m.includes('aws')) {
    return <AmazonLogo className={className} />;
  }

  if (m.includes('search') || m.includes('duckduckgo') || m.includes('google_search')) {
    return <SearchLogo className={className} />;
  }

  if (m.includes('perplexity') || m.includes('sonar')) {
    return <PerplexityLogo className={className} />;
  }

  if (m.includes('phi') || m.includes('phi-4') || m.includes('phi4') || m.includes('microsoft')) {
    return <Phi4Logo className={className} />;
  }

  if (m.includes('cohere') || m.includes('command')) {
    return <CohereLogo className={className} />;
  }

  if (m.includes('terra') || m.includes('gpt-oss') || m.includes('gpt_oss') || m.includes('gptoss') || m.includes('oss-120b')) {
    return <TerraLogo className={className} />;
  }

  if (m.includes('fable') || m === 'claude-3-opus' || m.includes('opus')) {
    return <FableLogo className={className} />;
  }

  if (m.includes('claude') || m.includes('haiku')) {
    return <ClaudeLogo className={className} />;
  }

  if (m.includes('anthropic')) {
    return <AnthropicLogo className={className} />;
  }

  if (m.includes('zai') || m.includes('glm')) {
    return <ZaiLogo className={className} />;
  }

  if (m.includes('kimi') || m.includes('moonshot')) {
    return <KimiLogo className={className} />;
  }

  if (m.includes('meta') || m.includes('llama')) {
    return <MetaLogo className={className} />;
  }
  
  if (m.includes('deepseek')) {
    return <DeepSeekLogo className={className} />;
  }
  
  if (m.includes('gpt') || m.includes('openai') || m.includes('chatgpt')) {
    return <ChatGPTLogo className={className} />;
  }
  
  if (m === 'google/gemini-pro-latest' || m === 'gemini-pro-latest') {
    return <GeminiProLogo className={className} />;
  }
  if (m.includes('gemini') || m.includes('google')) {
    return <GeminiLogo className={className} />;
  }

  if (m.includes('nvidia') || m.includes('nim')) {
    return <NvidiaLogo className={className} />;
  }

  if (m.includes('mistral')) {
    return <MistralLogo className={className} />;
  }

  if (m.includes('grok') || m.includes('xai')) {
    return <XAILogo className={className} />;
  }

  if (m.includes('qwen') || m.includes('alibaba')) {
    return <QwenLogo className={className} />;
  }

  // Default "auto" / Pentagon logo
  return <PentagonLogo className={className} />;
};

