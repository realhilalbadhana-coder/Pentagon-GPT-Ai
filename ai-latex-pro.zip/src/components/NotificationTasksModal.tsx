import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  BellRing, 
  BellOff, 
  Clock, 
  CheckCircle2, 
  Trash2, 
  Plus, 
  X, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Calendar, 
  AlertCircle, 
  Check, 
  RotateCcw,
  Zap
} from 'lucide-react';
import { ScheduledTask, TaskCategory } from '../types';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  playNotificationChime, 
  sendSystemNotification, 
  createScheduledTask, 
  loadScheduledTasks, 
  deleteTask, 
  updateTaskStatus, 
  snoozeTask, 
  formatTimeRemaining 
} from '../utils/reminderService';

interface NotificationTasksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTaskCreated?: (task: ScheduledTask) => void;
  theme?: string;
}

export const NotificationTasksModal: React.FC<NotificationTasksModalProps> = ({
  isOpen,
  onClose,
  onTaskCreated,
  theme
}) => {
  const [tasks, setTasks] = useState<ScheduledTask[]>([]);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [activeTab, setActiveTab] = useState<'active' | 'create' | 'history'>('active');

  // New task form state
  const [title, setTitle] = useState('');
  const [customDateTime, setCustomDateTime] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TaskCategory>('latex');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [systemNotification, setSystemNotification] = useState(true);
  const [, setTick] = useState(0);

  // Load tasks and permission on mount
  useEffect(() => {
    if (isOpen) {
      setTasks(loadScheduledTasks());
      setPermission(getNotificationPermission());
    }
  }, [isOpen]);

  // Live timer tick every 1s for accurate countdowns
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setTick(t => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setPermission(perm);
    if (perm === 'granted') {
      playNotificationChime('success');
      sendSystemNotification('Notifications Activated! 🔔', {
        body: 'You will now receive real-time alerts and sound chimes for all scheduled tasks and reminders.'
      });
    }
  };

  const handleTestNotification = () => {
    playNotificationChime('reminder');
    sendSystemNotification('Pentagon Real-Time Alert 🔔', {
      body: 'Testing notification & audio chime. Real-time tasks are working seamlessly!'
    });
  };

  const handleQuickAdd = (offsetMinutes: number, label: string) => {
    const targetTime = Date.now() + offsetMinutes * 60 * 1000;
    const targetDate = new Date(targetTime);
    const timeLabel = targetDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

    const newTask = createScheduledTask({
      title: title.trim() || `Task (${label})`,
      scheduledTime: targetTime,
      timeLabel: `Today at ${timeLabel}`,
      category: selectedCategory,
      soundEnabled,
      systemNotification
    });

    setTasks(loadScheduledTasks());
    setTitle('');
    setActiveTab('active');
    if (onTaskCreated) onTaskCreated(newTask);
    playNotificationChime('success');
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    let targetTime = Date.now() + 5 * 60 * 1000;
    if (customDateTime) {
      const parsed = new Date(customDateTime).getTime();
      if (!isNaN(parsed) && parsed > Date.now()) {
        targetTime = parsed;
      }
    }

    const targetDate = new Date(targetTime);
    const timeLabel = targetDate.toLocaleString([], { 
      month: 'short', 
      day: 'numeric', 
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    const newTask = createScheduledTask({
      title: title.trim(),
      scheduledTime: targetTime,
      timeLabel,
      category: selectedCategory,
      soundEnabled,
      systemNotification
    });

    setTasks(loadScheduledTasks());
    setTitle('');
    setCustomDateTime('');
    setActiveTab('active');
    if (onTaskCreated) onTaskCreated(newTask);
    playNotificationChime('success');
  };

  const handleDelete = (id: string) => {
    const updated = deleteTask(id);
    setTasks(updated);
  };

  const handleSnooze = (id: string, mins: number = 5) => {
    const updated = snoozeTask(id, mins);
    setTasks(updated);
    playNotificationChime('success');
  };

  const handleMarkCompleted = (id: string) => {
    const updated = updateTaskStatus(id, 'completed', { triggeredAt: Date.now() });
    setTasks(updated);
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'snoozed');
  const completedTasks = tasks.filter(t => t.status === 'completed' || t.status === 'triggered');

  const categories: { id: TaskCategory; label: string; icon: string }[] = [
    { id: 'latex', label: 'LaTeX & Paper', icon: '📜' },
    { id: 'academic', label: 'Academic & Study', icon: '🎓' },
    { id: 'personal', label: 'General Reminder', icon: '🔔' },
    { id: 'timer', label: 'Focus Timer', icon: '⏱️' },
    { id: 'urgent', label: 'Urgent Task', icon: '🚨' }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-xs z-[100] flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className={`w-full max-w-xl rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200 border ${
        theme === 'Night' 
          ? 'bg-[#161B22] text-gray-100 border-[#30363D]' 
          : 'bg-[#FCFBF9] text-[#1F1F1F] border-[#EAE8E2]'
      }`}>
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-black/5 dark:border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <BellRing className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">Real-Time Tasks & Notifications</h2>
                {pendingTasks.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white text-xs font-semibold">
                    {pendingTasks.length} active
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Scheduled alerts, timers, and background notifications
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Permission Request Banner (Mic / Camera Style Permission Card) */}
        {permission !== 'granted' && (
          <div className="mx-6 mt-4 p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/5 border border-amber-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs sm:text-sm font-semibold text-amber-900 dark:text-amber-200">
                  Allow Browser Notifications
                </h4>
                <p className="text-xs text-amber-700/80 dark:text-amber-300/70">
                  Enable permission to receive real-time popups and desktop chimes even when multitasking.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleRequestPermission}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs shrink-0 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Allow Access</span>
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('active')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'active'
                ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-[#161B22] shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Active Reminders ({pendingTasks.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('create')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'create'
                ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-[#161B22] shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Schedule New</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'history'
                ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-[#161B22] shadow-xs'
                : 'text-gray-600 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>History ({completedTasks.length})</span>
          </button>

          <button
            type="button"
            onClick={handleTestNotification}
            className="ml-auto p-2 rounded-xl text-gray-500 hover:text-gray-800 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-medium"
            title="Test notification sound and popup"
          >
            <Volume2 className="w-4 h-4 text-amber-500" />
            <span className="hidden sm:inline">Test Alert</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
          
          {/* TAB 1: ACTIVE REMINDERS */}
          {activeTab === 'active' && (
            <div className="space-y-3">
              {pendingTasks.length === 0 ? (
                <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-14 h-14 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-400">
                    <BellOff className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300">No Pending Reminders</h3>
                    <p className="text-xs text-gray-500 max-w-xs mt-1">
                      You can schedule tasks directly in the AI Chat (e.g. "Remind me at 9:10 PM") or use the button below.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('create')}
                    className="mt-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create Reminder</span>
                  </button>
                </div>
              ) : (
                pendingTasks.map(task => {
                  const isDue = task.scheduledTime <= Date.now();
                  const remainingStr = formatTimeRemaining(task.scheduledTime);

                  return (
                    <div 
                      key={task.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isDue 
                          ? 'bg-red-500/10 border-red-500/30 text-red-900 dark:text-red-200 animate-pulse' 
                          : 'bg-white dark:bg-[#1E242C] border-gray-200 dark:border-gray-800 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-sm ${
                          task.category === 'urgent' ? 'bg-red-100 dark:bg-red-950/50 text-red-600' :
                          task.category === 'latex' ? 'bg-blue-100 dark:bg-blue-950/50 text-blue-600' :
                          task.category === 'academic' ? 'bg-purple-100 dark:bg-purple-950/50 text-purple-600' :
                          'bg-amber-100 dark:bg-amber-950/50 text-amber-600'
                        }`}>
                          {task.category === 'urgent' ? '🚨' :
                           task.category === 'latex' ? '📜' :
                           task.category === 'academic' ? '🎓' :
                           task.category === 'timer' ? '⏱️' : '🔔'}
                        </div>

                        <div className="min-w-0">
                          <h4 className="text-sm font-semibold truncate text-[#1A1A1A] dark:text-white">
                            {task.title}
                          </h4>
                          <div className="flex items-center gap-2 mt-1 text-xs text-gray-500 dark:text-gray-400">
                            <span className="font-semibold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {remainingStr}
                            </span>
                            <span>•</span>
                            <span>{task.timeLabel}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                        <button
                          type="button"
                          onClick={() => handleSnooze(task.id, 5)}
                          className="px-2.5 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 text-xs font-medium text-gray-700 dark:text-gray-300 transition-colors cursor-pointer flex items-center gap-1"
                          title="Snooze +5 minutes"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>+5m</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleMarkCompleted(task.id)}
                          className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 transition-colors cursor-pointer"
                          title="Mark as completed"
                        >
                          <Check className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDelete(task.id)}
                          className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 transition-colors cursor-pointer"
                          title="Delete reminder"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 2: SCHEDULE NEW REMINDER */}
          {activeTab === 'create' && (
            <form onSubmit={handleCustomSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                  Task / Reminder Title
                </label>
                <input
                  type="text"
                  placeholder="e.g. Review LaTeX paper draft, Submit assignment, Focus break"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  autoFocus
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1E242C] text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 font-medium"
                />
              </div>

              {/* Quick Preset Time Chips */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                  Quick Time Presets
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { mins: 5, label: '5 Minutes' },
                    { mins: 15, label: '15 Minutes' },
                    { mins: 30, label: '30 Minutes' },
                    { mins: 60, label: '1 Hour' },
                  ].map(preset => (
                    <button
                      key={preset.mins}
                      type="button"
                      onClick={() => handleQuickAdd(preset.mins, preset.label)}
                      className="px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/20 text-xs font-medium text-gray-700 dark:text-gray-300 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Zap className="w-3 h-3 text-amber-500" />
                      <span>+{preset.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Date Time Picker */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                  Or Pick Exact Time (e.g. 9:10 PM)
                </label>
                <div className="relative">
                  <input
                    type="datetime-local"
                    value={customDateTime}
                    onChange={(e) => setCustomDateTime(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1E242C] text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 font-medium"
                  />
                </div>
              </div>

              {/* Category selector */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                  Category
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer flex items-center gap-1.5 ${
                        selectedCategory === cat.id
                          ? 'border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300 font-semibold'
                          : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] text-gray-600 dark:text-gray-400'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Alert Options */}
              <div className="pt-2 border-t border-gray-200 dark:border-gray-800 flex items-center justify-between gap-4 text-xs font-medium">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={soundEnabled}
                    onChange={(e) => setSoundEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                  <Volume2 className="w-3.5 h-3.5 text-gray-500" />
                  <span>Audio Chime Sound</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={systemNotification}
                    onChange={(e) => setSystemNotification(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                  <Bell className="w-3.5 h-3.5 text-gray-500" />
                  <span>OS Desktop Popup</span>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={!title.trim()}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <BellRing className="w-4 h-4" />
                <span>Save & Set Real-Time Reminder</span>
              </button>
            </form>
          )}

          {/* TAB 3: HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              {completedTasks.length === 0 ? (
                <div className="py-12 text-center text-xs text-gray-500">
                  No completed task history yet.
                </div>
              ) : (
                completedTasks.map(task => (
                  <div
                    key={task.id}
                    className="p-3.5 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white/60 dark:bg-[#1E242C]/60 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span className="font-medium text-gray-700 dark:text-gray-300 truncate">
                        {task.title}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-gray-400">{task.timeLabel}</span>
                      <button
                        type="button"
                        onClick={() => handleDelete(task.id)}
                        className="p-1 text-gray-400 hover:text-red-500 transition-colors cursor-pointer"
                        title="Delete from history"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-black/5 dark:border-white/10 flex items-center justify-between text-[11px] text-gray-500 dark:text-gray-400 bg-black/[0.02] dark:bg-white/[0.02] shrink-0">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${permission === 'granted' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            <span>Notification Access: {permission === 'granted' ? 'Active & Granted' : 'Default / Permission Needed'}</span>
          </div>
          <span>Natural Language Reminders Supported in Chat</span>
        </div>

      </div>
    </div>
  );
};
