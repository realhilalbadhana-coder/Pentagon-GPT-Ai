import React from 'react';
import { BellRing, Check, RotateCcw, X } from 'lucide-react';
import { ScheduledTask } from '../types';

interface ActiveReminderBannerProps {
  task: ScheduledTask | null;
  onDismiss: (taskId: string) => void;
  onSnooze: (taskId: string, minutes?: number) => void;
  onComplete: (taskId: string) => void;
}

export const ActiveReminderBanner: React.FC<ActiveReminderBannerProps> = ({
  task,
  onDismiss,
  onSnooze,
  onComplete
}) => {
  if (!task) return null;

  return (
    <div className="fixed top-4 right-4 sm:right-6 z-[120] max-w-md w-[calc(100vw-32px)] animate-in slide-in-from-top-4 fade-in duration-300">
      <div className="p-4 rounded-3xl bg-[#1F1F1F] dark:bg-white text-white dark:text-[#161B22] shadow-[0_12px_40px_rgba(0,0,0,0.35)] border border-amber-500/40 flex flex-col gap-3">
        
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center animate-bounce shrink-0 shadow-md">
              <BellRing className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 dark:text-amber-600 bg-amber-400/10 px-2 py-0.5 rounded-full">
                  Task Due Now 🔔
                </span>
                <span className="text-xs text-gray-400 dark:text-gray-500">
                  {task.timeLabel}
                </span>
              </div>
              <h3 className="text-sm sm:text-[15px] font-bold truncate mt-0.5">
                {task.title}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onDismiss(task.id)}
            className="w-7 h-7 rounded-full hover:bg-white/10 dark:hover:bg-black/10 flex items-center justify-center text-gray-400 hover:text-white dark:hover:text-black transition-colors cursor-pointer shrink-0"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-1 border-t border-white/10 dark:border-black/10">
          <button
            type="button"
            onClick={() => onComplete(task.id)}
            className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Mark Completed</span>
          </button>

          <button
            type="button"
            onClick={() => onSnooze(task.id, 5)}
            className="py-2 px-3 rounded-xl bg-white/10 dark:bg-black/10 hover:bg-white/20 text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1"
          >
            <RotateCcw className="w-3 h-3 text-amber-400 dark:text-amber-600" />
            <span>+5m Snooze</span>
          </button>
        </div>

      </div>
    </div>
  );
};
