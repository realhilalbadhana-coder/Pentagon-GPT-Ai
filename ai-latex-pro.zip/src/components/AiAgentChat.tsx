
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { getAccessToken } from '../lib/auth';
import { getRecentEmails, sendEmail } from '../lib/gmailApi';
import { User } from 'firebase/auth';
import { 
  onAuthStatusChanged, 
  signInWithGoogle, 
  signInWithGithub,
  signInWithMicrosoft,
  initGoogleOneTap,
  logOutFromGoogle, 
  saveSessionToFirestore, 
  loadSessionsFromFirestore, 
  deleteSessionFromFirestore, 
  saveProjectToFirestore, 
  loadProjectsFromFirestore, 
  deleteProjectFromFirestore,
  saveUserProfileToFirestore
} from '../lib/firebase';
import { Users, Mic, Settings, Filter, ListFilter,  MessageCircleDashed,
  PanelLeft,
  PenSquare,
  Pencil,
  Plus,
  Send,
  LogIn,
  ChevronDown, ArrowUp,
  ChevronUp,
  FolderPlus,
  Link,
  X,
  UserPlus,
  Folder,
  CheckSquare,
  Compass,
  Image as ImageIcon,
  LayoutGrid,
  Trash2,
  Check,
  Copy,
  Printer,
  FileText,
  FileCode,
  Camera,
  Paperclip,
  MoreVertical,
  Pin,
  Type,
  Share2,
  FolderInput,
  ShieldAlert,
  ChevronLeft,
  RefreshCw,
  Zap,
  ZapOff,
  Globe,
  Headphones,
  Waypoints,
  BookOpenCheck,
  ChevronRight,
  ExternalLink,
  Search,
  SlidersHorizontal,
  GraduationCap,
  Code2,
  Sigma,
  Sparkles,
  Calculator,
  Calendar,
  Mail,
  AtSign,
  Music,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Volume1,
  Repeat,
  Shuffle,
  Disc,
  Radio,
  ListMusic,
  Cloud,
  LogOut,
  CheckCircle2,
  Download,
  Loader2,
  Bell,
  BellRing,
  BellOff,
  Clock, RotateCcw, Rocket,
  Brain,
  Blend,
  AudioLines,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { CodeBlockWithRunner } from './CodeBlockWithRunner';
import { 
  downloadPdfFile, 
  downloadLatexSourceFile, 
  copyLatexCodeToClipboard, 
  exportVectorPdf, 
  openAcademicPdfPreview,
  exportMarkdownFile,
  exportDocxFile
} from '../utils/pdfExport';
import { LatexPdfExportModal } from './LatexPdfExportModal';

import { ActiveReminderBanner } from './ActiveReminderBanner';
import { useTextToSpeech } from "../utils/useTextToSpeech";
import { useLiveSpeechRecognition } from "../utils/useLiveSpeechRecognition";
import { useSpeechRecognition } from '../utils/useSpeechRecognition';
import { localStorageHelper } from '../utils/localStorageHelper';
import { ChatSession, UserProfile, Project, SearchSource, SearchImage, ScheduledTask } from '../types';
import { 
  parseReminderFromPrompt, 
  createScheduledTask, 
  loadScheduledTasks, 
  playNotificationChime, 
  sendSystemNotification, 
  getNotificationPermission, 
  requestNotificationPermission, 
  snoozeTask, 
  updateTaskStatus, 
  deleteTask 
} from '../utils/reminderService';
import { SettingsModal } from './SettingsModal';
import { AuthModal } from './AuthModal';
import { GoogleSignInButton } from './GoogleSignInButton';
import { GmailConnectButton } from './GmailConnectButton';
import {
  PentagonThumbUpIcon,
  PentagonThumbDownIcon,
  PentagonShareIcon,
  PentagonCopyIcon,
  PentagonVolumeIcon,
  PentagonMoreIcon,
  PentagonSmartAsteriskIcon,
  PentagonSearchIcon,
  SearchLogo,
  ModelLogo,
  AmazonLogo,
} from './ModelLogos';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  displayContent?: string;
  attachments?: AttachedDoc[];
  timestamp: string;
  actionTaken?: string | null;
  emailDraft?: { to: string, subject: string, body: string };
  feedback?: 'up' | 'down';
  model?: string;
  citations?: string[];
  sources?: SearchSource[];
  images?: SearchImage[];
  isNew?: boolean;
  suggestions?: string[];
  comparisonResults?: { modelId: string; modelName: string; content?: string; loading: boolean; provider?: string }[];
  connector?: string;
  musicTracks?: Array<{
    videoId: string;
    title: string;
    artist: string;
    duration?: string;
    thumbnailUrl: string;
    embedUrl: string;
  }>;
}

export interface AttachedDoc {
  id: string;
  name: string;
  size: number;
  type: string;
  previewUrl?: string;
  extractedText?: string;
  status: 'processing' | 'ready' | 'error';
  errorMessage?: string;
}

export type ModelType =
  | 'mimo-v2.5'
  | 'mimo-v2.5-pro'
  | 'auto'
  | 'search'
  | 'sonar-reasoning-pro'
  | 'perplexity'
  | 'meta'
  | 'deepseek-v4-flash-latest'
  | 'deepseek-r1'
  | 'deepseek-v4-pro'
  | 'deepseek'
  | 'openai/gpt-latest'
  | 'openai/gpt-mini-latest'
  | 'chatgpt'
  | 'google/gemini-pro-latest'
  | 'google/gemini-3.7-flash'
  | 'gemini'
  | 'claude'
  | 'claude-3-opus'
  | 'claude-haiku'
  | 'command-r-plus'
  | 'phi-4'
  | 'amazon/nova-2-lite-v1:free'
  | 'nvidia-fast'
  | 'nvidia-best'
  | 'nvidia-ultra'
  | 'mistral'
  | 'mistral-large'
  | 'grok-4.5'
  | 'grok-4.1-fast'
  | 'grok'
  | 'qwen'
  | 'kimi'
  | 'zai'
  | 'gpt-oss-120b'
  | 'minimax/minimax-m3'
  | 'minimax/minimax-m2.5'
  | 'minimax/minimax-m2.7:free';

export type ProviderType =
  | 'All'
  | 'MiniMax'
  | 'Amazon'
  | 'OpenAI'
  | 'Anthropic'
  | 'Google'
  | 'Microsoft'
  | 'DeepSeek'
  | 'Meta'
  | 'xAI'
  | 'Mistral'
  | 'NVIDIA'
  | 'Cohere'
  | 'Alibaba Qwen'
  | 'Perplexity'
  | 'Open Source'
  | 'Xiaomi';

interface ModelOption {
  id: ModelType;
  name: string;
  tagline: string;
  group: 'modes' | 'engines';
  provider: ProviderType;
  renderIcon: () => React.ReactNode;
  disabled?: boolean;
  badge?: React.ReactNode;
}

const PROVIDER_FILTERS: { id: ProviderType; label: string }[] = [
  { id: 'All', label: 'All Models' },
  { id: 'MiniMax', label: 'MiniMax' },
  { id: 'Amazon', label: 'Amazon AWS' },
  { id: 'OpenAI', label: 'OpenAI' },
  { id: 'Anthropic', label: 'Anthropic' },
  { id: 'Google', label: 'Google' },
  { id: 'Microsoft', label: 'Microsoft' },
  { id: 'DeepSeek', label: 'DeepSeek' },
  { id: 'Meta', label: 'Meta' },
  { id: 'xAI', label: 'xAI' },
  { id: 'Mistral', label: 'Mistral' },
  { id: 'NVIDIA', label: 'NVIDIA' },
  { id: 'Cohere', label: 'Cohere' },
  { id: 'Alibaba Qwen', label: 'Qwen' },
  { id: 'Perplexity', label: 'Perplexity' },
  { id: 'Open Source', label: 'Open Source' },
  { id: 'Xiaomi', label: 'Xiaomi' },
];

const ALL_MODELS: ModelOption[] = [
  {
    id: 'mimo-v2.5-pro',
    name: 'Xiaomi MiMo V2.5 Pro',
    tagline: 'Flagship multilingual reasoning',
    group: 'engines',
    provider: 'Xiaomi',
    renderIcon: () => <ModelLogo model="mimo-v2.5-pro" className="w-5 h-5" />,
  },
  {
    id: 'mimo-v2.5',
    name: 'Xiaomi MiMo V2.5',
    tagline: 'High-speed reasoning',
    group: 'engines',
    provider: 'Xiaomi',
    renderIcon: () => <ModelLogo model="mimo-v2.5" className="w-5 h-5" />,
  },
  // Primary Pentagon Modes (Original SVGs)
  {
    id: 'auto',
    name: 'Smart',
    tagline: 'Auto-adapts depth & speed',
    group: 'modes',
    provider: 'Google',
    renderIcon: () => <PentagonSmartAsteriskIcon className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" />,
  },
  // Frontier AI Engines
  {
    id: 'minimax/minimax-m3',
    name: 'MiniMax M3',
    tagline: 'Next-gen enterprise reasoning & intelligence',
    group: 'engines',
    provider: 'MiniMax',
    renderIcon: () => <ModelLogo model="minimax" className="w-5 h-5" />,
  },
  {
    id: 'minimax/minimax-m2.5',
    name: 'MiniMax M2.5',
    tagline: 'High-speed multimodal reasoning & coding',
    group: 'engines',
    provider: 'MiniMax',
    renderIcon: () => <ModelLogo model="minimax" className="w-5 h-5" />,
  },
  {
    id: 'minimax/minimax-m2.7:free',
    name: 'MiniMax M2.7 ',
    tagline: 'Ultra-fast versatile open reasoning ',
    group: 'engines',
    provider: 'MiniMax',
    renderIcon: () => <ModelLogo model="minimax" className="w-5 h-5" />,
  },
  {
    id: 'amazon/nova-2-lite-v1:free',
    name: 'Amazon Nova 2 Lite',
    tagline: 'High-speed multimodal reasoning ',
    group: 'engines',
    provider: 'Amazon',
    renderIcon: () => <ModelLogo model="amazon" className="w-5 h-5" />,
  },
  {
    id: 'phi-4',
    name: 'Microsoft Phi-4',
    tagline: 'Advanced synthetic reasoning',
    group: 'engines',
    provider: 'Microsoft',
    renderIcon: () => <ModelLogo model="phi-4" className="w-5 h-5" />,
  },
  {
    id: 'command-r-plus',
    name: 'Command R+',
    tagline: 'Cohere 104B reasoning & tool use',
    group: 'engines',
    provider: 'Cohere',
    renderIcon: () => <ModelLogo model="cohere" className="w-5 h-5" />,
  },
  {
    id: 'claude-haiku',
    name: 'Claude Haiku 4.5',
    tagline: 'Lightning fast & responsive',
    group: 'engines',
    provider: 'Anthropic',
    renderIcon: () => <ModelLogo model="haiku" className="w-5 h-5" />,
  },
  {
    id: 'claude-3-opus',
    name: 'Claude 3 Opus',
    tagline: 'Flagship deep reasoning',
    group: 'engines',
    provider: 'Anthropic',
    renderIcon: () => <ModelLogo model="anthropic" className="w-5 h-5" />,
  },
  {
    id: 'claude',
    name: 'Sonnet 5',
    tagline: 'High-precision writing & analysis',
    group: 'engines',
    provider: 'Anthropic',
    renderIcon: () => <ModelLogo model="claude" className="w-5 h-5" />,
  },
  {
    id: 'sonar-reasoning-pro',
    name: 'Sonar Reasoning Pro',
    tagline: 'Deep chain-of-thought & web citations',
    group: 'engines',
    provider: 'Perplexity',
    renderIcon: () => <ModelLogo model="sonar-reasoning-pro" className="w-5 h-5" />,
  },
  {
    id: 'perplexity',
    name: 'Perplexity Sonar',
    tagline: 'Deep research & citation engine',
    group: 'engines',
    provider: 'Perplexity',
    renderIcon: () => <ModelLogo model="perplexity" className="w-5 h-5" />,
  },
  {
    id: 'meta',
    name: 'Meta Llama 4',
    tagline: 'Open-weight flagship intelligence',
    group: 'engines',
    provider: 'Meta',
    renderIcon: () => <ModelLogo model="meta" className="w-5 h-5" />,
  },
  {
    id: 'deepseek-v4-flash-latest',
    name: 'DeepSeek V4 Flash',
    tagline: 'Ultra-fast next-gen generation & low latency',
    group: 'engines',
    provider: 'DeepSeek',
    renderIcon: () => <ModelLogo model="deepseek" className="w-5 h-5" />,
  },
  {
    id: 'deepseek-r1',
    name: 'DeepSeek R1',
    tagline: 'Deep reasoning & breakthrough chain-of-thought',
    group: 'engines',
    provider: 'DeepSeek',
    renderIcon: () => <ModelLogo model="deepseek" className="w-5 h-5" />,
  },
  {
    id: 'deepseek-v4-pro',
    name: 'DeepSeek V4 Pro',
    tagline: 'Maximum capability reasoning & complex problem solving',
    group: 'engines',
    provider: 'DeepSeek',
    renderIcon: () => <ModelLogo model="deepseek" className="w-5 h-5" />,
  },
  {
    id: 'deepseek',
    name: 'DeepSeek V3',
    tagline: 'Ultra-fast math & coding logic',
    group: 'engines',
    provider: 'DeepSeek',
    renderIcon: () => <ModelLogo model="deepseek" className="w-5 h-5" />,
  },
  {
    id: 'openai/gpt-latest',
    name: 'OpenAI GPT Latest',
    tagline: 'Premier OpenAI flagship reasoning & intelligence',
    group: 'engines',
    provider: 'OpenAI',
    renderIcon: () => <ModelLogo model="chatgpt" className="w-5 h-5" />,
  },
  {
    id: 'openai/gpt-mini-latest',
    name: 'OpenAI GPT Mini Latest',
    tagline: 'High-speed compact intelligence & low latency',
    group: 'engines',
    provider: 'OpenAI',
    renderIcon: () => <ModelLogo model="chatgpt" className="w-5 h-5" />,
  },
  {
    id: 'chatgpt',
    name: 'ChatGPT 4o',
    tagline: 'OpenAI conversational flagship',
    group: 'engines',
    provider: 'OpenAI',
    renderIcon: () => <ModelLogo model="chatgpt" className="w-5 h-5" />,
  },
  {
    id: 'google/gemini-pro-latest',
    name: 'Google Gemini Pro Latest',
    tagline: 'Frontier Google multimodal reasoning & coding',
    group: 'engines',
    provider: 'Google',
    renderIcon: () => <ModelLogo model="gemini" className="w-5 h-5" />,
  },
  {
    id: 'google/gemini-3.7-flash',
    name: 'Google Gemini 3.7 Flash',
    tagline: 'Next-gen hybrid reasoning & lightning speed',
    group: 'engines',
    provider: 'Google',
    renderIcon: () => <ModelLogo model="gemini" className="w-5 h-5" />,
  },
  {
    id: 'gemini',
    name: 'Gemini 3.7 Flash',
    tagline: 'Google multimodal reasoning',
    group: 'engines',
    provider: 'Google',
    renderIcon: () => <ModelLogo model="gemini" className="w-5 h-5" />,
  },
  {
    id: 'nvidia-best',
    name: 'NVIDIA Nemotron 70B',
    tagline: 'Enterprise reasoning model',
    group: 'engines',
    provider: 'NVIDIA',
    renderIcon: () => <ModelLogo model="nvidia" className="w-5 h-5" />,
  },
  {
    id: 'nvidia-ultra',
    name: 'NVIDIA Nemotron Ultra',
    tagline: 'Ultra-scale intelligent reasoning',
    group: 'engines',
    provider: 'NVIDIA',
    renderIcon: () => <ModelLogo model="nvidia" className="w-5 h-5" />,
  },
  {
    id: 'nvidia-fast',
    name: 'NVIDIA Lightning',
    tagline: 'Ultra high-throughput inference',
    group: 'engines',
    provider: 'NVIDIA',
    renderIcon: () => <ModelLogo model="nvidia" className="w-5 h-5" />,
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    tagline: 'Fast European intelligence',
    group: 'engines',
    provider: 'Mistral',
    renderIcon: () => <ModelLogo model="mistral" className="w-5 h-5" />,
  },
  {
    id: 'mistral-large',
    name: 'Mistral Large 2',
    tagline: '128k flagship context model',
    group: 'engines',
    provider: 'Mistral',
    renderIcon: () => <ModelLogo model="mistral" className="w-5 h-5" />,
  },
  {
    id: 'grok-4.5',
    name: 'xAI Grok 4.5',
    tagline: 'Next-gen flagship reasoning & knowledge',
    group: 'engines',
    provider: 'xAI',
    renderIcon: () => <ModelLogo model="grok-4.5" className="w-5 h-5" />,
  },
  {
    id: 'grok-4.1-fast',
    name: 'xAI Grok 4.1 Fast',
    tagline: 'Ultra-low latency conversational engine',
    group: 'engines',
    provider: 'xAI',
    renderIcon: () => <ModelLogo model="grok-4.1-fast" className="w-5 h-5" />,
  },
  {
    id: 'grok',
    name: 'xAI Grok',
    tagline: 'Direct, witty & fast intelligence',
    group: 'engines',
    provider: 'xAI',
    renderIcon: () => <ModelLogo model="grok" className="w-5 h-5" />,
  },
  {
    id: 'qwen',
    name: 'Qwen 3 Next',
    tagline: 'Multilingual & STEM expertise',
    group: 'engines',
    provider: 'Alibaba Qwen',
    renderIcon: () => <ModelLogo model="qwen" className="w-5 h-5" />,
  },
  {
    id: 'gpt-oss-120b',
    name: 'GPT-5.6 Terra',
    tagline: 'Ultra-fast open weights engine',
    group: 'engines',
    provider: 'OpenAI',
    renderIcon: () => <ModelLogo model="chatgpt" className="w-5 h-5" />,
    badge: (
      <span className="flex items-center gap-0.5 px-1.5 py-[1px] rounded text-[9px] font-bold uppercase tracking-wider bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-sm ml-1.5 shrink-0" title="Premium">
        <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5"><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
        PRO
      </span>
    )
  },
  {
    id: 'zai',
    name: 'Z.AI GLM-5.2',
    tagline: 'High-capability bilingual engine',
    group: 'engines',
    provider: 'Open Source',
    renderIcon: () => <ModelLogo model="zai" className="w-5 h-5" />,
  },
  {
    id: 'kimi',
    name: 'Kimi k2.7 Code',
    tagline: 'Specialized coding & long context',
    group: 'engines',
    provider: 'Open Source',
    renderIcon: () => <ModelLogo model="kimi" className="w-5 h-5" />,
  },
];

export interface ConnectorItem {
  id: string;
  name: string;
  tag: string;
  description: string;
  category: 'Specialists' | 'Tools' | 'Integrations';
  iconType: 'lucide' | 'image';
  lucideIcon?: any;
  imageUrl?: string;
  color: string;
  bgColor: string;
  textColor: string;
  borderColor: string;
  placeholder: string;
  suggestions: string[];
  systemPrompt?: string;
}

export const CONNECTORS_LIST: ConnectorItem[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    tag: 'YouTube',
    description: 'Extract transcripts, summarize & analyze YouTube video links',
    category: 'Tools',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg',
    color: '#ef4444',
    bgColor: 'bg-red-50 dark:bg-red-950/50',
    textColor: 'text-red-600 dark:text-red-400',
    borderColor: 'border-red-200 dark:border-red-800',
    placeholder: 'Paste YouTube link or ask about a video...',
    suggestions: [
      'Summarize this video in 5 bullet points',
      'Extract key timestamps & chapters',
      'Translate video transcript to English',
      'Explain the main takeaways of this video'
    ]
  },
  {
    id: 'youtube_music',
    name: 'YouTube Music',
    tag: 'Music',
    description: 'Search & stream songs, artists & tracks with zero API limits',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/6a/Youtube_Music_icon.svg',
    color: '#ff0000',
    bgColor: 'bg-red-50 dark:bg-red-950/50',
    textColor: 'text-red-600 dark:text-red-400',
    borderColor: 'border-red-200 dark:border-red-800',
    placeholder: 'Search any song, artist, album, or track (e.g. Tum Hi Ho)...',
    suggestions: [
      'Play Tum Hi Ho by Arijit Singh',
      'Play Dil Dil Pakistan',
      'Find trending Hindi songs',
      'Search lofi chill beats music'
    ]
  },
  {
    id: 'google_drive',
    name: 'Google Drive',
    tag: 'Drive',
    description: 'Search & reference files and docs stored in Google Drive',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/5f/Google_Drive_icon_%282026%29.svg',
    color: '#0f9d58',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/50',
    textColor: 'text-emerald-600 dark:text-emerald-400',
    borderColor: 'border-emerald-200 dark:border-emerald-800',
    placeholder: 'Query Google Drive files...',
    suggestions: [
      'Search my Drive for recent project spreadsheets',
      'Find meeting notes document from last week',
      'Summarize documents shared with me recently'
    ]
  },
  {
    id: 'gmail',
    name: 'Gmail',
    tag: 'Gmail',
    description: 'Draft, search, and manage email conversations',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8f/Gmail_icon_%282026%29.svg',
    color: '#ea4335',
    bgColor: 'bg-red-50 dark:bg-red-950/50',
    textColor: 'text-red-600 dark:text-red-400',
    borderColor: 'border-red-200 dark:border-red-800',
    placeholder: 'Draft an email or query Gmail inbox...',
    suggestions: [
      'Check my latest unread emails',
      'Draft a polite follow-up email about the project status',
      'Summarize recent emails from my manager'
    ]
  },
  {
    id: 'google_calendar',
    name: 'Google Calendar',
    tag: 'Calendar',
    description: 'Schedule meetings, check agenda and manage events',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Google_Calendar_icon_%282026%29.svg',
    color: '#4285f4',
    bgColor: 'bg-blue-50 dark:bg-blue-950/50',
    textColor: 'text-blue-600 dark:text-blue-400',
    borderColor: 'border-blue-200 dark:border-blue-800',
    placeholder: 'Check schedule or create calendar event...',
    suggestions: [
      'What meetings do I have scheduled today?',
      'Create a meeting with team tomorrow at 3 PM',
      'Find free time slots for this Thursday'
    ]
  },
  {
    id: 'google_contacts',
    name: 'Google Contacts',
    tag: 'Contacts',
    description: 'Look up colleague contact details & address book',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a8/Google_Contacts_icon_%282022%29.svg',
    color: '#1a73e8',
    bgColor: 'bg-blue-50 dark:bg-blue-950/50',
    textColor: 'text-blue-600 dark:text-blue-400',
    borderColor: 'border-blue-200 dark:border-blue-800',
    placeholder: 'Search Google Contacts...',
    suggestions: [
      'Find contact details for Alex',
      'Show contact card for team lead'
    ]
  },
  {
    id: 'dropbox',
    name: 'Dropbox',
    tag: 'Dropbox',
    description: 'Access and reference files stored in Dropbox',
    category: 'Integrations',
    iconType: 'image',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/cb/Dropbox_logo_2017.svg',
    color: '#0061ff',
    bgColor: 'bg-blue-50 dark:bg-blue-950/50',
    textColor: 'text-blue-600 dark:text-blue-400',
    borderColor: 'border-blue-200 dark:border-blue-800',
    placeholder: 'Query Dropbox files...',
    suggestions: [
      'Find recent Dropbox documents',
      'Search shared project folder in Dropbox'
    ]
  }
];

export const PentagonMusicPlayerCard: React.FC<{
  tracks: Array<{
    videoId: string;
    title: string;
    artist: string;
    duration?: string;
    thumbnailUrl: string;
    embedUrl: string;
  }>;
}> = ({ tracks }) => {
  const [activeTrackIndex, setActiveTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [isLooping, setIsLooping] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  // Unique instance ID for global audio coordination
  const instanceId = useMemo(() => 'player_' + Math.random().toString(36).substring(2, 9), []);

  const currentTrack = tracks[activeTrackIndex] || tracks[0];

  // Parse duration string (e.g. "3:45" or "04:12" -> seconds)
  const totalDuration = useMemo(() => {
    if (!currentTrack?.duration) return 210;
    const parts = currentTrack.duration.split(':').map(Number);
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      return parts[0] * 60 + parts[1];
    } else if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    return 210;
  }, [currentTrack?.duration]);

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Send postMessage to audio iframe
  const sendIframeCommand = useCallback((func: string, args: any[] = []) => {
    try {
      if (iframeRef.current && iframeRef.current.contentWindow) {
        iframeRef.current.contentWindow.postMessage(
          JSON.stringify({ event: 'command', func, args }),
          '*'
        );
      }
    } catch (e) {
      // Ignore cross-origin warnings
    }
  }, []);

  // Broadcast to pause all other music players when this one plays
  const broadcastPlay = useCallback(() => {
    window.dispatchEvent(new CustomEvent('pentagon-global-audio-play', { detail: { id: instanceId } }));
  }, [instanceId]);

  // Listen for other players starting and pause this one
  useEffect(() => {
    const handleOtherPlay = (e: any) => {
      if (e?.detail?.id && e.detail.id !== instanceId) {
        sendIframeCommand('pauseVideo');
        setIsPlaying(false);
      }
    };
    window.addEventListener('pentagon-global-audio-play', handleOtherPlay);
    return () => window.removeEventListener('pentagon-global-audio-play', handleOtherPlay);
  }, [instanceId, sendIframeCommand]);

  // When card mounts with autoplay, stop other players
  useEffect(() => {
    broadcastPlay();
  }, [broadcastPlay]);

  // Sync state on track change
  useEffect(() => {
    setCurrentTime(0);
    setIsPlaying(true);
    broadcastPlay();
  }, [activeTrackIndex, broadcastPlay]);

  // Progress timer
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= totalDuration) {
            if (isLooping) {
              sendIframeCommand('seekTo', [0, true]);
              return 0;
            } else if (tracks.length > 1) {
              setActiveTrackIndex(p => (p + 1) % tracks.length);
              return 0;
            } else {
              setIsPlaying(false);
              return totalDuration;
            }
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration, isLooping, tracks.length, sendIframeCommand]);

  const togglePlayPause = () => {
    if (isPlaying) {
      sendIframeCommand('pauseVideo');
      setIsPlaying(false);
    } else {
      broadcastPlay();
      sendIframeCommand('playVideo');
      setIsPlaying(true);
    }
  };

  const handleNext = () => {
    broadcastPlay();
    setActiveTrackIndex(prev => (prev + 1) % tracks.length);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handlePrev = () => {
    broadcastPlay();
    if (currentTime > 4) {
      setCurrentTime(0);
      sendIframeCommand('seekTo', [0, true]);
    } else {
      setActiveTrackIndex(prev => (prev - 1 + tracks.length) % tracks.length);
      setCurrentTime(0);
      setIsPlaying(true);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSec = Number(e.target.value);
    setCurrentTime(newSec);
    sendIframeCommand('seekTo', [newSec, true]);
  };

  if (!currentTrack) return null;

  const progressPercent = totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;

  return (
    <div className="mt-3 bg-[#1A1D24] dark:bg-[#12141A] text-white border border-[#2D333F] dark:border-[#252A36] rounded-2xl p-3 sm:p-3.5 shadow-md max-w-lg w-full overflow-hidden animate-in fade-in duration-200 select-none">
      {/* Headless Audio Engine */}
      <iframe
        ref={iframeRef}
        key={currentTrack.videoId}
        src={`https://www.youtube-nocookie.com/embed/${currentTrack.videoId}?enablejsapi=1&autoplay=1&controls=0&modestbranding=1&rel=0&iv_load_policy=3&playsinline=1`}
        title={currentTrack.title}
        className="absolute -top-[9999px] -left-[9999px] w-1 h-1 opacity-0 pointer-events-none"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      />

      {/* Main Rectangular Player Bar */}
      <div className="flex items-center gap-3">
        {/* Song Artwork Logo / Thumbnail */}
        <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-black/40 shrink-0 border border-white/10 shadow-xs">
          <img
            src={currentTrack.thumbnailUrl}
            alt={currentTrack.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Track Title & Artist Info */}
        <div className="flex-1 min-w-0 pr-1">
          <h4 className="text-[13.5px] sm:text-[14px] font-semibold text-gray-100 truncate leading-tight">
            {currentTrack.title}
          </h4>
          <p className="text-[11.5px] sm:text-xs text-gray-400 truncate mt-0.5 font-medium">
            {currentTrack.artist}
          </p>
        </div>

        {/* Essential Controls: Prev, Play/Pause, Next, Loop, and Change Track */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Previous Button */}
          <button
            type="button"
            onClick={handlePrev}
            className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 active:scale-95 transition-colors cursor-pointer"
            title="Previous Track"
          >
            <SkipBack className="w-4 h-4 fill-current" />
          </button>

          {/* Play/Pause Button */}
          <button
            type="button"
            onClick={togglePlayPause}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white text-black hover:bg-gray-200 active:scale-90 flex items-center justify-center shadow-xs transition-all cursor-pointer shrink-0"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          {/* Next Button */}
          <button
            type="button"
            onClick={handleNext}
            className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 active:scale-95 transition-colors cursor-pointer"
            title="Next Track"
          >
            <SkipForward className="w-4 h-4 fill-current" />
          </button>

          {/* Loop Button */}
          <button
            type="button"
            onClick={() => setIsLooping(!isLooping)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isLooping ? 'text-white bg-white/20' : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
            }`}
            title={isLooping ? 'Loop is ON' : 'Loop is OFF'}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          {/* Change Track (If Multiple Matches) */}
          {tracks.length > 1 && (
            <button
              type="button"
              onClick={handleNext}
              className="ml-1 px-2 py-1 rounded-md bg-white/10 hover:bg-white/15 text-[11px] font-medium text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
              title="Switch to next matching song"
            >
              <span>Change</span>
              <span className="text-[10px] text-gray-400">({activeTrackIndex + 1}/{tracks.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Sleek Progress Scrubber */}
      <div className="mt-2.5 pt-1 flex items-center gap-2">
        <span className="text-[10px] font-mono text-gray-400 min-w-[28px]">
          {formatTime(currentTime)}
        </span>
        <div className="relative flex-1 flex items-center">
          <input
            type="range"
            min={0}
            max={totalDuration}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer accent-white hover:h-1.5 transition-all"
            style={{
              background: `linear-gradient(to right, #FFFFFF ${progressPercent}%, rgba(255, 255, 255, 0.2) ${progressPercent}%)`
            }}
          />
        </div>
        <span className="text-[10px] font-mono text-gray-400 min-w-[28px] text-right">
          {formatTime(totalDuration)}
        </span>
      </div>
    </div>
  );
};

// Aliased export for compatibility
export const YouTubeMusicPlayerCard = PentagonMusicPlayerCard;

// Helper to extract raw string from React children (for the strong tags)
const extractText = (children: any): string => {
  if (typeof children === 'string') return children;
  if (typeof children === 'number') return children.toString();
  if (Array.isArray(children)) return children.map(extractText).join('');
  if (children && children.props && children.props.children) {
    return extractText(children.props.children);
  }
  return '';
};

// Universal LaTeX & Math Preprocessor for KaTeX
function preprocessMathForKaTeX(content: string): string {
  if (!content) return '';

  // Split by code blocks (```...``` and `...`) to avoid modifying code blocks
  const parts = content.split(/(```[\s\S]*?```|`[^`]*`)/g);

  for (let i = 0; i < parts.length; i++) {
    // If it's a code block, leave it untouched
    if (parts[i].startsWith('```') || (parts[i].startsWith('`') && parts[i].endsWith('`'))) {
      continue;
    }

    let segment = parts[i];

    // 1. Clean citation brackets
    segment = segment
      .replace(/\(\s*(\[[^\]]+\]\([^)]+\))\s*\)/g, ' $1')
      .replace(/\[\s*(\[[^\]]+\]\([^)]+\))\s*\]/g, ' $1')
      .replace(/\(\s*Sources?:\s*(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1')
      .replace(/\(\s*Source\s*(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1')
      .replace(/\(\s*see\s+(\[[^\]]+\]\([^)]+\))\s*\)/gi, ' $1');

    // 2. Display math: \[ ... \] and \\[ ... \\] -> \n\n$$\n...\n$$\n\n
    segment = segment.replace(/\\\\?\[([\s\S]*?)\\\\?\]/g, (_, math) => {
      return `\n\n$$\n${math.trim()}\n$$\n\n`;
    });

    // 3. Inline math: \( ... \) and \\( ... \\) -> $...$
    segment = segment.replace(/\\\\?\(([\s\S]*?)\\\\?\)/g, (_, math) => {
      return `$${math.trim()}$`;
    });

    // 4. Wrap bare LaTeX environments (\begin{equation}, \begin{align}, etc.) in $$ if not already wrapped
    const mathEnv = 'equation|equation\\*|align|align\\*|aligned|gather|gather\\*|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|cases|split|multline|multline\\*';
    const envRegex = new RegExp(`(?<!\\$\\$\\s*)(?:\\\\begin\\{(${mathEnv})\\}[\\s\\S]*?\\\\end\\{\\1\\})(?!\\s*\\$\\$)`, 'g');
    segment = segment.replace(envRegex, (m) => `\n\n$$\n${m.trim()}\n$$\n\n`);

    // 5. Ensure $$ blocks have clean newlines around them so remark-math parses them accurately
    segment = segment.replace(/([^\n])\s*\$\$\s*([\s\S]*?)\s*\$\$/g, '$1\n\n$$\n$2\n$$');
    segment = segment.replace(/\$\$\s*([\s\S]*?)\s*\$\$\s*([^\n])/g, '$$\n$1\n$$\n\n$2');

    parts[i] = segment;
  }

  return parts.join('');
}

interface TypingMarkdownProps {
  content: string;
  isNew?: boolean;
  onComplete: () => void;
  components: any;
  remarkPlugins: any[];
  rehypePlugins: any[];
}

function TypingMarkdown({ content, isNew, onComplete, components, remarkPlugins, rehypePlugins }: TypingMarkdownProps) {
  const loadingStatus = "Formatting";
  const [displayedContent, setDisplayedContent] = useState(isNew ? '' : content);
  const [isTyping, setIsTyping] = useState(isNew);
  const [isPreparing, setIsPreparing] = useState(isNew);
  const indexRef = useRef(0);
  
  useEffect(() => {
    if (!isNew) {
      setDisplayedContent(content);
      setIsTyping(false);
      setIsPreparing(false);
      return;
    }

    let timeoutId: any;

    if (isPreparing) {
      const delay = 50; // Super fast load
      timeoutId = setTimeout(() => {
        setIsPreparing(false);
      }, delay);
      return () => clearTimeout(timeoutId);
    }

    if (isTyping && indexRef.current < content.length) {
      const typeChar = () => {
        if (!isTyping) return;
        
        // Very fast stream: 8 to 18 characters per frame (avoids huge height jumps, but still incredibly fast)
        const charsRemaining = content.length - indexRef.current;
        const chunkSize = Math.min(charsRemaining, Math.floor(Math.random() * 20) + 30); // Very fast typing 
        
        indexRef.current += chunkSize;
        setDisplayedContent(content.substring(0, indexRef.current));

        if (indexRef.current >= content.length) {
          setIsTyping(false);
          if (onComplete) onComplete();
          return;
        }

        // 10ms to 20ms delay (60fps feel). Extremely smooth and fast without wasting time.
        const delay = Math.floor(Math.random() * 10) + 10;
        timeoutId = setTimeout(typeChar, delay);
      };

      timeoutId = setTimeout(typeChar, 30);
      return () => clearTimeout(timeoutId);
    }
  }, [content, isNew, isPreparing, isTyping, onComplete]);

  if (isPreparing) {
    return (
      <div className="flex flex-col space-y-2 animate-in fade-in py-2">
        <div className="flex items-center gap-1.5 text-sm text-gray-500">
          <span>{loadingStatus}</span>
                    <span className="inline-flex gap-1 pt-1">
            <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
            <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
            <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="smoke-reveal-wrapper">
      <ReactMarkdown
        remarkPlugins={remarkPlugins}
        rehypePlugins={rehypePlugins}
        components={components}
        urlTransform={(value) => value}
      >
        {preprocessMathForKaTeX(displayedContent)}
      </ReactMarkdown>
    </div>
  );
}

const memoizedRemarkPlugins: any[] = [remarkGfm, [remarkMath, { singleDollarTextMath: true }]];
const memoizedRehypePlugins: any[] = [[rehypeKatex, { output: 'htmlAndMathml', throwOnError: false, strict: false }]];

export function AiAgentChat({ theme, onThemeChange }: { theme?: string, onThemeChange?: (theme: string) => void }) {
  // LocalStorage & Session state
  const [sessions, setSessions] = useState<ChatSession[]>(() => localStorageHelper.getSessions());
    const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [renamingSessionId, setRenamingSessionId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState<string>('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleRenameSubmit = (sessionId: string) => {
    if (renameValue.trim()) {
      setSessions(prev => {
        const updated = prev.map(s => s.id === sessionId ? { ...s, title: renameValue.trim() } : s);
        localStorageHelper.saveSessions(updated);
        return updated;
      });
    }
    setRenamingSessionId(null);
  };

  const togglePin = (sessionId: string) => {
    setSessions(prev => {
      const updated = prev.map(s => s.id === sessionId ? { ...s, isPinned: !s.isPinned } : s);
      localStorageHelper.saveSessions(updated);
      return updated;
    });
    showToast("Pin status updated");
  };

  const handleCopyConversation = (sessionId: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (session) {
      const text = session.messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n\n');
      navigator.clipboard.writeText(text);
      showToast("Conversation copied to clipboard");
    }
  };

  
  const [projects, setProjects] = useState<Project[]>(() => localStorageHelper.getProjects());
  const [isProjectsExpanded, setIsProjectsExpanded] = useState(false);
  const [showCreateProject, setShowCreateProject] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [isTemporary, setIsTemporary] = useState(false);
  const [showMoveSubmenuId, setShowMoveSubmenuId] = useState<string | null>(null);

  const handleCreateProject = () => {
    if (!newProjectName.trim()) return;
    const proj = localStorageHelper.createProject(newProjectName.trim());
    setProjects(prev => [proj, ...prev]);
    if (authUser) {
      saveProjectToFirestore(authUser.uid, proj);
    }
    setNewProjectName('');
    setShowCreateProject(false);
    showToast("Project created successfully");
  };

  const handleMoveToProject = (sessionId: string, projectId: string | null) => {
    setSessions(prev => {
      const updated = prev.map(s => s.id === sessionId ? { ...s, projectId } : s);
      localStorageHelper.saveSessions(updated);
      return updated;
    });
    showToast("Moved to project");
    setActiveMenuId(null);
    setShowMoveSubmenuId(null);
  };

  const handleInvite = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast("Invite link copied to clipboard");
    } else {
      showToast("Invite link ready to share");
    }
  };

  const handleSummarize = (sessionId: string) => {
    if (currentSessionId !== sessionId) {
      handleSelectSession(sessionId);
    }
    setTimeout(() => {
      handleSend("Please provide a concise summary of our conversation so far.");
    }, 100);
    showToast("Requesting summary...");
  };

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => {
    const savedId = localStorageHelper.getCurrentSessionId();
    const existing = localStorageHelper.getSessions();
    if (savedId && existing.some(s => s.id === savedId)) {
      return savedId;
    }
    if (existing.length > 0) {
      return existing[0].id;
    }
    const fresh = localStorageHelper.createNewSession();
    return fresh.id;
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const existing = localStorageHelper.getSessions();
    const activeId = localStorageHelper.getCurrentSessionId();
    const found = existing.find(s => s.id === (activeId || existing[0]?.id));
    return found ? found.messages : [];
  });

  const [input, setInput] = useState<string>(() => localStorageHelper.getDraftInput());
  const [loading, setLoading] = useState(false);


  const [loadingStatus, setLoadingStatus] = useState("Thinking");
  const [preferredModel, setPreferredModel] = useState<ModelType>(() => {
    return (localStorageHelper.getPreferredModel('auto') as ModelType) || 'auto';
  });
  const [searchMode, setSearchMode] = useState<boolean>(() => localStorageHelper.getSearchMode(false));

  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => localStorageHelper.getUserProfile());
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);
  const [authLoadingProvider, setAuthLoadingProvider] = useState<string | null>(null);
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);

  // Listen to Google Auth status and sync with Firestore database
  useEffect(() => {
    const unsubscribe = onAuthStatusChanged(async (user) => {
      setAuthUser(user);
      if (!user) {
        // Trigger Google One Tap in-app bottom sheet (like Perplexity)
        setTimeout(() => {
          initGoogleOneTap();
        }, 1200);
      }
      if (user) {
        setIsCloudSyncing(true);
        try {
          // Sync profile to Firestore
          await saveUserProfileToFirestore(user, userProfile || undefined);
          
          // Load sessions from Firestore
          const cloudSessions = await loadSessionsFromFirestore(user.uid);
          const localSessions = localStorageHelper.getSessions();
          
          if (cloudSessions && cloudSessions.length > 0) {
            // Merge cloud and local sessions
            const sessionMap = new Map<string, ChatSession>();
            cloudSessions.forEach(s => sessionMap.set(s.id, s));
            localSessions.forEach(s => {
              if (!sessionMap.has(s.id)) {
                sessionMap.set(s.id, s);
                saveSessionToFirestore(user.uid, s);
              }
            });
            const merged = Array.from(sessionMap.values()).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
            setSessions(merged);
            localStorageHelper.saveSessions(merged);
          } else if (localSessions && localSessions.length > 0) {
            // Batch upload local sessions to Firestore
            for (const s of localSessions) {
              await saveSessionToFirestore(user.uid, s);
            }
          }

          // Load cloud projects
          const cloudProjects = await loadProjectsFromFirestore(user.uid);
          if (cloudProjects && cloudProjects.length > 0) {
            setProjects(cloudProjects);
            localStorageHelper.saveProjects(cloudProjects);
          }
        } catch (e) {
          console.error('[Firestore Sync Error]:', e);
        } finally {
          setIsCloudSyncing(false);
        }
      }
    });

    return () => unsubscribe();
  }, []);
  const [showSettings, setShowSettings] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showModelMenu, setShowModelMenu] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [showProviderFilter, setShowProviderFilter] = useState(false);
  const [selectedProviderFilter, setSelectedProviderFilter] = useState<ProviderType>('All');
  const [modelSearchQuery, setModelSearchQuery] = useState<string>('');
  const [activeModelTab, setActiveModelTab] = useState<'Popular' | 'Latest' | 'All'>('Popular');

  const POPULAR_IDS = [
    'gpt-oss-120b', // GPT-5.6 Terra
    'claude-3-opus', 
    'google/gemini-pro-latest',
    'deepseek-v4-flash-latest',
    'sonar-reasoning-pro', // Perplexity Sonar
    'nvidia-ultra',
    'mistral-large',
    'minimax/minimax-m3',
    'grok-4.5',
    'chatgpt'
  ];

  const LATEST_IDS = [
    'mimo-v2.5-pro',
    'mimo-v2.5',
    'amazon/nova-2-lite-v1:free',
    'command-r-plus',
    'phi-4',
    'nvidia-ultra',
    'nvidia-best',
    'nvidia-fast',
    'openai/gpt-latest',
    'openai/gpt-mini-latest',
    'deepseek-v4-flash-latest',
    'deepseek-r1',
    'grok-4.5'
  ];

  const currentModelObj = useMemo(() => {
    return ALL_MODELS.find(m => m.id === preferredModel) || ALL_MODELS[0];
  }, [preferredModel]);

  const filteredModels = useMemo(() => {
    let baseModels = ALL_MODELS;

    if (activeModelTab === 'Popular') {
      baseModels = ALL_MODELS.filter(m => POPULAR_IDS.includes(m.id));
    } else if (activeModelTab === 'Latest') {
      baseModels = ALL_MODELS.filter(m => LATEST_IDS.includes(m.id));
    } else if (activeModelTab === 'All') {
      baseModels = [...ALL_MODELS].sort((a, b) => a.name.localeCompare(b.name));
    }

    return baseModels.filter((m) => {
      // 1. Provider filter
      if (selectedProviderFilter !== 'All' && m.provider !== selectedProviderFilter) {
        return false;
      }
      // 2. Search query filter
      if (modelSearchQuery.trim()) {
        const q = modelSearchQuery.toLowerCase();
        const matchesName = m.name.toLowerCase().includes(q);
        const matchesTagline = m.tagline.toLowerCase().includes(q);
        const matchesProvider = m.provider.toLowerCase().includes(q);
        const matchesId = m.id.toLowerCase().includes(q);
        return matchesName || matchesTagline || matchesProvider || matchesId;
      }
      return true;
    });
  }, [selectedProviderFilter, modelSearchQuery, activeModelTab]);
  const shouldShowConsensus = useMemo(() => {
    if (loading) return false;
    if (messages.length === 0) return false;
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role !== 'assistant') return false;
    if (!lastMsg.comparisonResults) return false;
    if (input.trim().length > 0) return false;
    return true;
  }, [loading, messages, input]);

  const handleConsensusRequest = () => {
    const lastMsg = messages[messages.length - 1];
    let combinedContent = "Please combine the following AI responses into one consensus and summarize the best points:\n\n";
    if (lastMsg && lastMsg.comparisonResults) {
      lastMsg.comparisonResults.forEach(cr => {
        combinedContent += `[Model: ${cr.modelName}]\n${cr.content}\n\n`;
      });
    }
    handleSendRef.current(combinedContent, "Please combine the previous answers into one consensus.");
  };

  const [showImageModelMenu, setShowImageModelMenu] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [ttsLoading, setTtsLoading] = useState<string | null>(null);
  const [moreMenuId, setMoreMenuId] = useState<string | null>(null);
  const [exportingPdfId, setExportingPdfId] = useState<string | null>(null);
  const [latexExportContent, setLatexExportContent] = useState<string | null>(null);
  const [latexExportTitle, setLatexExportTitle] = useState<string>('');
  const [showLatexExportModal, setShowLatexExportModal] = useState<boolean>(false);
  const [attachedFiles, setAttachedFiles] = useState<AttachedDoc[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [showVoiceOverlay, setShowVoiceOverlay] = useState(false);
  const [voiceInterimText, setVoiceInterimText] = useState("");
  const autoSpeakNextResponse = useRef(false);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [showToolsMenu, setShowToolsMenu] = useState(false);
  const [showConnectorsSubMenu, setShowConnectorsSubMenu] = useState(false);
  const [selectedConnector, setSelectedConnector] = useState<ConnectorItem | null>(null);
  const [showMentionMenu, setShowMentionMenu] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [mentionSelectedIndex, setMentionSelectedIndex] = useState(0);
  const [youtubeModeActive, setYoutubeModeActive] = useState(false);
  const [youtubeMusicModeActive, setYoutubeMusicModeActive] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [compareSelectedModels, setCompareSelectedModels] = useState<string[]>(['chatgpt', 'claude', 'gemini']);
  const [showCompareSelector, setShowCompareSelector] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [showCameraMenu, setShowCameraMenu] = useState(false);
  const [flashOn, setFlashOn] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [activeSourcesModalMsg, setActiveSourcesModalMsg] = useState<ChatMessage | null>(null);
  const [sourcesTab, setSourcesTab] = useState<'references' | 'related'>('references');
  const [activeImageLightbox, setActiveImageLightbox] = useState<SearchImage | null>(null);
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);
  const [promptEnhancedSuccess, setPromptEnhancedSuccess] = useState(false);

  const [activeDueTask, setActiveDueTask] = useState<ScheduledTask | null>(null);
  const [scheduledTasksList, setScheduledTasksList] = useState<ScheduledTask[]>(() => loadScheduledTasks());
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(() => getNotificationPermission());
  const abortControllerRef = useRef<AbortController | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ttsAbortControllerRef = useRef<AbortController | null>(null);

  // Periodic real-time background task & reminder monitor (every 1 second)
  useEffect(() => {
    const timerInterval = setInterval(() => {
      const allTasks = loadScheduledTasks();
      setScheduledTasksList(allTasks);
      const now = Date.now();

      for (const t of allTasks) {
        if (t.status === 'pending' && t.scheduledTime <= now) {
          // Trigger alarm & notification
          updateTaskStatus(t.id, 'triggered', { triggeredAt: now });
          if (t.soundEnabled) {
            playNotificationChime('reminder');
          }
          if (t.systemNotification) {
            sendSystemNotification(`🔔 Task Due: ${t.title}`, {
              body: `Your scheduled task (${t.timeLabel}) is due now!`,
              onClick: () => {
                setShowNotificationModal(true);
              }
            });
          }
          setActiveDueTask(t);
          break;
        }
      }
    }, 1000);

    return () => clearInterval(timerInterval);
  }, []);

  // Magic AI Prompt Optimizer Handler
  const handleEnhancePrompt = async () => {
    const textToEnhance = input.trim();
    if (!textToEnhance || isEnhancingPrompt || loading) return;

    setIsEnhancingPrompt(true);
    try {
      const res = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: textToEnhance }),
      });

      const data = await res.json();
      if (res.ok && data.enhancedPrompt) {
        setInput(data.enhancedPrompt);
        localStorageHelper.saveDraftInput(data.enhancedPrompt);

        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.style.height = 'auto';
            inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
            inputRef.current.focus();
          }
        }, 50);

        setPromptEnhancedSuccess(true);
        showToast('✨ Prompt optimized for best AI output!');
        setTimeout(() => setPromptEnhancedSuccess(false), 2200);
      } else {
        showToast(data.error || 'Could not optimize prompt');
      }
    } catch (err: any) {
      console.error('Enhance prompt error:', err);
      showToast('Failed to optimize prompt. Please try again.');
    } finally {
      setIsEnhancingPrompt(false);
    }
  };

  const filteredConnectors = useMemo(() => {
    if (!mentionQuery) return CONNECTORS_LIST;
    const q = mentionQuery.toLowerCase().trim();
    return CONNECTORS_LIST.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.tag.toLowerCase().includes(q) || 
      c.description.toLowerCase().includes(q)
    );
  }, [mentionQuery]);

  const selectConnector = useCallback((connector: ConnectorItem) => {
    setSelectedConnector(connector);
    setShowMentionMenu(false);
    setShowConnectorsSubMenu(false);
    setShowPlusMenu(false);

    if (inputRef.current) {
      const val = inputRef.current.value || input;
      const cursorPos = inputRef.current.selectionStart || val.length;
      const textBeforeCursor = val.slice(0, cursorPos);
      const textAfterCursor = val.slice(cursorPos);
      const cleanedBefore = textBeforeCursor.replace(/@[a-zA-Z0-9_-]*$/, '');
      const nextVal = (cleanedBefore + textAfterCursor).trimStart();
      setInput(nextVal);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 40);
    }

    if (connector.id === 'youtube') {
      setYoutubeModeActive(true);
      setYoutubeMusicModeActive(false);
    } else if (connector.id === 'youtube_music') {
      setYoutubeMusicModeActive(true);
      setYoutubeModeActive(false);
    } else {
      setYoutubeModeActive(false);
      setYoutubeMusicModeActive(false);
    }

    if (connector.id === 'web_search' || connector.id === 'deep_research') {
      setSearchMode(true);
    }
  }, [input]);

  const removeSelectedConnector = useCallback(() => {
    setSelectedConnector(null);
    setYoutubeModeActive(false);
    setYoutubeMusicModeActive(false);
  }, []);

  // Synchronize active messages & session to localStorage
  useEffect(() => {
    if (!currentSessionId) return;

    setSessions(prevSessions => {
      const existingIndex = prevSessions.findIndex(s => s.id === currentSessionId);
      let updated: ChatSession[];

      if (messages.length === 0 && existingIndex === -1) {
        return prevSessions;
      }

      if (existingIndex >= 0) {
        updated = prevSessions.map(s => {
          if (s.id === currentSessionId) {
            let title = s.title;
            if ((!title || title === 'New chat' || title === 'Untitled chat') && messages.length > 0) {
              const firstUserMsg = messages.find(m => m.role === 'user');
              if (firstUserMsg) title = firstUserMsg.content.slice(0, 36) + (firstUserMsg.content.length > 36 ? '...' : '');
            }
            return {
              ...s,
              title,
              messages,
              updatedAt: Date.now(),
              preferredModel,
            };
          }
          return s;
        });
      } else {
        const firstUserMsg = messages.find(m => m.role === 'user');
        const title = firstUserMsg ? firstUserMsg.content.slice(0, 36) + (firstUserMsg.content.length > 36 ? '...' : '') : 'New chat';
        const newS: ChatSession = {
          id: currentSessionId,
          title,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          messages,
          preferredModel,
        };
        updated = [newS, ...prevSessions];
      }

      if (!isTemporary) {
        localStorageHelper.saveSessions(updated);
        if (authUser) {
          const activeS = updated.find(s => s.id === currentSessionId);
          if (activeS) {
            saveSessionToFirestore(authUser.uid, activeS);
          }
        }
        return updated;
      }
      return prevSessions; // Don't update sessions list for temporary chats
    });
  }, [messages, currentSessionId, preferredModel, isTemporary, authUser]);

  
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as Element).closest('.session-menu-container')) {
        setActiveMenuId(null);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Persist active session ID
  useEffect(() => {
    if (currentSessionId) {
      localStorageHelper.saveCurrentSessionId(currentSessionId);
    }
  }, [currentSessionId]);

  // Persist preferred model
  useEffect(() => {
    localStorageHelper.savePreferredModel(preferredModel);
  }, [preferredModel]);

  // Persist draft input
  useEffect(() => {
    localStorageHelper.saveDraftInput(input);
  }, [input]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Handle Switching Chat Sessions
  const handleSelectSession = (sessionId: string) => {
    if (loading) return;
    setIsTemporary(false);
    const session = sessions.find(s => s.id === sessionId);
    if (session) {
      setCurrentSessionId(session.id);
      setMessages(session.messages);
      if (session.preferredModel) {
        setPreferredModel(session.preferredModel as ModelType);
      }
      setIsSidebarOpen(false);
    }
  };

  // Handle Starting a New Chat
  const handleNewChat = () => {
    if (loading) return;
    setIsTemporary(false);
    const newSession = localStorageHelper.createNewSession();
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setMessages([]);
    setInput('');
    setIsSidebarOpen(false);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.focus();
    }
  };

  // Handle Deleting a Chat Session
  const handleDeleteSession = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = sessions.filter(s => s.id !== sessionId);
    setSessions(remaining);
    localStorageHelper.saveSessions(remaining);
    if (authUser) {
      deleteSessionFromFirestore(authUser.uid, sessionId);
    }

    if (currentSessionId === sessionId) {
      if (remaining.length > 0) {
        setCurrentSessionId(remaining[0].id);
        setMessages(remaining[0].messages);
      } else {
        const fresh = localStorageHelper.createNewSession();
        setSessions([fresh]);
        setCurrentSessionId(fresh.id);
        setMessages([]);
      }
    }
  };

  // Voice Typing Speech Recognition System
  const { speak, stop: stopSpeaking, isSpeaking } = useTextToSpeech();
  
  const {
    isListening: isLiveListening,
    startListening: startLiveListening,
    stopListening: stopLiveListening
  } = useLiveSpeechRecognition({
    onTranscriptChange: (text, isFinal) => {
      setVoiceInterimText(text);
      if (isFinal && text.trim()) {
        autoSpeakNextResponse.current = true;
        handleSend(text);
        setVoiceInterimText('');
      }
    }
  });


  const {
    isListening: isDictating,
    isTranscribing: isDictatingTranscribing,
    startListening: startDictating,
    stopListening: stopDictating
  } = useSpeechRecognition({
    onTranscriptUpdate: (fullText) => {
      setInput(fullText);
    }
  });

  const toggleDictation = () => {
    if (isDictating) {
      stopDictating();
    } else {
      startDictating(input);
    }
  };

  const toggleMicListening = () => {
    if (isLiveListening) {
      stopLiveListening();
      setShowVoiceOverlay(false);
    } else {
      setShowVoiceOverlay(true);
      startLiveListening();
    }
  };

  // Smart mic control for Copilot-style Voice Mode
  useEffect(() => {
    if (showVoiceOverlay) {
      // Pause mic while AI is generating or speaking to prevent feedback loops
      if (loading || isSpeaking) {
        if (isLiveListening) {
          stopLiveListening();
        }
      } else {
        // Auto-restart mic when AI is quiet
        if (!isLiveListening) {
          startLiveListening();
        }
      }
    }
  }, [showVoiceOverlay, isLiveListening, isSpeaking, loading, startLiveListening, stopLiveListening]);

  useEffect(() => {
    if (!loading && messages.length > 0 && autoSpeakNextResponse.current) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'assistant') {
        speak(lastMsg.content);
        autoSpeakNextResponse.current = false;
      }
    }
  }, [loading, messages, speak]);

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setLoading(false);
  };

  const handleCopy = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (content: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Pentagon Response',
          text: content,
        });
      } catch (err) {
        console.error('Share error:', err);
      }
    } else {
      navigator.clipboard.writeText(content);
      setCopiedId('share');
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  
  




  
  const audioCacheRef = useRef<{ [id: string]: HTMLAudioElement }>({});
  const lastBrowserTtsIdRef = useRef<string | null>(null);

  const handleTextToSpeech = async (id: string, text: string) => {
    // 1. Pause any and all currently playing audios unconditionally
    if (audioRef.current) {
       audioRef.current.pause();
    }
    Object.values(audioCacheRef.current).forEach(audio => {
       audio.pause();
    });
    
    // 2. Abort any ongoing fetch
    if (ttsAbortControllerRef.current) {
      ttsAbortControllerRef.current.abort();
    }
    
    // 3. Stop browser TTS just in case
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    
    // 4. Check if they clicked the one that is currently speaking/loading
    if (speakingId === id || ttsLoading === id) {
      setSpeakingId(null);
      setTtsLoading(null);
      return; // Toggle off behavior
    }
    
    // 5. Reset states for the new audio
    setSpeakingId(null);
    setTtsLoading(id);
    
    // 6. Play cached if exists
    if (audioCacheRef.current[id]) {
      const audio = audioCacheRef.current[id];
      audioRef.current = audio;
      audio.currentTime = 0;
      try {
        await audio.play();
        setSpeakingId(id);
        setTtsLoading(null);
      } catch (err) {
        setSpeakingId(null);
        setTtsLoading(null);
      }
      return;
    }
    
    // 7. Fetch new audio
    try {
      ttsAbortControllerRef.current = new AbortController();
      const cleanText = text.replace(/<[^>]+>/g, '').trim();
      
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanText, voice: 'Kore' }),
        signal: ttsAbortControllerRef.current.signal
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error ${res.status}`);
      }
      
      const data = await res.json();
      if (!data.success || !data.audioBase64) {
         throw new Error(data.error || 'No audio returned');
      }
      
      const audioSrc = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      const audio = new Audio(audioSrc);
      
      audioRef.current = audio;
      audioCacheRef.current[id] = audio;
      
      audio.onended = () => {
        setSpeakingId((prevId) => prevId === id ? null : prevId);
      };
      audio.onerror = (e) => {
        console.log('Audio playback error details:', audio.error?.code, audio.error?.message);
        setSpeakingId((prevId) => prevId === id ? null : prevId);
        delete audioCacheRef.current[id];
      };
      
      audio.load();
      await audio.play();
      
      setTtsLoading(null);
setSpeakingId(id);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('TTS fetch aborted');
        return;
      }
      console.log('TTS backend failed, falling back to browser synthesis:', err.message);
      
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text.replace(/<[^>]+>/g, '').trim());
        utterance.rate = 1.0;
        utterance.onend = () => setSpeakingId((prevId) => prevId === id ? null : prevId);
        utterance.onerror = () => setSpeakingId((prevId) => prevId === id ? null : prevId);
        window.speechSynthesis.speak(utterance);
        setTtsLoading(null);
        setSpeakingId(id);
      } else {
        showToast(err.message || 'TTS Playback failed');
        setTtsLoading(null);
        setSpeakingId(null);
      }
    }
  };

  const handleFeedback = (id: string, type: 'up' | 'down') => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, feedback: m.feedback === type ? undefined : type } : m));
  };

  const prepareFileForOcr = async (file: File): Promise<{ base64Data: string; fileType: string }> => {
    // If it's an image, downscale huge images (e.g. 5-15MB phone camera shots) to max 1800px & JPEG 0.85
    if (file.type.startsWith('image/') && !file.type.includes('svg') && !file.type.includes('gif')) {
      try {
        const compressedBase64 = await new Promise<string>((resolve, reject) => {
          const img = new Image();
          const objectUrl = URL.createObjectURL(file);
          img.onload = () => {
            URL.revokeObjectURL(objectUrl);
            let { width, height } = img;
            const maxDim = 1800;
            if (width > maxDim || height > maxDim) {
              if (width > height) {
                height = Math.round((height * maxDim) / width);
                width = maxDim;
              } else {
                width = Math.round((width * maxDim) / height);
                height = maxDim;
              }
            }
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.fillStyle = '#FFFFFF';
              ctx.fillRect(0, 0, width, height);
              ctx.drawImage(img, 0, 0, width, height);
              resolve(canvas.toDataURL('image/jpeg', 0.85));
            } else {
              reject(new Error('Canvas context unavailable'));
            }
          };
          img.onerror = () => {
            URL.revokeObjectURL(objectUrl);
            reject(new Error('Failed to load image for compression'));
          };
          img.src = objectUrl;
        });

        return { base64Data: compressedBase64, fileType: 'image/jpeg' };
      } catch (e) {
        console.warn('[Image compression fallback]:', e);
      }
    }

    // Standard reader for PDFs and other files
    const standardBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });

    return { base64Data: standardBase64, fileType: file.type || 'application/octet-stream' };
  };

  const handleFileUpload = async (files: FileList | File[]) => {
    const fileArray = Array.from(files);
    if (fileArray.length === 0) return;

    for (const file of fileArray) {
      const docId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const isImg = file.type.startsWith('image/');
      let previewUrl = '';
      if (isImg) {
        previewUrl = URL.createObjectURL(file);
      }

      // Add initial doc in processing state
      const newDoc: AttachedDoc = {
        id: docId,
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        previewUrl,
        status: 'processing',
      };

      setAttachedFiles(prev => [...prev, newDoc]);

      // Read file data
      try {
        // For plain text files, extract directly
        if (file.type.includes('text') || file.name.endsWith('.txt') || file.name.endsWith('.md') || file.name.endsWith('.csv') || file.name.endsWith('.json')) {
          try {
            const textReader = new FileReader();
            textReader.onload = () => {
              const textContent = textReader.result as string;
              setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, extractedText: textContent, status: 'ready' } : d));
            };
            textReader.readAsText(file);
            continue;
          } catch (e) {
            // fallback to OCR
          }
        }

        const { base64Data, fileType } = await prepareFileForOcr(file);

        // Call OCR Endpoint (/api/ocr)
        try {
          const ocrRes = await fetch('/api/ocr', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileBase64: base64Data,
              fileName: file.name,
              fileType: fileType || file.type,
            }),
          });

          if (ocrRes.ok) {
            const ocrData = await ocrRes.json();
            if (ocrData.success && ocrData.text) {
              setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, extractedText: ocrData.text, status: 'ready' } : d));
            } else {
              setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, status: 'ready', extractedText: `[Image/Document attached: ${file.name}]` } : d));
            }
          } else {
            setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, status: 'ready', extractedText: `[Document attached: ${file.name}]` } : d));
          }
        } catch (ocrErr: any) {
          console.warn('[OCR client error]:', ocrErr);
          setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, status: 'ready', extractedText: `[Document: ${file.name}]` } : d));
        }
      } catch (readErr: any) {
        setAttachedFiles(prev => prev.map(d => d.id === docId ? { ...d, status: 'error', errorMessage: 'Could not read file' } : d));
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileUpload(e.target.files);
      e.target.value = '';
    }
  };

  const initCameraStream = async (mode: 'environment' | 'user') => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: { ideal: mode },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn("Primary camera stream failed, attempting fallback:", err);
      try {
        const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: true });
        streamRef.current = fallbackStream;
        if (videoRef.current) {
          videoRef.current.srcObject = fallbackStream;
        }
      } catch (fbErr) {
        console.error("Camera access failed:", fbErr);
        alert("Unable to access camera.");
        setShowCamera(false);
      }
    }
  };

  const startCamera = async () => {
    setShowAttachmentMenu(false);
    setShowCamera(true);
    setShowCameraMenu(false);
    setFlashOn(false);
    setFacingMode('environment');
    setTimeout(() => {
      initCameraStream('environment');
    }, 60);
  };

  const toggleFacingMode = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    initCameraStream(nextMode);
  };

  const toggleFlash = async () => {
    const nextFlash = !flashOn;
    setFlashOn(nextFlash);
    if (streamRef.current) {
      const track = streamRef.current.getVideoTracks()[0];
      if (track) {
        try {
          const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as any;
          if (capabilities && capabilities.torch) {
            await track.applyConstraints({
              advanced: [{ torch: nextFlash } as any]
            });
          }
        } catch (e) {
          console.warn('Torch constraint not supported on device:', e);
        }
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
    setShowCameraMenu(false);
    setFlashOn(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], `photo_${Date.now()}.jpg`, { type: 'image/jpeg' });
            handleFileUpload([file]);
            stopCamera();
          }
        }, 'image/jpeg', 0.8);
      }
    }
  };

  const removeAttachment = (id: string) => {
    setAttachedFiles(prev => prev.filter(d => d.id !== id));
  };


  const generateChatTitle = async (messageText: string, sessionId: string) => {
    try {
      const response = await fetch('/api/generate-title', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: messageText }),
      });
      const data = await response.json();
      if (data && data.title) {
        setSessions(prev => {
          const updated = prev.map(s => {
            if (s.id === sessionId) {
              return { ...s, title: data.title };
            }
            return s;
          });
          localStorageHelper.saveSessions(updated);
          return updated;
        });
      }
    } catch (e) {
      console.error('Failed to generate title', e);
    }
  };

  const handleSend = async (overridePrompt?: string, displayContentOverride?: string) => {
    setShowModelMenu(false);
    const rawPrompt = (overridePrompt !== undefined ? overridePrompt : input).trim();
    if ((!rawPrompt && attachedFiles.length === 0) || loading) return;

    // Build the user message with OCR text context if attachments exist
    let promptToSend = rawPrompt;

    if (selectedConnector) {
      if (selectedConnector.systemPrompt) {
        promptToSend = `${selectedConnector.systemPrompt}\n\nUser Request: ${promptToSend}`;
      }
    }

    if (youtubeModeActive) {
      const ytRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
      const ytMatch = rawPrompt.match(ytRegex);
      if (ytMatch) {
        setLoading(true);
        setLoadingStatus("Transcribing Video...");
        try {
          const ytRes = await fetch('/api/youtube-transcript', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ videoUrl: ytMatch[0] })
          });
          const ytData = await ytRes.json();
          if (ytRes.ok && ytData.transcript) {
            promptToSend = `${rawPrompt}\n\n[YOUTUBE VIDEO TRANSCRIPT]\n${ytData.transcript}\n[END YOUTUBE VIDEO TRANSCRIPT]`;
          } else {
            setLoading(false);
            setMessages(prev => [...prev, {
              id: Date.now().toString(),
              role: 'assistant',
              content: `🚨 **YouTube Integration Error:**

${ytData.error || 'Failed to fetch transcript. Please ensure the video has closed captions.'}`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }]);
            return; // Abort sending the message
          }
        } catch(e) {
          setLoading(false);
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'assistant',
            content: `🚨 **YouTube Integration Error:**

Failed to connect to the server. Please try again.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }]);
          return;
        }
        setLoading(false);
      }
    }
    if (attachedFiles.length > 0) {
      const attachmentsContext = attachedFiles
        .map(f => {
          if (f.extractedText && f.extractedText.trim()) {
            return `📄 **Attached Document:** \`${f.name}\`\n---\n**Extracted Document Content (OCR.Space Engine):**\n${f.extractedText.trim()}\n---`;
          }
          return `📄 **Attached Document:** \`${f.name}\``;
        })
        .join('\n\n');

      if (promptToSend) {
        promptToSend = `${promptToSend}\n\n${attachmentsContext}`;
      } else {
        promptToSend = `Please analyze and summarize the following attached document:\n\n${attachmentsContext}`;
      }
    }

        let finalPromptToSend = promptToSend;
    const lowerPrompt = promptToSend.toLowerCase();
    if (lowerPrompt.includes('email') || lowerPrompt.includes('gmail') || lowerPrompt.includes('inbox') || lowerPrompt.includes('reply') || lowerPrompt.includes('mail')) {
      try {
        const token = await getAccessToken();
        if (token) {
          const emails = await getRecentEmails(token, 5);
          if (emails && emails.length > 0) {
            const emailContext = `\n\n[GMAIL CONTEXT - RECENT EMAILS]\n${emails.map(e => `ID: ${e.id}\nFrom: ${e.from}\nDate: ${e.date}\nSubject: ${e.subject}\nSnippet: ${e.snippet}`).join('\n\n')}\n[END GMAIL CONTEXT]`;
            finalPromptToSend += emailContext;
          }
          finalPromptToSend += `\n\n[SYSTEM INSTRUCTION: If the user asks you to send an email or reply to an email, you MUST output a raw JSON block starting with \`\`\`json\n{"action": "send_email", "to": "email_address", "subject": "email_subject", "body": "email_body_in_plain_text"}\n\`\`\` and nothing else. Ensure the action field is EXACTLY "send_email" if it's an email draft. You can include some conversational text before or after the JSON block.]`;
        }
      } catch(e) {
        console.error("Failed to inject gmail context", e);
      }
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: finalPromptToSend,
      displayContent: displayContentOverride !== undefined ? displayContentOverride : (rawPrompt || ''), // Empty if only uploading
      attachments: attachedFiles.length > 0 ? [...attachedFiles] : undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      connector: selectedConnector ? selectedConnector.name : undefined
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    
    // Auto-generate AI title on the second message to avoid greetings being the title
    if (messages.length === 2) {
      generateChatTitle(promptToSend, currentSessionId);
    } else if (messages.length === 0 && promptToSend.length > 50) {
      // If the first message is long enough (not just a greeting like "hi"), generate title immediately
      generateChatTitle(promptToSend, currentSessionId);
    }

    setInput('');
    setAttachedFiles([]);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }

    // Direct YouTube Music Search & Embed Playback (Zero Quota / No API Key)
    const isMusicIntent = youtubeMusicModeActive || selectedConnector?.id === 'youtube_music' || 
      /^(?:@music|@ytmusic|@songs|play\s+|listen\s+to\s+|gaana\s+sunao\s+|gana\s+sunao\s+|search\s+song\s+)/i.test(rawPrompt) ||
      /\b(play\s+song|listen\s+to|stream\s+song|youtube\s+music)\b/i.test(rawPrompt);

    if (isMusicIntent) {
      setLoading(true);
      setLoadingStatus("Searching music tracks...");
      try {
        const musicRes = await fetch('/api/youtube-music-search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: rawPrompt })
        });
        const musicData = await musicRes.json();
        if (musicRes.ok && musicData.tracks && musicData.tracks.length > 0) {
          setLoading(false);
          const topTrack = musicData.tracks[0];
          const musicAssistantMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: `🎵 **Now Playing:** **${topTrack.title}** by **${topTrack.artist}**\n\n*Streamed via YouTube Music.* Use the player controls below:`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            musicTracks: musicData.tracks,
            connector: 'YouTube Music'
          };
          setMessages(prev => [...prev, musicAssistantMsg]);
          return;
        }
      } catch (mErr) {
        console.log("Music search error, falling back to chat AI:", mErr);
      }
    }

    // Natural Language Real-Time Task & Notification Scheduler
    const reminderParsed = parseReminderFromPrompt(rawPrompt);
    if (reminderParsed) {
      const scheduledTask = createScheduledTask({
        title: reminderParsed.title,
        scheduledTime: reminderParsed.scheduledTime,
        timeLabel: reminderParsed.timeLabel,
        category: reminderParsed.category,
        soundEnabled: true,
        systemNotification: true,
        sessionId: currentSessionId
      });

      // Update state
      setScheduledTasksList(loadScheduledTasks());
      playNotificationChime('success');

      // Check / request notification permission if not yet granted
      if (getNotificationPermission() === 'default') {
        requestNotificationPermission().then(perm => {
          setNotificationPermission(perm);
          if (perm === 'granted') {
            sendSystemNotification('Notification Permission Enabled! 🔔', {
              body: `You will be alerted at ${scheduledTask.timeLabel} for "${scheduledTask.title}".`
            });
          }
        });
      }

      setLoading(false);
      const reminderAssistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `⏰ **Real-Time Task & Reminder Scheduled!**\n\n- 📋 **Task:** ${scheduledTask.title}\n- 🕒 **Scheduled Alert Time:** **${scheduledTask.timeLabel}**\n- 🔔 **Alert Engine:** System Desktop Popup + Harmonic Sound Chime\n- 🏷️ **Category:** \`${scheduledTask.category.toUpperCase()}\`\n\n> *Your notification is armed in real-time. When the clock hits **${scheduledTask.timeLabel}**, you will receive an audible chime and desktop popup alert.* You can click the **Tasks & Alerts** bell at the top anytime to view, edit, or snooze!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, reminderAssistantMsg]);
      return;
    }

    setLoadingStatus(attachedFiles.length > 0 ? "Analyzing files..." : "Thinking...");
    // Dynamically ask AI what it's doing
    if (attachedFiles.length === 0 && rawPrompt) {
      fetch('/api/intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: rawPrompt })
      })
      .then(res => res.json())
      .then(data => {
        if (data.status) setLoadingStatus(data.status + '...');
      })
      .catch(e => console.log('Intent check failed', e));
    }
    setLoading(true);

    abortControllerRef.current = new AbortController();

    const clientTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Karachi';
    const clientTime = new Date().toLocaleString('en-US', {
      dateStyle: 'full',
      timeStyle: 'medium',
    });

    if (compareMode) {
      setCompareMode(false);
      
      const compareModelsToUse = compareSelectedModels.length > 0 ? compareSelectedModels : ['chatgpt', 'claude', 'gemini'];
      const comparisonResults = compareModelsToUse.map(m => ({
         modelId: m,
         modelName: ALL_MODELS.find(x => x.id === m)?.name || m,
         loading: true,
      }));

      const loadingId = (Date.now() + 1).toString();
      const loadingMsg: ChatMessage = {
        id: loadingId,
        role: 'assistant',
        content: '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        comparisonResults
      };

      setMessages(prev => [...prev, loadingMsg]);

      let completedCount = 0;
      const checkDone = () => {
         completedCount++;
         if (completedCount === compareModelsToUse.length) {
            setLoading(false);
         }
      };

      compareModelsToUse.forEach((model, idx) => {
         fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
               messages: newHistory.map(m => ({ role: m.role, content: m.content || (m.comparisonResults ? m.comparisonResults.map(cr => `[${cr.modelName}]: ${cr.content}`).join('\n\n') : ' ') })),
               preferredModel: model,
               searchMode: false,
               clientTime,
               clientTimeZone
            }),
            signal: abortControllerRef.current?.signal
         })
         .then(async res => {
            const text = await res.text();
            let data: any = {};
            try {
              data = JSON.parse(text);
            } catch {
              throw new Error('Server connection error');
            }
            if (!res.ok || !data.success) throw new Error(data?.error || 'Failed');
            return data;
         })
         .then(data => {
            setMessages(prev => prev.map(m => {
               if (m.id === loadingId && m.comparisonResults) {
                  const newCompResults = [...m.comparisonResults];
                  newCompResults[idx] = { ...newCompResults[idx], loading: false, content: data.reply, provider: data.provider };
                  return { ...m, comparisonResults: newCompResults };
               }
               return m;
            }));
         })
         .catch(err => {
            setMessages(prev => prev.map(m => {
               if (m.id === loadingId && m.comparisonResults) {
                  const newCompResults = [...m.comparisonResults];
                  newCompResults[idx] = { ...newCompResults[idx], loading: false, content: '❌ Failed to generate response.' };
                  return { ...m, comparisonResults: newCompResults };
               }
               return m;
            }));
         })
         .finally(() => {
            checkDone();
         });
      });

      return;
    }

    try {

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map(m => ({ role: m.role, content: m.content || (m.comparisonResults ? m.comparisonResults.map(cr => `[${cr.modelName}]: ${cr.content}`).join('\n\n') : ' ') })),
          preferredModel,
          searchMode,
          clientTime,
          clientTimeZone,
        }),
        signal: abortControllerRef.current.signal,
      });

      let data: any = null;
      try {
        const text = await response.text();
        try {
          data = JSON.parse(text);
        } catch {
          if (text.includes('<!DOCTYPE') || text.includes('<!doctype') || text.includes('<html')) {
            throw new Error('Backend server is starting up or unreachable. If hosted externally, please ensure the server was started with "npm start".');
          }
          throw new Error('Unexpected non-JSON response from server.');
        }
      } catch (parseErr: any) {
        throw new Error(parseErr.message || 'Failed to parse response from server.');
      }

      if (!response.ok) {
        const errorMsg = data?.error || `Server returned error (${response.status}). Please try again.`;
        throw new Error(errorMsg);
      }

      if (data && data.success) {
        setMessages((prev) => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            isNew: true,
            content: data.reply || 'Task completed.',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actionTaken: data.provider ? `via ${data.provider}` : null,
            model: data.provider || preferredModel,
            citations: data.citations || undefined,
            sources: data.sources || undefined,
            images: data.images || undefined,
            suggestions: data.suggestions || undefined,
          }
        ]);
      } else {
        throw new Error(data?.error || 'Failed to execute request.');
      }
    } catch (error: any) {
      if (error.name === 'AbortError') return;
      let displayError = error.message || 'Something went wrong. Please try sending your message again.';
      if (displayError.includes('<!doctype') || displayError.includes('Unexpected token')) {
        displayError = 'Server is currently unreachable. Make sure the Node.js backend is running with "npm start".';
      } else if (displayError.includes('503') || displayError.toLowerCase().includes('high load') || displayError.toLowerCase().includes('unavailable')) {
        displayError = 'The upstream AI engine is temporarily busy due to high traffic. Your next request will automatically switch to a faster standby engine.';
      }
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `⚠️ ${displayError}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actionTaken: 'Notice',
        }
      ]);
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (showMentionMenu) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setMentionSelectedIndex(prev => (prev + 1) % (filteredConnectors.length || 1));
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setMentionSelectedIndex(prev => (prev - 1 + filteredConnectors.length) % (filteredConnectors.length || 1));
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        if (filteredConnectors.length > 0) {
          const selected = filteredConnectors[mentionSelectedIndex] || filteredConnectors[0];
          selectConnector(selected);
        }
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowMentionMenu(false);
        return;
      }
    }

    if (e.key === 'Backspace' && input === '' && selectedConnector) {
      removeSelectedConnector();
      return;
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInput(val);

    const cursorPos = e.target.selectionStart || val.length;
    const textBeforeCursor = val.slice(0, cursorPos);
    const atMatch = textBeforeCursor.match(/@([a-zA-Z0-9_-]*)$/);

    if (atMatch) {
      setShowMentionMenu(true);
      setMentionQuery(atMatch[1].toLowerCase());
      setMentionSelectedIndex(0);
    } else {
      setShowMentionMenu(false);
      setMentionQuery("");
    }

    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
  };

  const handleSendRef = useRef(handleSend);
  useEffect(() => {
    handleSendRef.current = handleSend;
  });

  const memoizedComponents = useMemo(() => ({
    h1: ({ children }: any) => <h1 className="text-xl font-bold text-[#1A1A1A] dark:text-white mt-4 mb-2">{children}</h1>,
    h2: ({ children }: any) => <h2 className="text-lg font-bold text-[#1A1A1A] dark:text-white mt-3 mb-1.5">{children}</h2>,
    h3: ({ children }: any) => <h3 className="text-base font-semibold text-[#1A1A1A] dark:text-white mt-2.5 mb-1">{children}</h3>,
    p: ({ children }: any) => <p className="mb-3 leading-[1.65] break-words whitespace-pre-wrap">{children}</p>,
    ul: ({ children }: any) => <ul className="list-disc pl-5 mb-3 space-y-1">{children}</ul>,
    ol: ({ children }: any) => <ol className="list-decimal pl-5 mb-3 space-y-1">{children}</ol>,
    li: ({ children }: any) => <li className="leading-[1.65]">{children}</li>,
    hr: () => <hr className="my-4 border-[#EDECE8]" />,
    strong: ({ children }: any) => (
      <strong className="font-semibold text-[#1A1A1A] dark:text-white">
        {children}
      </strong>
    ),
    b: ({ children }: any) => (
      <strong className="font-semibold text-[#1A1A1A] dark:text-white">
        {children}
      </strong>
    ),
    table: ({ children }: any) => (
      <div className="overflow-x-auto w-full my-4 rounded-lg border border-[#DFDED9] dark:border-[#30363D]">
        <table className="w-full text-left text-sm text-[#1A1A1A] dark:text-white">{children}</table>
      </div>
    ),
    thead: ({ children }: any) => <thead className="bg-[#F5F5F4] border-b border-[#DFDED9] dark:border-[#30363D]">{children}</thead>,
    tbody: ({ children }: any) => <tbody className="divide-y divide-[#DFDED9]">{children}</tbody>,
    tr: ({ children }: any) => <tr className="hover:bg-[#FAFAFA] transition-colors">{children}</tr>,
    th: ({ children }: any) => <th className="px-4 py-2 font-semibold text-[#1A1A1A] dark:text-white">{children}</th>,
    td: ({ children }: any) => <td className="px-4 py-2">{children}</td>,
    img: ({ src, alt }: any) => {
      if (!src || typeof src !== 'string' || src.trim() === '') return null;
      return (
        <img
          src={src}
          alt={alt || ''}
          className="rounded-2xl max-w-full h-auto my-3 border border-[#DFDED9] dark:border-[#30363D] shadow-sm"
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      );
    },
    blockquote: ({ children }: any) => (
      <blockquote className="border-l-3 border-[#1A1A1A] pl-3 my-2 text-gray-700 italic">
        {children}
      </blockquote>
    ),
    a: ({ href, children }: any) => {
      let domain = '';
      try {
        domain = new URL(href || '').hostname.replace(/^www\./, '');
      } catch {
        domain = '';
      }
      const iconUrl = domain ? `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=32` : '';
      const isCitationLink = !String(children).startsWith('http') && String(children).length < 50;
      const cleanLabel = typeof children === 'string' 
        ? children.replace(/^[\(\[\{\s]+|[\)\]\}\s]+$/g, '').trim()
        : children;
      if (isCitationLink) {
        return (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 align-baseline mx-0.5 px-1.5 py-0.2 rounded-md text-[11.5px] font-medium bg-[#F0EFEB] hover:bg-[#E4E3DE] text-[#333] border border-[#DCDAD4] transition-all no-underline shadow-xs cursor-pointer group select-none hover:border-[#BEBCB4]"
            title={typeof cleanLabel === 'string' ? `${cleanLabel} - Click to open source` : (href || '')}
          >
            {iconUrl && typeof iconUrl === 'string' && iconUrl.trim() !== '' ? (
              <img
                src={iconUrl}
                alt=""
                className="w-3 h-3 rounded-full object-contain flex-shrink-0"
                loading="lazy"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 flex-shrink-0" />
            )}
            <span className="truncate max-w-[120px] text-gray-800 font-semibold group-hover:text-black">{cleanLabel}</span>
            <ExternalLink className="w-2.5 h-2.5 text-gray-400 group-hover:text-gray-700 flex-shrink-0" />
          </a>
        );
      }
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 font-medium underline underline-offset-2 transition-colors inline-flex items-center gap-1"
        >
          <span>{cleanLabel}</span>
          <ExternalLink className="w-3 h-3 flex-shrink-0 inline" />
        </a>
      );
    },
    code({ node, inline, className, children, ...props }: any) {
      const match = /language-(\w+)/.exec(className || '');
      const codeString = String(children).replace(/\n$/, '');
      if (!inline && match) {
        return (
          <div className="my-3">
            <CodeBlockWithRunner
              language={match[1]}
              code={codeString}
              isTyping={false}
              theme={theme}
            />
          </div>
        );
      }
      return (
        <code className="bg-[#EBEAE7] text-[#1A1A1A] dark:text-white font-mono text-[13px] px-1.5 py-0.5 rounded border border-[#DFDED9] dark:border-[#30363D] break-words overflow-wrap-anywhere inline-block max-w-full" {...props}>
          {children}
        </code>
      );
    },
  }), [theme]);

  return (
    <div className={`flex flex-col h-full relative font-sans w-full selection:bg-blue-100 overflow-hidden ${theme === 'Night' ? 'bg-[#11141A] text-gray-100' : 'bg-[#FAF9F6] text-[#1A1A1A] dark:text-white'}`}>
      
      {/* Background Soft Warm Glow Gradient */}
      <div className={`absolute inset-0 pointer-events-none z-0 ${theme === 'Night' ? 'bg-[#11141A]' : 'bg-gradient-to-b from-[#FAF9F6] via-[#FAF9F6] to-[#F5EFEB]/60'}`} />

      {/* Top Header (Pentagon Exact Style) */}
      <header className={`flex items-center justify-between px-4 py-3 backdrop-blur-xs border-b shrink-0 z-30 ${theme === 'Night' ? 'bg-[#11141A]/90 border-gray-800' : 'bg-[#FAF9F6]/80 border-[#EDECE8]/60'}`}>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setIsSidebarOpen(true)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${theme === 'Night' ? 'hover:bg-gray-800 text-gray-200' : 'hover:bg-[#EBEAE7] text-[#1A1A1A] dark:text-white'}`}
            title="Open navigation menu"
          >
            <PanelLeft className={`w-5 h-5 ${theme === 'Night' ? 'text-gray-200' : 'text-[#1A1A1A] dark:text-white'}`} />
          </button>
        </div>

        <div className="flex items-center gap-2">


          {/* Temporary Chat Toggle: Visible on home/empty chat OR when temporary mode is on */}
          {(messages.length === 0 || isTemporary) && (
            <button
              type="button"
              onClick={() => setIsTemporary(!isTemporary)}
              className={`px-3.5 py-1.5 rounded-full border ${isTemporary ? 'border-[#2A2925] bg-[#2A2925] text-white hover:bg-black' : 'border-[#DFDED9] dark:border-[#30363D] bg-white hover:bg-[#F8F7F5] text-[#1A1A1A] dark:text-white'} text-xs font-medium flex items-center gap-1.5 transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.03)] cursor-pointer`}
              title="Temporary chat (not saved to history)"
            >
              <MessageCircleDashed className={`w-3.5 h-3.5 ${isTemporary ? 'text-white' : 'text-gray-500'}`} />
              <span>Temporary</span>
            </button>
          )}
        </div>
      </header>

      {/* Sidebar Drawer (100% Matches Screenshot 2) */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/40 backdrop-blur-2xs transition-opacity animate-in fade-in"
            onClick={() => setIsSidebarOpen(false)}
          />

          {/* Drawer Content */}
          <div className="relative w-72 sm:w-80 bg-[#FAF9F6] h-full shadow-2xl flex flex-col z-50 border-r border-[#EAE8E3] animate-in slide-in-from-left duration-200">
            {/* Drawer Header */}
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-[#EDECE8]">
              <h2 className="text-base font-bold text-gray-900 tracking-tight flex items-center gap-2">
                <ModelLogo model="auto" className="w-5 h-5" />
                <span>Pentagon</span>
              </h2>
              <button
                type="button"
                onClick={() => setIsSidebarOpen(false)}
                className="p-1.5 rounded-lg hover:bg-gray-200/70 text-gray-600 cursor-pointer"
              >
                <PanelLeft className="w-5 h-5" />
              </button>
            </div>

            {/* Menu List 1 (New Chat, Library, Tasks, Projects) */}
            <div className="p-3 space-y-1">
              <button
                type="button"
                onClick={handleNewChat}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-800 font-medium rounded-xl hover:bg-[#EAE8E3] transition-colors cursor-pointer"
              >
                <PenSquare className="w-4 h-4 text-gray-600" />
                <span>New chat</span>
              </button>

              <button
                type="button"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-800 font-medium rounded-xl hover:bg-[#EAE8E3] transition-colors cursor-pointer"
              >
                <Folder className="w-4 h-4 text-gray-600" />
                <span>Library</span>
              </button>


              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsProjectsExpanded(!isProjectsExpanded)}
                  className="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-800 font-medium rounded-xl hover:bg-[#EAE8E3] transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-3">
                    <Folder className="w-4 h-4 text-gray-600" />
                    <span>Projects</span>
                  </span>
                  <div className="flex items-center gap-1">
                    <span 
                      onClick={(e) => { e.stopPropagation(); setShowCreateProject(true); }}
                      className="p-1 hover:bg-[#D5D3CE] rounded-lg transition-colors text-gray-500"
                    >
                      <Plus className="w-4 h-4" />
                    </span>
                  </div>
                </button>
                
                {isProjectsExpanded && (
                  <div className="mt-1 space-y-1 ml-2">
                    {projects.map(proj => (
                      <div 
                        key={proj.id}
                        onClick={() => setActiveProjectId(activeProjectId === proj.id ? null : proj.id)}
                        className={`flex items-center justify-between px-3 py-2 rounded-xl text-sm cursor-pointer transition-colors ${
                          activeProjectId === proj.id ? 'bg-[#EAE8E3] text-gray-900 font-medium' : 'text-gray-700 hover:bg-[#F0EEEA] dark:bg-[#21262D]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Folder className={`w-4 h-4 ${activeProjectId === proj.id ? 'fill-current text-gray-700' : 'text-gray-500'}`} />
                          <span className="truncate max-w-[140px]">{proj.name}</span>
                        </div>
                        <MoreVertical className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="border-t border-[#EDECE8] mx-3" />

            {/* Recent Chats List */}
            <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-gray-400 px-3 py-1">
                Recent Chats
              </div>
              {[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                return b.updatedAt - a.updatedAt;
              }).map(session => {
                const isActive = session.id === currentSessionId;
                return (
                  <div
                    key={session.id}
                    className="relative session-menu-container"
                  >
                    <div
                      onClick={() => handleSelectSession(session.id)}
                      className={`group flex items-center justify-between px-3 py-2 rounded-xl text-sm cursor-pointer transition-colors ${
                        isActive || activeMenuId === session.id ? 'bg-[#EAE8E3] text-gray-900 font-medium' : 'text-gray-700 hover:bg-[#F0EEEA] dark:bg-[#21262D]'
                      }`}
                    >
                      {renamingSessionId === session.id ? (
                        <input
                          type="text"
                          autoFocus
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onBlur={() => handleRenameSubmit(session.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleRenameSubmit(session.id);
                            if (e.key === 'Escape') setRenamingSessionId(null);
                          }}
                          className="flex-1 min-w-0 bg-transparent border-b border-gray-400 focus:outline-none focus:border-black text-xs sm:text-sm pr-2"
                        />
                      ) : (
                        <span className="truncate flex-1 pr-2 text-xs sm:text-sm flex items-center gap-1.5" dir="auto">
                          {session.isPinned && <Pin className="w-3 h-3 text-gray-400 fill-current" />}
                          {session.title || 'Untitled chat'}
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenuId(activeMenuId === session.id ? null : session.id);
                        }}
                        className={`p-1 rounded transition-opacity ${
                          isActive || activeMenuId === session.id ? 'opacity-100 text-gray-700' : 'opacity-0 group-hover:opacity-100 text-gray-500 hover:text-gray-800'
                        }`}
                        title="More options"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Popover Menu */}
                    {activeMenuId === session.id && (
                      <div className="absolute right-0 top-full mt-1 w-56 bg-[#FCFBF9] dark:bg-[#161B22] rounded-2xl shadow-lg border border-[#EAE8E1] dark:border-[#30363D] py-2 z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
                        {showMoveSubmenuId !== session.id ? (
                          <>
                            <button 
                              onClick={(e) => { e.stopPropagation(); togglePin(session.id); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <Pin className={`w-4 h-4 ${session.isPinned ? 'fill-current' : ''}`} />
                              {session.isPinned ? 'Unpin' : 'Pin'}
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); setRenameValue(session.title || ''); setRenamingSessionId(session.id); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <Type className="w-4 h-4" />
                              Rename
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); showToast("Invite link copied to clipboard"); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <UserPlus className="w-4 h-4" />
                              Invite
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); handleCopyConversation(session.id); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <Share2 className="w-4 h-4" />
                              Send a copy
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); handleSummarize(session.id); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <FileText className="w-4 h-4" />
                              Summarise in a page
                            </button>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowMoveSubmenuId(session.id);
                              }}
                              className="w-full flex items-center justify-between px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                <FolderInput className="w-4 h-4" />
                                Move to projects
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-400" />
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); showToast("Report submitted successfully"); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors border-t border-[#EAE8E1] dark:border-[#30363D] mt-1 pt-3"
                            >
                              <ShieldAlert className="w-4 h-4" />
                              Report a concern
                            </button>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveMenuId(null);
                                handleDeleteSession(session.id, e);
                              }}
                              className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors font-medium mb-1 mt-1"
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </button>
                          </>
                        ) : (
                          <div className="animate-in slide-in-from-right-8 duration-200">
                            <button 
                              onClick={(e) => { e.stopPropagation(); setShowMoveSubmenuId(null); }}
                              className="w-full flex items-center gap-2 px-3 py-2 sm:py-2.5 text-sm text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors border-b border-[#EAE8E1] dark:border-[#30363D] mb-1 pb-2"
                            >
                              <ChevronLeft className="w-4 h-4" />
                              Back
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); setShowCreateProject(true); setShowMoveSubmenuId(null); setActiveMenuId(null); }}
                              className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors mt-2 mb-1"
                            >
                              <FolderPlus className="w-4 h-4" />
                              New project
                            </button>
                            
                            <div className="max-h-[200px] overflow-y-auto">
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleMoveToProject(session.id, null); }}
                                className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-gray-500 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
                              >
                                Remove from project
                              </button>
                              {projects.map(proj => (
                                <button 
                                  key={proj.id}
                                  onClick={(e) => { e.stopPropagation(); handleMoveToProject(session.id, proj.id); }}
                                  className="w-full flex items-center gap-3 px-4 py-2 sm:py-2.5 text-sm text-[#45433D] dark:text-gray-200 hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors truncate"
                                >
                                  <Folder className="w-4 h-4" />
                                  {proj.name}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Bottom Profile Bar */}
            <div className="p-3 border-t border-[#EDECE8] dark:border-gray-800 bg-white/90 dark:bg-[#161B22]/90">
              {authUser ? (
                <div className="flex items-center justify-between gap-2">
                  <div 
                    className="flex items-center gap-2.5 cursor-pointer flex-1 min-w-0 hover:opacity-80 transition-opacity"
                    onClick={() => {
                      setIsSidebarOpen(false);
                      setShowSettings(true);
                    }}
                  >
                    {authUser.photoURL ? (
                      <img 
                        src={authUser.photoURL} 
                        alt="Avatar" 
                        className="w-8 h-8 rounded-full object-cover border border-gray-200 dark:border-gray-700 shrink-0" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 text-white flex items-center justify-center text-xs font-bold shadow-xs shrink-0">
                        {authUser.displayName ? authUser.displayName.charAt(0).toUpperCase() : (authUser.email ? authUser.email.charAt(0).toUpperCase() : 'U')}
                      </div>
                    )}
                    <div className="flex flex-col min-w-0">
                      <span className="text-xs font-semibold text-gray-900 dark:text-white truncate">
                        {authUser.displayName || 'User'}
                      </span>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400 truncate">
                        {authUser.email || ''}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setIsSidebarOpen(false);
                      setShowSettings(true);
                    }}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-xs font-medium text-gray-700 dark:text-gray-200 shadow-2xs cursor-pointer shrink-0 transition-colors"
                    title="Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Settings</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsSidebarOpen(false);
                      setShowAuthModal(true);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-[#1F1F1F] dark:bg-white text-white dark:text-[#12161C] hover:bg-black dark:hover:bg-gray-100 text-xs font-semibold transition-all shadow-2xs cursor-pointer active:scale-98"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Sign in / up</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsSidebarOpen(false);
                      setShowSettings(true);
                    }}
                    className="p-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#21262D] hover:bg-gray-50 dark:hover:bg-[#30363D] text-gray-700 dark:text-gray-200 transition-colors shadow-2xs cursor-pointer"
                    title="Settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Conversation Area */}
      
      
      {/* Create Project Modal */}
      {showCreateProject && (
        <div className="fixed inset-0 bg-black/40 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#FCFBF9] w-full max-w-sm rounded-3xl shadow-xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 p-6">
            <h2 className="text-xl font-bold text-center text-[#2A2925] mb-2">Create project</h2>
            <p className="text-sm text-center text-gray-500 mb-6 px-4">
              Organise your conversations and files in one place. Create podcasts, quizzes, and more from your files.
            </p>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-[#45433D] dark:text-gray-200 mb-1">Project name</label>
                <input 
                  type="text"
                  placeholder="Name your project"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleCreateProject();
                    if (e.key === 'Escape') setShowCreateProject(false);
                  }}
                  autoFocus
                  className="w-full px-4 py-3 bg-transparent border-2 border-[#2A2925] rounded-xl focus:outline-none focus:ring-0 text-sm font-medium placeholder:font-normal"
                />
              </div>
              
              <div>
                <label className="block text-sm text-[#45433D] dark:text-gray-200 mb-1">Add your materials</label>
                <div className="border border-dashed border-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center text-center bg-[#F8F6F1]/50 cursor-pointer hover:bg-[#F0EEEA] dark:bg-[#21262D] transition-colors">
                  <ImageIcon className="w-6 h-6 text-gray-400 mb-2" />
                  <span className="text-xs text-gray-500">Drag and drop or click to upload</span>
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-4 text-xs font-medium text-gray-600">
                <button className="flex items-center gap-1.5 hover:text-gray-900"><Link className="w-4 h-4" /> Add link</button>
                <button className="flex items-center gap-1.5 hover:text-gray-900"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e7/Microsoft_OneDrive_Icon_%282025_-_present%29.svg" alt="OneDrive" className="w-4 h-4" /> OneDrive</button>
                <button className="flex items-center gap-1.5 hover:text-gray-900"><img src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Google_Drive_icon_%282026%29.svg" alt="Google Drive" className="w-4 h-4" /> Google Drive</button>
              </div>
            </div>
            
            <div className="flex flex-col gap-2 mt-auto">
              <button 
                onClick={handleCreateProject}
                disabled={!newProjectName.trim()}
                className="w-full py-3.5 rounded-xl bg-[#2A2925] text-white font-medium hover:bg-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Create project
              </button>
              <button 
                onClick={() => setShowCreateProject(false)}
                className="w-full py-3.5 rounded-xl text-[#45433D] dark:text-gray-200 font-medium hover:bg-[#F2F0E8] dark:hover:bg-[#21262D] transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 px-4 py-2 bg-black text-white text-sm font-medium rounded-full shadow-lg z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
          {toastMessage}
        </div>
      )}

      <main className="flex-1 flex flex-col relative w-full overflow-hidden z-10">
        <div className="flex-1 overflow-y-auto px-4 md:px-8 relative z-10 custom-scrollbar">
          
          {/* Top Date Header */}
          <div className="max-w-2xl mx-auto pt-3 pb-1 text-xs text-gray-400 font-medium">
            Today
          </div>

          {/* Empty State Greetings (Exact Pentagon Style) */}
          {messages.length === 0 && !loading && (
            <div className="max-w-2xl mx-auto py-8 space-y-4 animate-in fade-in duration-300">
              {isTemporary ? (
                <div className="flex flex-col animate-in fade-in zoom-in-95 duration-200">
                  <h2 className="text-3xl font-bold text-[#1A1A1A] dark:text-white mb-3">Temporary chat</h2>
                  <p className="text-[15px] leading-relaxed text-gray-500 max-w-[400px]">
                    This chat will not be saved to history, reflected in memory, or used to train AI models. We will keep your chat for up to 30 days.
                  </p>
                </div>
              ) : (
                <>
                  <div className="text-[28px] font-bold tracking-tight text-[#1A1A1A] dark:text-white mb-3">
                    Hi {userProfile?.name ? userProfile.name.split(' ')[0] : 'Farooq'}, what should we dive into today?
                  </div>

                  </>
              )}
            </div>
          )}

          {/* Chat Messages List (100% Unified Styling for ALL models) */}
          {messages.length > 0 && (
            <div className="space-y-6 py-4 w-full max-w-2xl mx-auto px-1 sm:px-0">
              {messages.map((msg, index) => {
                const isUser = msg.role === 'user';
                const hasUrdu = !isUser && /[\u0600-\u06FF]/.test(msg.content);

                if (isUser) {
                  const hasDisplayContent = msg.displayContent && msg.displayContent.trim().length > 0;
                  const textToDisplay = msg.displayContent !== undefined ? msg.displayContent : msg.content;
                  
                  return (
                    <div key={msg.id} className="flex justify-end animate-in fade-in duration-200">
                      <div className="flex flex-col items-end space-y-2 max-w-[85%] sm:max-w-[80%]">
                        {/* Render Attachments as small reference cards if they exist */}
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="flex flex-wrap gap-2 justify-end">
                            {msg.attachments.map((doc) => {
                              const isPdf = doc.type.includes('pdf') || doc.name.toLowerCase().endsWith('.pdf');
                              return (
                                <div key={doc.id} className="flex items-center gap-2 bg-white border border-gray-200 p-1.5 pr-3 rounded-2xl shadow-sm text-sm">
                                  {doc.previewUrl && !isPdf ? (
                                    <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 bg-gray-100 border border-gray-200">
                                      <img src={doc.previewUrl} alt={doc.name} className="w-full h-full object-cover" />
                                    </div>
                                  ) : (
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-white ${isPdf ? 'bg-red-500' : 'bg-blue-600'}`}>
                                      {isPdf ? 'PDF' : 'DOC'}
                                    </div>
                                  )}
                                  <span className="text-gray-700 font-medium truncate max-w-[120px] text-xs">
                                    {isPdf ? 'PDF Document' : (doc.type.startsWith('image/') ? 'Image' : 'Document')}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                        
                        {/* Connector Badge if used */}
                        {msg.connector && (
                          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-semibold self-end border border-blue-200 dark:border-blue-800/60 shadow-2xs animate-in fade-in duration-150">
                            <AtSign className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                            <span>{msg.connector}</span>
                          </div>
                        )}

                        {/* Only render text bubble if there is text */}
                        {textToDisplay && textToDisplay.trim().length > 0 && (
                          <div className="bg-[#EEEEEC] text-[#1A1A1A] dark:text-white rounded-[22px] px-5 py-3 text-[15.5px] font-normal leading-relaxed shadow-none break-words whitespace-pre-wrap max-w-full overflow-hidden">
                            {textToDisplay}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                }

                // Assistant Message (Strictly Unified format - Exact Action Bar from IMG_20260819_221243)
                return (
                  <div key={msg.id} className="flex flex-col space-y-2 animate-in fade-in duration-200 min-w-0 w-full overflow-hidden">
                    
                    {/* Markdown Body or Comparison Carousel */}
                    {msg.comparisonResults ? (
                      <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory">
                        {msg.comparisonResults.map((cr, idx) => (
                          <div key={idx} className="snap-start flex-shrink-0 w-[85vw] sm:w-[350px] bg-white dark:bg-[#161B22] border border-[#EAE8E2] dark:border-[#30363D] rounded-2xl flex flex-col max-h-[650px] shadow-sm">
                            <div className="flex items-center gap-2 px-4 py-3 sticky top-0 bg-white dark:bg-[#161B22] border-b border-[#EAE8E2] dark:border-[#30363D] rounded-t-2xl z-10">
                              <ModelLogo modelId={cr.modelId} className="w-5 h-5 shrink-0" />
                              <span className="font-semibold text-[14.5px] text-[#1F1F1F] dark:text-gray-200">{cr.modelName}</span>
                            </div>
                            <div className="p-4 overflow-y-auto flex-1">
                              {cr.loading ? (
                                <div className="flex items-center gap-2 text-[15px] text-gray-500 py-2">
                                  <Brain className="w-4 h-4 animate-pulse text-gray-400" />
                                  <span>Generating</span>
                                </div>
                              ) : (
                                <div className="flex flex-col h-full">
                                  <div className="text-[14.5px] leading-[1.65] text-[#1A1A1A] dark:text-gray-200 prose prose-sm dark:prose-invert max-w-none break-words flex-1">
                                    <ReactMarkdown remarkPlugins={memoizedRemarkPlugins} rehypePlugins={memoizedRehypePlugins} components={memoizedComponents}>
                                      {preprocessMathForKaTeX(cr.content || '')}
                                    </ReactMarkdown>
                                  </div>
                                  <div className="flex items-center gap-5 pt-3 mt-4 text-[#454545] border-t border-[#EAE8E2] dark:border-[#30363D]">
                                    <button onClick={() => handleCopy(msg.id + cr.modelId, cr.content)} className="hover:text-black transition-colors" title="Copy">
                                      {copiedId === msg.id + cr.modelId ? <Check className="w-4 h-4 text-emerald-600" /> : <PentagonCopyIcon className="w-4 h-4" />}
                                    </button>
                                    <button onClick={() => handleTextToSpeech(msg.id + cr.modelId, cr.content)} className="hover:text-black transition-colors" title="Read aloud">
                                      {ttsLoading === msg.id + cr.modelId ? <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" /> : <PentagonVolumeIcon className="w-4 h-4" />}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className={`text-[15.5px] leading-[1.65] text-[#1A1A1A] dark:text-white pl-0.5 max-w-none break-words overflow-x-auto overflow-y-hidden ${hasUrdu ? 'chat-response' : ''}`}>
                        <TypingMarkdown
                          content={msg.content}
                          isNew={msg.isNew}
                          onComplete={() => {
                            setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, isNew: false } : m));
                          }}
                          remarkPlugins={memoizedRemarkPlugins}
                          rehypePlugins={memoizedRehypePlugins}
                          components={memoizedComponents}
                        />
                      </div>
                    )}

                    {msg.emailDraft && (
                      <div className="mt-4 p-4 bg-white dark:bg-[#161B22] border border-gray-200 dark:border-[#30363D] rounded-xl shadow-sm animate-in fade-in zoom-in-95">
                        <div className="flex items-center gap-2 mb-3">
                          <img src="https://upload.wikimedia.org/wikipedia/commons/8/8f/Gmail_icon_%282026%29.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Gmail" className="w-5 h-5 drop-shadow-sm" />
                          <h4 className="font-semibold text-gray-800 dark:text-gray-200 text-[14px]">Email Draft Ready</h4>
                        </div>
                        <div className="text-[13px] mb-1"><span className="text-gray-500">To:</span> <span className="font-medium text-gray-800 dark:text-gray-200">{msg.emailDraft.to}</span></div>
                        <div className="text-[13px] mb-3"><span className="text-gray-500">Subject:</span> <span className="font-medium text-gray-800 dark:text-gray-200">{msg.emailDraft.subject}</span></div>
                        <div className="p-3 bg-[#F5F4F0] dark:bg-[#0D1117] rounded-lg text-[13px] text-gray-800 dark:text-gray-300 whitespace-pre-wrap border border-gray-200 dark:border-[#21262D]">
                          {msg.emailDraft.body}
                        </div>
                        
                        <div className="mt-4 flex gap-3">
                          <button 
                            onClick={async (e) => {
                               const btn = e.currentTarget;
                               btn.disabled = true;
                               btn.innerText = 'Sending...';
                               try {
                                 const token = await getAccessToken();
                                 if (!token) throw new Error('Not connected');
                                 await sendEmail(token, msg.emailDraft!.to, msg.emailDraft!.subject, msg.emailDraft!.body);
                                 btn.innerText = 'Sent ✓';
                                 btn.classList.add('bg-green-600', 'text-white', 'border-transparent');
                                 btn.classList.remove('bg-black');
                               } catch (err) {
                                 btn.innerText = 'Failed';
                                 btn.disabled = false;
                               }
                            }}
                            className="bg-[#212121] text-white text-[12px] font-medium px-5 py-2 rounded-full hover:bg-black transition-colors shadow-sm"
                          >
                            Confirm & Send
                          </button>
                        </div>
                      </div>
                    )}

                    {/* YouTube Music Embedded Interactive Player Card */}
                    {msg.musicTracks && msg.musicTracks.length > 0 && (
                      <YouTubeMusicPlayerCard tracks={msg.musicTracks} />
                    )}

                    {!msg.isNew && !msg.comparisonResults && (
                      <>
                    {/* Direct Search Images Gallery */}
                    {msg.images && msg.images.length > 0 && (
                      <div className="pt-2 pb-2">
                        <div className="columns-2 sm:columns-3 gap-2 space-y-2">
                          {msg.images.map((img, imgIdx) => (
                            <div
                              key={imgIdx}
                              onClick={() => setActiveImageLightbox(img)}
                              className="break-inside-avoid flex flex-col cursor-pointer group"
                            >
                              <div className="w-full rounded-xl overflow-hidden bg-black/5 relative shadow-sm hover:shadow-md transition-all">
                                {img.url && img.url.trim() !== '' ? (
                                  <img
                                    src={img.url}
                                    alt={img.title || ''}
                                    className="w-full h-auto block group-hover:scale-[1.02] transition-transform duration-300"
                                    loading="lazy"
                                    referrerPolicy="no-referrer"
                                    onError={(e) => {
                                      const parent = (e.target as HTMLElement).closest('.break-inside-avoid');
                                      if (parent) (parent as HTMLElement).style.display = 'none';
                                    }}
                                  />
                                ) : null}
                              </div>
                              <div className="pt-1.5 pb-1 px-0.5">
                                <p className="text-[12px] font-medium text-gray-800 dark:text-gray-200 line-clamp-1 group-hover:text-black dark:group-hover:text-white transition-colors">
                                  {img.title || 'Image'}
                                </p>
                                <p className="text-[11px] text-gray-500 dark:text-gray-400 line-clamp-1">
                                  {img.sourceName || 'Web'}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Rich Source Preview Cards & Show All Drawer Trigger */}
                    {msg.sources && msg.sources.length > 0 ? (
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        {/* Primary Source Card */}
                        {msg.sources.slice(0, 1).map((src, sIdx) => (
                          <a
                            key={sIdx}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2.5 max-w-[260px] sm:max-w-[300px] px-3 py-1.5 rounded-2xl border border-[#DFDED9] dark:border-[#30363D] bg-white hover:bg-[#F9F9F8] shadow-[0_1px_2px_rgba(0,0,0,0.03)] transition-all group cursor-pointer text-left"
                          >
                            <div className="w-5 h-5 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center flex-shrink-0 overflow-hidden">
                              {(src.iconUrl || src.domain) ? (
                                <img
                                  src={src.iconUrl || `https://www.google.com/s2/favicons?domain=${encodeURIComponent(src.domain)}&sz=64`}
                                  alt=""
                                  className="w-3.5 h-3.5 object-contain"
                                  onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                                />
                              ) : (
                                <span className="w-2 h-2 rounded-full bg-gray-400" />
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider truncate">
                                {src.siteName || src.domain}
                              </p>
                              <p className="text-[12px] font-medium text-gray-900 truncate group-hover:text-black">
                                {src.title}
                              </p>
                            </div>
                          </a>
                        ))}

                        {/* Show All Card with Stacked Favicons */}
                        {msg.sources.length > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              setActiveSourcesModalMsg(msg);
                              setSourcesTab('references');
                            }}
                            className="flex items-center gap-2 px-3 py-1.5 rounded-2xl border border-[#DFDED9] dark:border-[#30363D] bg-white hover:bg-[#F9F9F8] shadow-[0_1px_2px_rgba(0,0,0,0.03)] transition-all cursor-pointer group"
                          >
                            <div className="flex items-center -space-x-1.5 overflow-hidden">
                              {msg.sources.slice(0, 4).map((src, i) => (
                                <div
                                  key={i}
                                  className="w-4 h-4 rounded-full bg-white border border-gray-300 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-xs"
                                  style={{ zIndex: 10 - i }}
                                >
                                  {(src.iconUrl || src.domain) ? (
                                    <img
                                      src={src.iconUrl || `https://www.google.com/s2/favicons?domain=${encodeURIComponent(src.domain)}&sz=32`}
                                      alt=""
                                      className="w-3 h-3 object-contain"
                                      onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                                    />
                                  ) : (
                                    <span className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                                  )}
                                </div>
                              ))}
                            </div>
                            <span className="text-[12px] font-medium text-gray-800 group-hover:text-black flex items-center gap-1.5">
                              Show all
                              <span className="px-1.5 py-0.2 rounded-full bg-gray-100 border border-gray-200 text-[10.5px] font-bold text-gray-700">
                                {msg.sources.length}
                              </span>
                            </span>
                            <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-gray-700" />
                          </button>
                        )}
                      </div>
                    ) : (
                      /* Fallback Citations Badges */
                      msg.citations && msg.citations.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1.5 pt-1">
                          {msg.citations.map((cite, cIdx) => (
                            <span key={cIdx} className="text-[11px] bg-[#EFEFEF] text-[#4F4F4F] px-2 py-0.5 rounded-[6px] border border-[#DFDED9] dark:border-[#30363D] font-medium">
                              {cite}
                            </span>
                          ))}
                        </div>
                      )
                    )}

                    {/* Smart Follow-up Suggestions */}
                    {msg.suggestions && msg.suggestions.length > 0 && (
                      <div className="flex flex-wrap items-center gap-2 pt-3 pb-1">
                        {msg.suggestions.map((suggestion, sIdx) => (
                          <button
                            key={sIdx}
                            onClick={() => handleSend(suggestion)}
                            className="text-[13px] bg-white text-[#1A1A1A] dark:text-white hover:bg-[#F2F1EC] transition-colors px-3.5 py-1.5 rounded-full border border-[#DFDED9] dark:border-[#30363D] shadow-[0_1px_2px_rgba(0,0,0,0.03)] flex items-center font-medium cursor-pointer"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Action Bar */}
                    <div className="flex items-center gap-6 sm:gap-7 pt-4 pb-2 text-[#454545] relative">
                      
                      {/* 1. Thumbs Up */}
                      <button
                        type="button"
                        onClick={() => handleFeedback(msg.id, 'up')}
                        className="hover:text-black hover:opacity-70 transition-opacity cursor-pointer"
                        title="Good response"
                      >
                        <PentagonThumbUpIcon filled={msg.feedback === 'up'} className="w-5 h-5" />
                      </button>

                      {/* 2. Thumbs Down */}
                      <button
                        type="button"
                        onClick={() => handleFeedback(msg.id, 'down')}
                        className="hover:text-black hover:opacity-70 transition-opacity cursor-pointer"
                        title="Bad response"
                      >
                        <PentagonThumbDownIcon filled={msg.feedback === 'down'} className="w-5 h-5" />
                      </button>

                      {/* 3. Share */}
                      <button
                        type="button"
                        onClick={() => handleShare(msg.content)}
                        className="hover:text-black hover:opacity-70 transition-opacity cursor-pointer"
                        title="Share"
                      >
                        <PentagonShareIcon className="w-5 h-5" />
                      </button>

                      {/* 4. Copy */}
                      <button
                        type="button"
                        onClick={() => handleCopy(msg.id, msg.content)}
                        className="hover:text-black hover:opacity-70 transition-opacity cursor-pointer relative"
                        title="Copy to clipboard"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <PentagonCopyIcon className="w-5 h-5" />
                        )}
                      </button>

                      {/* 5. Speaker / Audio */}
                      <button
                        type="button"
                        onClick={() => handleTextToSpeech(msg.id, msg.content)}
                        className={`hover:text-black hover:opacity-70 transition-all duration-300 cursor-pointer ${speakingId === msg.id ? 'text-purple-600 animate-pulse scale-110' : ''}`}
                        title="Read aloud"
                      >
                        {ttsLoading === msg.id ? (
                          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <PentagonVolumeIcon className="w-5 h-5" />
                        )}
                      </button>

                      {/* 6. More Options (...) */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => setMoreMenuId(moreMenuId === msg.id ? null : msg.id)}
                          className="hover:text-black hover:opacity-70 transition-opacity cursor-pointer pt-0.5"
                          title="More options"
                        >
                          <PentagonMoreIcon className="w-5 h-5" />
                        </button>

                        {moreMenuId === msg.id && (
                          <>
                            <div className="fixed inset-0 z-40" onClick={() => setMoreMenuId(null)} />
                            <div className="absolute bottom-full left-0 mb-2 w-52 bg-white dark:bg-[#1A1F26] rounded-2xl shadow-xl border border-gray-200/80 dark:border-[#2D333B] py-1.5 px-1.5 z-50 animate-in fade-in zoom-in-95 font-sans">
                              {/* 1. Edit query */}
                              <button
                                type="button"
                                onClick={() => {
                                  setMoreMenuId(null);
                                  const userMsg = messages.slice(0, index).reverse().find(m => m.role === 'user');
                                  if (userMsg) {
                                    setInput(userMsg.content);
                                    if (inputRef.current) {
                                      inputRef.current.focus();
                                      inputRef.current.style.height = 'auto';
                                      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
                                    }
                                    showToast("Query loaded for editing");
                                  } else {
                                    showToast("No query found to edit");
                                  }
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100/80 dark:hover:bg-[#262C36] rounded-xl text-left transition-colors cursor-pointer"
                              >
                                <svg className="w-4 h-4 text-gray-600 dark:text-gray-300 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                </svg>
                                <span>Edit query</span>
                              </button>

                              {/* 2. Unhelpful */}
                              <button
                                type="button"
                                onClick={() => {
                                  setMoreMenuId(null);
                                  handleFeedback(msg.id, 'down');
                                  showToast("Feedback recorded: Unhelpful");
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100/80 dark:hover:bg-[#262C36] rounded-xl text-left transition-colors cursor-pointer"
                              >
                                <svg className="w-4 h-4 text-gray-600 dark:text-gray-300 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17" />
                                </svg>
                                <span>Unhelpful</span>
                              </button>

                              {/* 3. Export as PDF (Direct 1-click vector PDF with loading spinner) */}
                              <button
                                type="button"
                                disabled={exportingPdfId === msg.id}
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  if (exportingPdfId) return;
                                  try {
                                    setExportingPdfId(msg.id);
                                    showToast("Generating PDF document...");
                                    await exportVectorPdf(msg.content, `Pentagon-Response-${msg.id.substring(0, 6)}`);
                                    showToast("PDF downloaded successfully!");
                                  } catch (err) {
                                    console.error("PDF Export Error:", err);
                                    showToast("Failed to generate PDF");
                                  } finally {
                                    setExportingPdfId(null);
                                    setMoreMenuId(null);
                                  }
                                }}
                                className={`w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium rounded-xl text-left transition-colors cursor-pointer ${
                                  exportingPdfId === msg.id
                                    ? 'bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 cursor-wait'
                                    : 'text-gray-700 dark:text-gray-200 hover:bg-gray-100/80 dark:hover:bg-[#262C36]'
                                }`}
                              >
                                {exportingPdfId === msg.id ? (
                                  <Loader2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 animate-spin shrink-0" />
                                ) : (
                                  <svg className="w-4 h-4 text-gray-600 dark:text-gray-300 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                                    <polyline points="14 2 14 8 20 8" />
                                    <text x="6" y="16.5" fontSize="4.8" fontWeight="bold" fill="currentColor" stroke="none" fontFamily="sans-serif">PDF</text>
                                  </svg>
                                )}
                                <span>{exportingPdfId === msg.id ? 'Generating PDF...' : 'Export as PDF'}</span>
                              </button>

                              {/* 4. Export as Markdown */}
                              <button
                                type="button"
                                onClick={() => {
                                  setMoreMenuId(null);
                                  exportMarkdownFile(msg.content, `Pentagon-Response-${msg.id.substring(0, 6)}`);
                                  showToast("Markdown (.md) exported!");
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100/80 dark:hover:bg-[#262C36] rounded-xl text-left transition-colors cursor-pointer"
                              >
                                <svg className="w-4 h-4 text-gray-600 dark:text-gray-300 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                  <rect x="3" y="4" width="18" height="16" rx="2" />
                                  <path d="M7 15V9l2.5 3L12 9v6" strokeWidth="1.6" />
                                  <path d="M16 11v4m-1.5-1.5l1.5 1.5 1.5-1.5" strokeWidth="1.6" />
                                </svg>
                                <span>Export as Markdown</span>
                              </button>

                              {/* 5. Export as DOCX */}
                              <button
                                type="button"
                                onClick={() => {
                                  setMoreMenuId(null);
                                  exportDocxFile(msg.content, `Pentagon-Response-${msg.id.substring(0, 6)}`);
                                  showToast("Word document (.doc) exported!");
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100/80 dark:hover:bg-[#262C36] rounded-xl text-left transition-colors cursor-pointer"
                              >
                                <svg className="w-4 h-4 text-gray-600 dark:text-gray-300 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                                  <polyline points="14 2 14 8 20 8" />
                                  <text x="5" y="16.5" fontSize="4.2" fontWeight="bold" fill="currentColor" stroke="none" fontFamily="sans-serif">DOCX</text>
                                </svg>
                                <span>Export as DOCX</span>
                              </button>

                              {/* 6. Delete */}
                              <button
                                type="button"
                                onClick={() => {
                                  setMoreMenuId(null);
                                  setMessages(prev => {
                                    const updated = prev.filter(m => m.id !== msg.id);
                                    const session = sessions.find(s => s.id === currentSessionId);
                                    if (session) {
                                      const updatedSessions = sessions.map(s => s.id === currentSessionId ? { ...s, messages: updated } : s);
                                      setSessions(updatedSessions);
                                      localStorageHelper.saveSessions(updatedSessions);
                                      if (authUser) {
                                        saveSessionToFirestore(authUser.uid, { ...session, messages: updated });
                                      }
                                    }
                                    return updated;
                                  });
                                  showToast("Message deleted");
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13.5px] font-medium text-[#B91C1C] dark:text-[#EF4444] hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl text-left transition-colors cursor-pointer"
                              >
                                <svg className="w-4 h-4 text-[#B91C1C] dark:text-[#EF4444] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                                  <polyline points="3 6 5 6 21 6" />
                                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                                  <line x1="10" y1="11" x2="10" y2="17" />
                                  <line x1="14" y1="11" x2="14" y2="17" />
                                </svg>
                                <span>Delete</span>
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                    </>
                    )}
                  </div>
                );
              })}

              {/* Clean Subtle Loading Indicator */}
              {loading && !messages.some(m => m.comparisonResults?.some(cr => cr.loading)) && (
                <div className="flex flex-col space-y-2 animate-in fade-in py-2">
                  <div className="flex items-center gap-1.5 text-sm text-gray-500">
                    <span>{loadingStatus}</span>
                    <span className="inline-flex gap-1 pt-1">
                      <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                      <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                      <span className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                    </span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}

        </div>

        {/* Streamlined Floating Input Bar */}
        <div className={`shrink-0 max-w-3xl w-full mx-auto px-4 pb-5 pt-1 bg-gradient-to-t z-20 ${theme === "Night" ? "from-[#11141A] via-[#11141A] to-transparent" : "from-[#FAF9F6] via-[#FAF9F6] to-transparent"}`}>
          
          {/* Logo Marquee on Home Screen */}
          {messages.length === 0 && (
            <div className="overflow-hidden w-full mb-3 sm:mb-4 pointer-events-none select-none relative" style={{ WebkitTouchCallout: 'none', userSelect: 'none' }}>
              <div className="logo-marquee-track items-center gap-12 sm:gap-16 opacity-[0.45] dark:opacity-40 grayscale mix-blend-multiply dark:mix-blend-screen filter">
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5a/Xiaomi_MiMo_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Xiaomi" className="h-[14px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Gemini" className="h-[18px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Meta" className="h-[13px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/a/a0/OpenAI_wordmark_2017.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="OpenAI" className="h-[18px] object-contain" />
                
                {/* Duplicate for infinite effect */}
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5a/Xiaomi_MiMo_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Xiaomi" className="h-[14px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Gemini" className="h-[18px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Meta" className="h-[13px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/a/a0/OpenAI_wordmark_2017.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="OpenAI" className="h-[18px] object-contain" />
                
                {/* 2nd Duplicate to ensure no gap on wide screens */}
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5a/Xiaomi_MiMo_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Xiaomi" className="h-[14px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Gemini" className="h-[18px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="Meta" className="h-[13px] object-contain" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/a/a0/OpenAI_wordmark_2017.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original" alt="OpenAI" className="h-[18px] object-contain" />
              </div>
            </div>
          )}
          


          {/* Clean Input Surface */}
          <div className={`relative rounded-[32px] sm:rounded-[36px] border p-3.5 sm:p-4 transition-all duration-300 ${theme === "Night" ? "bg-[#1E242C] border-[#30363D] shadow-[0_8px_32px_rgba(0,0,0,0.3)] focus-within:border-[#4B5563]" : "bg-white border-[#E5E5E5] shadow-[0_8px_30px_rgba(0,0,0,0.06)] focus-within:shadow-[0_8px_35px_rgba(0,0,0,0.08)] focus-within:border-[#D1D1D1]"}`}>
            
            {/* Active Connector Chip (Inside Input Card) */}
              {youtubeModeActive && (
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800/80 mb-2.5 shadow-2xs animate-in fade-in zoom-in-95 duration-150">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg" alt="YouTube" className="w-3.5 h-3.5 object-contain" />
                  <span className="text-xs sm:text-[13px] font-semibold">YouTube</span>
                  <button
                    type="button"
                    onClick={() => setYoutubeModeActive(false)}
                    className="w-4 h-4 rounded-full hover:bg-red-200/60 dark:hover:bg-red-800/60 flex items-center justify-center text-red-500 hover:text-red-700 transition-colors ml-0.5 cursor-pointer"
                    title="Remove connector"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              {youtubeMusicModeActive && (
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800/80 mb-2.5 shadow-2xs animate-in fade-in zoom-in-95 duration-150">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/6/6a/Youtube_Music_icon.svg" alt="YouTube Music" className="w-3.5 h-3.5 object-contain" />
                  <span className="text-xs sm:text-[13px] font-semibold">YouTube Music</span>
                  <button
                    type="button"
                    onClick={() => setYoutubeMusicModeActive(false)}
                    className="w-4 h-4 rounded-full hover:bg-red-200/60 dark:hover:bg-red-800/60 flex items-center justify-center text-red-500 hover:text-red-700 transition-colors ml-0.5 cursor-pointer"
                    title="Remove connector"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              {/* Attached Files List (OCR Space Enabled) */}
              {attachedFiles.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 mb-2.5 pt-0.5">
                  {attachedFiles.map(file => {
                    const isPdf = file.name.toLowerCase().endsWith('.pdf') || file.type.includes('pdf');
                    return (
                      <div
                        key={file.id}
                        className="inline-flex items-center gap-2 px-2.5 py-1.5 rounded-full bg-[#F5F4F0] border border-[#E5E3DC] text-xs text-[#222222] shadow-sm max-w-full animate-in fade-in zoom-in-95 duration-150"
                      >
                        {file.previewUrl ? (
                          <img src={file.previewUrl} alt="preview" className="w-5 h-5 rounded-md object-cover" />
                        ) : (
                          <span className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold text-white ${isPdf ? 'bg-red-500' : 'bg-blue-600'}`}>
                            {isPdf ? 'PDF' : 'DOC'}
                          </span>
                        )}

                        <span className="font-medium truncate max-w-[140px] sm:max-w-[200px]">
                          {isPdf ? 'PDF Document' : (file.type.startsWith('image/') ? 'Image' : 'Document')}
                        </span>

                        {/* Remove Attachment Button */}
                        <button
                          type="button"
                          onClick={() => removeAttachment(file.id)}
                          className="w-4 h-4 rounded-full hover:bg-black/10 text-gray-500 hover:text-gray-800 flex items-center justify-center cursor-pointer transition-colors"
                          title="Remove file"
                        >
                          ×
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Multiline Textarea with Magic Particle Blur Overlay */}
              <div className="relative w-full">
                {isEnhancingPrompt && (
                  <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden flex items-center justify-center">
                    {/* Centered glowing status pill */}
                    <div className="absolute z-30 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#111827]/90 dark:bg-white/95 text-white dark:text-gray-900 shadow-xl backdrop-blur-md text-xs font-semibold animate-in zoom-in-95 duration-200 border border-purple-500/30">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400 dark:text-amber-500 animate-spin" />
                      <span>AI is optimizing your prompt...</span>
                    </div>

                    {/* Dynamic Rising Magic Sparkle & Glowing Particles */}
                    {[...Array(14)].map((_, i) => {
                      const leftPos = 6 + (i * 7) % 86;
                      const topPos = 25 + ((i * 11) % 55);
                      const delay = (i * 0.09).toFixed(2);
                      const size = i % 3 === 0 ? 'w-3 h-3' : i % 2 === 0 ? 'w-2 h-2' : 'w-1.5 h-1.5';
                      const color = i % 4 === 0 ? 'text-amber-400' : i % 4 === 1 ? 'text-purple-400' : i % 4 === 2 ? 'text-cyan-400' : 'text-pink-400';
                      return (
                        <div
                          key={i}
                          className="magic-particle"
                          style={{
                            left: `${leftPos}%`,
                            top: `${topPos}%`,
                            animationDelay: `${delay}s`,
                            animationDuration: `${1.1 + (i % 3) * 0.3}s`
                          }}
                        >
                          {i % 2 === 0 ? (
                            <Sparkles className={`${size} ${color} filter drop-shadow-[0_0_6px_currentColor]`} />
                          ) : (
                            <div className={`${size} rounded-full bg-current ${color} filter drop-shadow-[0_0_6px_currentColor]`} />
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={handleInput}
                  onKeyDown={handleKeyDown}
                  rows={1}
                  placeholder={
                    youtubeModeActive
                      ? "Paste YouTube video link to summarize or ask anything..."
                      : youtubeMusicModeActive
                      ? "Search any song, artist or track to play (e.g. Tum Hi Ho)..."
                      : compareMode
                      ? "Ask all models at once..."
                      : "Message Pentagon"
                  }
                  className={`w-full resize-none bg-transparent border-0 outline-none text-[17px] leading-normal max-h-48 px-1 pt-0.5 pb-2 focus:ring-0 font-normal selection:bg-blue-100 ${
                    isEnhancingPrompt ? 'blur-[2px] opacity-40 transition-all duration-300' : 'transition-all duration-300'
                  } ${theme === 'Night' ? 'text-gray-100 placeholder-gray-500' : 'text-[#1F1F1F] dark:text-gray-200 placeholder-[#555555]'}`}
                />
              </div>

              {/* Hidden File Inputs */}
              <input
                type="file"
                ref={photoInputRef}
                onChange={handleFileInputChange}
                multiple
                accept="image/*"
                className="hidden"
              />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileInputChange}
                multiple
                accept=".pdf,.doc,.docx,.txt,.csv,.json,.md"
                className="hidden"
              />

              {/* Bottom Row Inside Card (100% Replica of IMG_20260819_221233) */}
              <div className="flex items-center justify-between pt-1 px-1">
                {/* Left Controls: Plus Button + Model Pill */}
                <div className="flex items-center gap-1 relative">
                  
                  {/* Round Plus Button (Triggers Menu) */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => {
                        if (showAttachmentMenu) {
                          setShowAttachmentMenu(false);
                        } else {
                          setShowPlusMenu(!showPlusMenu);
                        }
                      }}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer active:scale-95 relative z-50 ${(showAttachmentMenu || showPlusMenu) ? 'bg-gray-100 dark:bg-gray-800' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                      title="Add attachments or features"
                    >
                      <Plus className={`w-[22px] h-[22px] text-gray-500 transition-transform duration-200 ${(showAttachmentMenu || showPlusMenu) ? 'rotate-45' : ''}`} strokeWidth={2} />
                    </button>
                    {/* New Features Menu */}
                    {showPlusMenu && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => { setShowPlusMenu(false); setShowConnectorsSubMenu(false); }} />
                        <div className="absolute bottom-full -left-2 sm:left-0 mb-3 w-64 max-w-[calc(100vw-32px)] bg-white dark:bg-[#161B22] rounded-3xl shadow-[0_8px_40px_rgba(0,0,0,0.12)] border border-[#EAE8E2] dark:border-[#30363D] py-2 z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
                          {showConnectorsSubMenu ? (
                            <div className="flex flex-col">
                              <button
                                type="button"
                                onClick={() => setShowConnectorsSubMenu(false)}
                                className="w-full flex items-center gap-3 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                              >
                                <ChevronLeft className="w-5 h-5 text-gray-500" />
                                <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200">Back</span>
                              </button>
                              <div className="h-px bg-[#F0EFEA] mx-4 mb-1" />

                              <button 
                                type="button" 
                                onClick={() => {
                                  setYoutubeModeActive(!youtubeModeActive);
                                  setYoutubeMusicModeActive(false);
                                  setShowConnectorsSubMenu(false);
                                  setShowPlusMenu(false);
                                }}
                                className="w-full flex items-center justify-between px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                              >
                                <div className="flex items-center gap-3">
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg" alt="YouTube" className="w-5 h-5 object-contain" />
                                  <span className="text-[14.5px] font-medium text-[#1F1F1F] dark:text-gray-200">YouTube</span>
                                </div>
                                {youtubeModeActive && <Check className="w-4 h-4 text-emerald-500" />}
                              </button>

                              <button 
                                type="button" 
                                onClick={() => {
                                  setYoutubeMusicModeActive(!youtubeMusicModeActive);
                                  setYoutubeModeActive(false);
                                  setShowConnectorsSubMenu(false);
                                  setShowPlusMenu(false);
                                }}
                                className="w-full flex items-center justify-between px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                              >
                                <div className="flex items-center gap-3">
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/6/6a/Youtube_Music_icon.svg" alt="YouTube Music" className="w-5 h-5 object-contain" />
                                  <span className="text-[14.5px] font-medium text-[#1F1F1F] dark:text-gray-200">YouTube Music</span>
                                </div>
                                {youtubeMusicModeActive && <Check className="w-4 h-4 text-emerald-500" />}
                              </button>

                              {[
                                { name: 'Google Drive', icon: 'https://upload.wikimedia.org/wikipedia/commons/5/5f/Google_Drive_icon_%282026%29.svg' },
                                { name: 'Google Calendar', icon: 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Google_Calendar_icon_%282026%29.svg' },
                                { name: 'Gmail', icon: 'https://upload.wikimedia.org/wikipedia/commons/8/8f/Gmail_icon_%282026%29.svg' },
                                { name: 'Google Contacts', icon: 'https://upload.wikimedia.org/wikipedia/commons/a/a8/Google_Contacts_icon_%282022%29.svg' },
                                { name: 'Dropbox', icon: 'https://upload.wikimedia.org/wikipedia/commons/c/cb/Dropbox_logo_2017.svg' },
                              ].map(connector => (
                                <button key={connector.name} disabled className="w-full flex items-center justify-between px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors opacity-80 cursor-not-allowed">
                                  <div className="flex items-center gap-3">
                                    <img src={connector.icon} alt={connector.name} className="w-5 h-5 object-contain" />
                                    <span className="text-[14.5px] font-medium text-[#1F1F1F] dark:text-gray-200">{connector.name}</span>
                                  </div>
                                  <span className="text-[13px] text-gray-500 font-medium whitespace-nowrap ml-2">Coming soon</span>
                                </button>
                              ))}
                            </div>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setShowPlusMenu(false);
                                  setShowAttachmentMenu(true);
                                }}
                            className="w-full flex items-center gap-4 px-5 py-3.5 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Paperclip className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200">Add images or files</span>
                          </button>

                          <div className="h-px bg-[#F0EFEA] mx-4" />

                          <button
                            type="button"
                            onClick={() => {
                              setShowPlusMenu(false);
                              setCompareMode(true);
                              inputRef.current?.focus();
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <LayoutGrid className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200 flex-1">Compare models</span>
                          </button>

                          <button
                            type="button"
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Globe className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200 flex-1">Start deep research</span>
                            <span className="text-[11px] font-medium bg-[#EFEFEF] text-[#555] px-2 py-0.5 rounded-md whitespace-nowrap">5 remaining</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setShowPlusMenu(false);
                              handleSend(
`When the user requests Create a Podcast, the system should perform the following steps in sequence to deliver a complete podcast episode framework:

Clarify Topic
Ask or confirm the theme of the podcast (e.g., travel, technology, history, lifestyle).
If no topic is provided, suggest 2–3 engaging options.

Generate Episode Outline
Provide a structured outline including:
Introduction: Hook the audience, set the theme.
Main Segments: Share stories, interviews, or tips.
Transitions: Smooth flow between segments.
Conclusion: Summarize key takeaways and add a call‑to‑action.

Suggest Content Ideas
Offer talking points, draft scripts, or interview questions.
Include storytelling techniques and examples relevant to the chosen topic.

Enhance Creativity
Recommend tone and style (casual, professional, inspirational).
Suggest background music, sound effects, or guest involvement.

Audience Engagement
Provide strategies to involve listeners (Q&A, shoutouts, polls).
Suggest ways to build community around the podcast.

Outcome:  
The system should deliver a complete, ready‑to‑use podcast episode framework that includes outline, content suggestions, creative enhancements, and audience engagement strategies. The user can then record and publish based on this framework.`,
                                "Create a podcast."
                              );
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Headphones className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200 flex-1">Create a podcast</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setShowPlusMenu(false);
                              handleSend(
`When the user requests Take a Quiz, the system should deliver an interactive quiz experience by following these steps:

1. Topic Clarification
Ask or confirm the subject of the quiz (e.g., science, history, geography, literature).
If no topic is provided, suggest 2–3 engaging options.

2. Quiz Generation
Create a set of multiple‑choice questions (MCQs).
Each question should have:
A clear question statement.
3–4 answer options.
One correct answer clearly marked internally.

3. Difficulty Levels
Offer questions in varying levels: easy, medium, and hard.
Adjust complexity based on user’s progress or request.

4. Interactive Flow
Present one question at a time.
Allow the user to select an answer.
Immediately provide feedback:
Correct → Positive reinforcement.
Incorrect → Explain the right answer briefly.

5. Scoring System
Track the number of correct answers.
Display score at the end of the quiz.
Optionally show percentage or grade (e.g., 7/10 = 70%).

6. Learning Enhancement
Provide short explanations for each answer to reinforce learning.
Suggest follow‑up resources or topics for deeper study.

7. Customization Options
Allow user to choose:
Number of questions (5, 10, 20).
Subject area (math, science, history, etc.).
Difficulty level (easy, medium, hard).

8. Completion Summary
At the end, show:
Total score.
Correct vs incorrect answers.
Encouragement message.
Suggest next quiz or related topics.

Outcome:  
The system should deliver a fully interactive quiz experience that includes topic clarification, question generation, difficulty levels, interactive flow, scoring, learning reinforcement, customization options, and a completion summary. The user can practice knowledge, test skills, and receive immediate feedback.`,
                                "Take a quiz."
                              );
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer mb-1"
                          >
                            <BookOpenCheck className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200">Take a quiz</span>
                          </button>

                          <div className="h-px bg-[#F0EFEA] mx-4" />

                          <button
                            type="button"
                            onClick={() => {
                              setShowPlusMenu(false);
                              setShowNotificationModal(true);
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <BellRing className="w-5 h-5 text-amber-600 dark:text-amber-400" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200 flex-1">Set task / reminder</span>
                            {scheduledTasksList.filter(t => t.status === 'pending' || t.status === 'snoozed').length > 0 && (
                              <span className="text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded-full">
                                {scheduledTasksList.filter(t => t.status === 'pending' || t.status === 'snoozed').length} active
                              </span>
                            )}
                          </button>

                          <div className="h-px bg-[#F0EFEA] mx-4" />

                          <button
                            type="button"
                            onClick={() => {
                              setShowConnectorsSubMenu(true);
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3.5 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Waypoints className="w-5 h-5 text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                            <span className="text-[15.5px] font-medium text-[#1F1F1F] dark:text-gray-200 flex-1">Use connectors</span>
                            <ChevronRight className="w-4 h-4 text-[#888]" />
                          </button>
                            </>
                          )}
                        </div>
                      </>
                    )}

                    {/* Original Attachment Menu */}
                    {showAttachmentMenu && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setShowAttachmentMenu(false)} />
                        <div className="absolute bottom-full left-0 mb-3 w-56 bg-white rounded-3xl shadow-[0_8px_40px_rgba(0,0,0,0.12)] border border-[#EAE8E2] py-3 z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
                          <button
                            type="button"
                            onClick={startCamera}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Camera className="w-[22px] h-[22px] text-[#1F1F1F] dark:text-gray-200" />
                            <span className="text-[17px] font-medium text-[#1A1A1A] dark:text-white">Camera</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              photoInputRef.current?.click();
                              setShowAttachmentMenu(false);
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <ImageIcon className="w-[22px] h-[22px] text-[#1F1F1F] dark:text-gray-200" />
                            <span className="text-[17px] font-medium text-[#1A1A1A] dark:text-white">Photos</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              fileInputRef.current?.click();
                              setShowAttachmentMenu(false);
                            }}
                            className="w-full flex items-center gap-4 px-5 py-3 text-left hover:bg-[#F7F6F3] dark:hover:bg-[#21262D] transition-colors cursor-pointer"
                          >
                            <Paperclip className="w-[22px] h-[22px] text-[#1F1F1F] dark:text-gray-200" />
                            <span className="text-[17px] font-medium text-[#1A1A1A] dark:text-white">Files</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Tools Button */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setShowToolsMenu(!showToolsMenu)}
                      className="w-10 h-10 rounded-full text-[#1F1F1F] dark:text-gray-200 hover:bg-[#F8F7F5] dark:hover:bg-[#21262D] flex items-center justify-center transition-all cursor-pointer active:scale-95 relative z-50"
                      title="Tools & Actions"
                    >
                      <SlidersHorizontal className="w-[18px] h-[18px] text-[#1F1F1F] dark:text-gray-200" strokeWidth={2} />
                    </button>
                    {showToolsMenu && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setShowToolsMenu(false)} />
                        <div className="absolute bottom-full left-0 mb-3 w-72 max-w-[calc(100vw-32px)] bg-white dark:bg-[#161B22] rounded-3xl shadow-[0_8px_40px_rgba(0,0,0,0.12)] border border-[#EAE8E2] dark:border-[#30363D] py-2 z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
                          {/* Web Grounding / Search */}
                          <div className="px-5 pb-1 pt-1.5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                            Web Search
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              const next = !searchMode;
                              setSearchMode(next);
                              localStorageHelper.saveSearchMode(next);
                            }}
                            className={`w-full flex items-center justify-between gap-3 px-5 py-2.5 text-left transition-colors cursor-pointer ${
                              searchMode ? 'bg-[#F0EEEA] dark:bg-[#21262D]' : 'hover:bg-[#F7F6F3] dark:hover:bg-[#21262D]'
                            }`}
                          >
                            <div className="flex items-center gap-3.5 min-w-0 flex-1">
                              <div className="w-5 h-5 flex items-center justify-center shrink-0">
                                <ModelLogo model="duckduckgo" className="w-5 h-5" />
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="text-[14.5px] font-medium text-[#1F1F1F] dark:text-gray-200 truncate">
                                  Google Search
                                </div>
                                <div className="text-[11px] text-gray-500 truncate">
                                  Real-time facts & web browsing
                                </div>
                              </div>
                            </div>
                            <div className={`w-9 h-5 rounded-full p-0.5 transition-colors shrink-0 flex items-center ${
                              searchMode ? 'bg-[#4285F4] justify-end' : 'bg-gray-200 dark:bg-gray-700 justify-start'
                            }`}>
                              <div className="w-4 h-4 rounded-full bg-white shadow-xs" />
                            </div>
                          </button>
                        </div>
                      </>
                    )}
                  </div>

                  
                  {shouldShowConsensus && (
                    <button
                      onClick={handleConsensusRequest}
                      className="h-10 px-3 ml-2 rounded-xl text-[14px] font-medium text-[#1F1F1F] hover:text-black dark:text-gray-200 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-1.5 transition-all cursor-pointer border border-[#EAE8E2] dark:border-[#30363D] shadow-[0_1px_2px_rgba(0,0,0,0.03)] bg-white dark:bg-[#161B22]"
                    >
                      <Brain className="w-4 h-4 text-gray-500 shrink-0" />
                      <span className="hidden sm:inline">Combine answers</span>
                      <span className="px-1.5 py-0.5 bg-[#1F1F1F] dark:bg-gray-200 text-white dark:text-black rounded-md text-[10.5px] font-bold">Consensus</span>
                    </button>
                  )}

                  <div className="flex-1" />
                  {compareMode ? (
                    <div className="relative ml-1.5">
                       <button 
                          onClick={() => setShowCompareSelector(!showCompareSelector)}
                          className="flex items-center gap-2 bg-[#F8F7F5] dark:bg-[#161B22] rounded-full p-1.5 pr-2 border border-[#EAE8E2] dark:border-[#30363D]"
                       >
                          <div className="flex -space-x-2">
                             {compareSelectedModels.length === 0 && (
                                <div className="w-8 h-8 rounded-full bg-white dark:bg-[#21262D] border border-gray-200 dark:border-gray-700 flex items-center justify-center">
                                   <LayoutGrid className="w-4 h-4 text-gray-500" />
                                </div>
                             )}
                             {compareSelectedModels.map((m, i) => {
                                const mod = ALL_MODELS.find(x => x.id === m);
                                return (
                                <div key={m} className={`w-8 h-8 rounded-full bg-white dark:bg-[#21262D] border border-gray-200 dark:border-gray-700 flex items-center justify-center z-[${10-i}] shadow-sm`}>
                                   {mod ? mod.renderIcon() : null}
                                </div>
                             )})}
                          </div>
                          <ChevronDown className="w-4 h-4 text-gray-500 mr-1" />
                       </button>
                       
                       {showCompareSelector && (
                          <div className="fixed inset-0 z-[100] flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                             <div className="absolute inset-0" onClick={() => setShowCompareSelector(false)} />
                             {/* Slide-up Sheet Panel */}
                             <div 
                               className="relative w-full md:max-w-lg md:mx-auto bg-[#F9F9F9] dark:bg-[#12161C] rounded-t-[32px] shadow-[0_-12px_45px_rgba(0,0,0,0.35)] flex flex-col h-[85vh] sm:h-[82vh] animate-in slide-in-from-bottom duration-300 overflow-hidden z-10"
                               onClick={(e) => e.stopPropagation()}
                             >
                               <div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0" />
                               
                               <div className="flex flex-col h-full overflow-hidden">
                                  {/* Header */}
                                  <div className="flex items-center px-4 mb-2 relative shrink-0">
                                     <button onClick={() => {}} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300 opacity-0 pointer-events-none">
                                        <RotateCcw className="w-5 h-5" />
                                     </button>
                                     <div className="flex-1 text-center pr-11">
                                        <h3 className="font-bold text-[22px] text-gray-900 dark:text-white">Compare models</h3>
                                     </div>
                                  </div>
                                  <p className="text-[15px] text-gray-600 dark:text-gray-400 text-center mb-4 shrink-0">Select up to 5 models to compare side-by-side</p>

                                  <div className="flex-1 overflow-y-auto px-4 pb-28 custom-scrollbar relative">
                                    <div className="space-y-3">
                                      {ALL_MODELS.filter(m => m.group === 'engines').map(m => {
                                         const isSelected = compareSelectedModels.includes(m.id);
                                         return (
                                            <button
                                              key={m.id}
                                              onClick={() => {
                                                 if (isSelected) {
                                                    if (compareSelectedModels.length > 1) {
                                                       setCompareSelectedModels(prev => prev.filter(x => x !== m.id));
                                                    }
                                                 } else {
                                                    if (compareSelectedModels.length < 5) {
                                                       setCompareSelectedModels(prev => [...prev, m.id]);
                                                    }
                                                 }
                                              }}
                                              className="w-full flex items-center justify-between p-4 px-5 rounded-[24px] bg-white dark:bg-[#1E242C] shadow-sm transition-transform active:scale-[0.98]"
                                            >
                                              <div className="flex items-center gap-4">
                                                <div className="w-[28px] h-[28px] flex items-center justify-center shrink-0">
                                                  {m.renderIcon()}
                                                </div>
                                                <span className="font-medium text-[17px] text-gray-900 dark:text-white">{m.name}</span>
                                                {m.badge}
                                              </div>
                                              <div className="shrink-0">
                                                {isSelected ? (
                                                  <div className="w-[28px] h-[28px] rounded-full bg-[#34A853] text-white flex items-center justify-center shadow-sm">
                                                    <Check className="w-5 h-5 stroke-[3]" />
                                                  </div>
                                                ) : (
                                                  <div className="w-[28px] h-[28px] rounded-full border-[1.5px] border-gray-300 dark:border-gray-600" />
                                                )}
                                              </div>
                                            </button>
                                         );
                                      })}
                                    </div>
                                  </div>

                                  {/* Bottom Action Bar */}
                                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#F9F9F9] via-[#F9F9F9] to-transparent dark:from-[#12161C] dark:via-[#12161C] flex gap-3">
                                     <button 
                                        onClick={() => { setCompareMode(false); setShowCompareSelector(false); }}
                                        className="flex-1 py-4 bg-gray-200 dark:bg-[#1E242C] text-gray-800 dark:text-gray-200 rounded-[18px] font-semibold text-[16px] transition-transform active:scale-[0.98]"
                                     >
                                        Exit Compare
                                     </button>
                                     <button 
                                        onClick={() => setShowCompareSelector(false)}
                                        className="flex-1 py-4 bg-[#34A853] text-white rounded-[18px] font-semibold text-[16px] shadow-sm transition-transform active:scale-[0.98]"
                                     >
                                        Apply ({compareSelectedModels.length})
                                     </button>
                                  </div>
                               </div>
                             </div>
                          </div>
                       )}
                    </div>
                  ) : (
                  <>
                  {/* Model Selector Pill Button (Icon + Name + ⌵) */}
                  {!loading && (
                  <div className="relative animate-in fade-in zoom-in-95 duration-200">
                    <button
                      type="button"
                      onClick={() => setShowModelMenu(true)}
                      className="h-10 px-2 rounded-xl text-[15px] font-medium text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                    >
                      <div className="shrink-0 flex items-center justify-center">
                        {currentModelObj.renderIcon()}
                      </div>
                      <div className="flex items-center">
                        <span className="max-w-[140px] truncate">{currentModelObj.name}</span>
                        {currentModelObj.badge}
                      </div>
                      <ChevronDown className="w-4 h-4 opacity-60 ml-0.5" strokeWidth={2.5} />
                    </button>
                    {showModelMenu && (
                      <div className="fixed inset-0 z-[100] flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                        {/* Backdrop Dismiss */}
                        <div 
                          className="absolute inset-0" 
                          onClick={() => { setShowModelMenu(false); setShowProviderFilter(false); }} 
                        />

                        {/* Slide-up Sheet Panel */}
                        <div 
                          className="relative w-full md:max-w-lg md:mx-auto bg-[#F9F9F9] dark:bg-[#12161C] rounded-t-[32px] shadow-[0_-12px_45px_rgba(0,0,0,0.35)] flex flex-col h-[85vh] sm:h-[82vh] animate-in slide-in-from-bottom duration-300 overflow-hidden z-10"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {/* Pull / Drag Indicator Handle */}
                          <div className="w-[45px] h-[4px] bg-gray-300 dark:bg-gray-700 rounded-full mx-auto mt-3 mb-2 shrink-0" />

                          {!showProviderFilter ? (
                            <div className="flex flex-col h-full overflow-hidden">
                              {/* Main Choose Model Header */}
                              <div className="flex items-center px-4 mb-2 relative shrink-0">
                                <button onClick={() => {}} className="w-11 h-11 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center text-gray-700 dark:text-gray-300">
                                  <RotateCcw className="w-5 h-5" />
                                </button>
                                <div className="flex-1 text-center pr-11">
                                  <h3 className="font-bold text-[22px] text-gray-900 dark:text-white">Choose a model</h3>
                                </div>
                              </div>
                              <p className="text-[15px] text-gray-600 dark:text-gray-400 text-center mb-4 shrink-0">Select the AI model that best fits your task</p>

                              {/* Search & Filter Bar */}
                              <div className="flex items-center gap-3 px-4 mb-4 shrink-0">
                                <div className="relative flex-1">
                                  <Search className="w-[20px] h-[20px] absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                  <input 
                                    type="text" 
                                    value={modelSearchQuery}
                                    onChange={(e) => setModelSearchQuery(e.target.value)}
                                    placeholder="Search" 
                                    className="w-full pl-12 pr-4 py-3 bg-gray-100 dark:bg-[#1E242C] rounded-full border-none focus:outline-none text-gray-900 dark:text-white text-[16px]"
                                  />
                                </div>
                                <button 
                                  onClick={() => setShowProviderFilter(true)} 
                                  className="w-12 h-12 rounded-full border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1E242C] flex items-center justify-center shrink-0 transition-colors active:bg-gray-50"
                                >
                                  <Filter className="w-[22px] h-[22px] text-gray-500 dark:text-gray-400" strokeWidth={1.5} />
                                </button>
                              </div>

                              {/* Tabs (Popular, Latest, All) */}
                              <div className="flex items-center justify-center gap-2 mb-4 border-b border-gray-200 dark:border-gray-800 pb-5 px-4 shrink-0">
                                <button 
                                  onClick={() => setActiveModelTab('Popular')}
                                  className={`px-6 py-2 rounded-full font-semibold text-[15px] shadow-sm transition-colors ${activeModelTab === 'Popular' ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-black' : 'text-gray-500 dark:text-gray-400 font-medium hover:bg-gray-100 dark:hover:bg-gray-800/50'}`}
                                >
                                  Popular
                                </button>
                                <button 
                                  onClick={() => setActiveModelTab('Latest')}
                                  className={`px-6 py-2 rounded-full font-semibold text-[15px] shadow-sm transition-colors ${activeModelTab === 'Latest' ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-black' : 'text-gray-500 dark:text-gray-400 font-medium hover:bg-gray-100 dark:hover:bg-gray-800/50'}`}
                                >
                                  Latest
                                </button>
                                <button 
                                  onClick={() => setActiveModelTab('All')}
                                  className={`px-6 py-2 rounded-full font-semibold text-[15px] shadow-sm transition-colors ${activeModelTab === 'All' ? 'bg-[#1F1F1F] dark:bg-white text-white dark:text-black' : 'text-gray-500 dark:text-gray-400 font-medium hover:bg-gray-100 dark:hover:bg-gray-800/50'}`}
                                >
                                  All
                                </button>
                              </div>

                              {/* Model List */}
                              <div className="flex-1 overflow-y-auto px-4 pb-28 custom-scrollbar relative">
                                {/* Auto Mode Special Card */}
                                {(selectedProviderFilter === 'All' && !modelSearchQuery) && (
                                  <>
                                    <button 
                                      onClick={() => { setPreferredModel('auto'); setShowModelMenu(false); }}
                                      className="w-full flex items-center gap-4 p-5 rounded-[24px] bg-white dark:bg-[#1E242C] shadow-sm mb-4 transition-transform active:scale-[0.98]"
                                    >
                                      <Rocket className="w-8 h-8 text-gray-700 dark:text-gray-300" strokeWidth={1.5} />
                                      <div className="flex-1 text-left">
                                        <div className="flex items-center gap-1.5 text-[18px]">
                                          <span className="font-semibold text-gray-900 dark:text-white">Auto Mode</span>
                                          <span className="text-gray-500 dark:text-gray-400 font-normal">(Super Fiesta)</span>
                                        </div>
                                        <p className="text-[15px] text-gray-500 dark:text-gray-400 mt-0.5">picks the best model for your task</p>
                                      </div>
                                      <div className="shrink-0">
                                        {preferredModel === 'auto' ? (
                                          <div className="w-[28px] h-[28px] rounded-full bg-[#34A853] text-white flex items-center justify-center shadow-sm">
                                            <Check className="w-5 h-5 stroke-[3]" />
                                          </div>
                                        ) : (
                                          <div className="w-[28px] h-[28px] rounded-full border-[1.5px] border-gray-300 dark:border-gray-600" />
                                        )}
                                      </div>
                                    </button>
                                    
                                    <div className="flex items-center justify-center gap-4 mb-4">
                                      <div className="h-[1px] bg-gray-200 dark:bg-gray-800 flex-1"></div>
                                      <span className="text-[14px] text-gray-500 dark:text-gray-400 font-medium">or pick your own</span>
                                      <div className="h-[1px] bg-gray-200 dark:bg-gray-800 flex-1"></div>
                                    </div>
                                  </>
                                )}

                                {/* Individual Models */}
                                <div className="space-y-3">
                                  {filteredModels.filter(m => m.id !== 'auto').map((model) => {
                                    const isSelected = model.id === preferredModel;
                                    return (
                                      <button
                                        key={model.id}
                                        onClick={() => {
                                          if (model.disabled) return;
                                          setPreferredModel(model.id);
                                        }}
                                        disabled={model.disabled}
                                        className={`w-full flex items-center justify-between p-4 px-5 rounded-[24px] bg-white dark:bg-[#1E242C] shadow-sm transition-transform active:scale-[0.98] ${model.disabled ? 'opacity-50 grayscale' : ''}`}
                                      >
                                        <div className="flex items-center gap-4">
                                          <div className="w-[28px] h-[28px] flex items-center justify-center shrink-0">
                                            {model.renderIcon()}
                                          </div>
                                          <span className="font-medium text-[17px] text-gray-900 dark:text-white">{model.name}</span>
                                          {model.badge}
                                          {(!model.badge && POPULAR_IDS.includes(model.id)) && (
                                            <span className="flex items-center gap-0.5 px-1.5 py-[1px] rounded text-[9px] font-bold uppercase tracking-wider bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-sm shrink-0" title="Premium">
                                              <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5"><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                              PRO
                                            </span>
                                          )}
                                        </div>
                                        <div className="shrink-0 pl-3">
                                          {isSelected ? (
                                            <div className="w-[28px] h-[28px] rounded-full border-[2.5px] border-[#34A853] flex items-center justify-center shadow-sm">
                                              <div className="w-[14px] h-[14px] bg-[#34A853] rounded-full" />
                                            </div>
                                          ) : (
                                            <div className="w-[28px] h-[28px] rounded-full border-[2px] border-gray-900 dark:border-gray-400" />
                                          )}
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col h-full overflow-hidden">
                              {/* Provider Filter View */}
                              <div className="flex items-center px-4 mb-6 relative shrink-0">
                                <button onClick={() => { setSelectedProviderFilter('All'); setShowProviderFilter(false); setModelSearchQuery(''); }} className="absolute left-4 top-1/2 -translate-y-1/2 text-[17px] font-semibold text-gray-500 hover:text-gray-800 transition-colors">
                                  Clear
                                </button>
                                <div className="flex-1 text-center">
                                  <h3 className="font-bold text-[22px] text-gray-900 dark:text-white">Filter by provider</h3>
                                </div>
                              </div>

                              <div className="flex-1 overflow-y-auto px-4 pb-28 space-y-2 custom-scrollbar">
                                {PROVIDER_FILTERS.filter(f => f.id !== 'All').map(filter => {
                                  const count = ALL_MODELS.filter(m => m.provider === filter.id && m.id !== 'auto').length;
                                  if (count === 0) return null;
                                  
                                  const isSelected = selectedProviderFilter === filter.id;
                                  const providerModel = ALL_MODELS.find(m => m.provider === filter.id);

                                  return (
                                    <button 
                                      key={filter.id}
                                      onClick={() => setSelectedProviderFilter(filter.id)}
                                      className="w-full flex items-center justify-between py-3 px-3 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors active:scale-[0.98]"
                                    >
                                      <div className="flex items-center gap-4">
                                        <div className="w-[30px] h-[30px] flex items-center justify-center shrink-0">
                                          {providerModel ? providerModel.renderIcon() : null}
                                        </div>
                                        <span className="font-medium text-[19px] text-gray-900 dark:text-white">{filter.label}</span>
                                      </div>
                                      <div className="flex items-center gap-5 shrink-0">
                                        <span className="text-[18px] font-medium text-gray-400">{count}</span>
                                        <div className={`w-[28px] h-[28px] rounded-full flex items-center justify-center border-[2.5px] ${isSelected ? 'border-[#34A853]' : 'border-gray-400 dark:border-gray-500'}`}>
                                          {isSelected && <div className="w-[14px] h-[14px] bg-[#34A853] rounded-full" />}
                                        </div>
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* Sticky Bottom Apply Button */}
                          <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-[#F9F9F9] via-[#F9F9F9] dark:from-[#12161C] dark:via-[#12161C] to-transparent pt-12 pointer-events-none">
                            <button 
                              onClick={() => {
                                if (showProviderFilter) {
                                  setShowProviderFilter(false);
                                } else {
                                  setShowModelMenu(false);
                                  localStorageHelper.savePreferredModel(preferredModel);
                                }
                              }}
                              className="w-full py-4 bg-[#34A853] hover:bg-[#2c9147] text-white rounded-full font-bold text-[19px] shadow-md pointer-events-auto transition-transform active:scale-[0.98]"
                            >
                              {showProviderFilter ? 'Done' : 'Apply for this chat'}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  )}
                  

                </>
                  )}
                </div>
                
                {/* Right Controls: Magic Pencil + Mic + Send */}
                <div className="flex items-center gap-1 pr-1">
                  {/* Magic Pencil Prompt Optimizer Button - Appears whenever user has typed text */}
                  {input.trim().length > 0 && !loading && (
                    <button
                      type="button"
                      onClick={handleEnhancePrompt}
                      disabled={isEnhancingPrompt}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 relative cursor-pointer group active:scale-95 ${
                        isEnhancingPrompt
                          ? 'bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-300'
                          : promptEnhancedSuccess
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-gray-400 hover:text-purple-600 dark:text-gray-500 dark:hover:text-purple-300 hover:bg-purple-50/80 dark:hover:bg-purple-950/30'
                      }`}
                      title="Magic AI Prompt Enhancer (Optimize & Polish)"
                    >
                      {isEnhancingPrompt ? (
                        <div className="relative flex items-center justify-center">
                          <Pencil className="w-4 h-4 magic-pencil-active" />
                          <Sparkles className="w-2.5 h-2.5 text-amber-400 absolute -top-1.5 -right-1.5 animate-pulse" />
                        </div>
                      ) : promptEnhancedSuccess ? (
                        <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-in zoom-in" strokeWidth={2.5} />
                      ) : (
                        <div className="relative flex items-center justify-center">
                          <Pencil className="w-4 h-4 transition-transform group-hover:scale-110 group-hover:-rotate-12" strokeWidth={2} />
                          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-gradient-to-r from-purple-500 to-amber-400 opacity-90 group-hover:animate-ping" />
                        </div>
                      )}
                    </button>
                  )}
                  {loading ? (
                    <button
                      type="button"
                      onClick={handleStop}
                      className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-800 transition-colors cursor-pointer"
                      title="Stop generating"
                    >
                      <div className="w-3 h-3 bg-gray-900 rounded-sm" />
                    </button>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={toggleDictation}
                        disabled={isDictatingTranscribing}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                          isDictating
                            ? 'bg-red-500 text-white animate-pulse'
                            : isDictatingTranscribing 
                              ? 'text-gray-400 opacity-50 cursor-wait'
                              : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer'
                        }`}
                        title={isDictating ? 'Dictating... click to stop' : 'Dictate with Groq Whisper'}
                      >
                        {isDictatingTranscribing ? (
                          <Loader2 className="w-[20px] h-[20px] animate-spin" strokeWidth={2} />
                        ) : (
                          <Mic className="w-[20px] h-[20px]" strokeWidth={2} />
                        )}
                      </button>
                      
                      <button
                        type="button"
                        onClick={toggleMicListening}
                        className="w-10 h-10 rounded-full bg-blue-500 hover:bg-blue-600 flex items-center justify-center text-white transition-colors cursor-pointer ml-1"
                        title="Voice Chat Mode"
                      >
                        <AudioLines className="w-[20px] h-[20px]" strokeWidth={2.5} />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSend()}
                        disabled={!input.trim()}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform active:scale-95 ml-1 ${
                          input.trim() 
                            ? 'bg-[#EAE8E3] dark:bg-[#343D49] hover:bg-[#DCDAD5] dark:hover:bg-[#434F5D] text-gray-800 dark:text-gray-200 cursor-pointer scale-100 opacity-100' 
                            : 'bg-transparent text-transparent scale-75 opacity-0 pointer-events-none w-0 -ml-2'
                        }`}
                        title="Send message"
                        style={{ transition: 'all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
                      >
                        <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
                      </button>
                    </>
                  )}
                </div>

              </div>

            </div>

          </div>

      </main>

      {/* ChatGPT-Style Bottom Half Camera Sheet */}
      {showCamera && (
        <div 
          onClick={stopCamera}
          className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-[2px] flex flex-col justify-end p-0 sm:p-4 animate-in fade-in duration-200"
        >
          {/* Camera Viewfinder Card */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl mx-auto h-[60vh] min-h-[400px] max-h-[72vh] sm:h-[520px] relative overflow-hidden rounded-t-[36px] sm:rounded-[36px] bg-[#111] shadow-2xl animate-in slide-in-from-bottom duration-300 flex flex-col border border-white/10"
          >
            {/* Live Camera Video (fills 100% of the rounded card, no black letterboxing) */}
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-full object-cover" 
            />
            <canvas ref={canvasRef} className="hidden" />

            {/* Top Sheet Drag/Grab Bar */}
            <div className="absolute top-3 inset-x-0 flex justify-center pointer-events-none z-20">
              <div className="w-10 h-1.5 rounded-full bg-white/40 backdrop-blur-md" />
            </div>

            {/* Bottom Controls Bar floating directly over the video (100% ChatGPT Style) */}
            <div className="absolute bottom-0 inset-x-0 pb-8 pt-16 px-8 flex items-end justify-between bg-gradient-to-t from-black/70 via-black/25 to-transparent z-20">
              {/* Back / Close Button */}
              <button 
                onClick={stopCamera} 
                className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 active:scale-95 text-white flex items-center justify-center backdrop-blur-md transition-all shadow-lg cursor-pointer shrink-0"
                title="Close Camera"
                aria-label="Close Camera"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              {/* Shutter Capture Button */}
              <button 
                onClick={capturePhoto} 
                className="w-[76px] h-[76px] rounded-full bg-white border-[5px] border-white/40 active:scale-90 transition-transform shadow-2xl cursor-pointer flex items-center justify-center focus:outline-none shrink-0" 
                title="Take Photo"
                aria-label="Take Photo"
              >
                <div className="w-full h-full rounded-full border-2 border-black/10" />
              </button>

              {/* Right Side: Three Dots (⋮) or Expanded Vertical Options Menu (Flash, Flip, Close) */}
              <div className="relative flex flex-col items-center shrink-0">
                {showCameraMenu ? (
                  <div className="flex flex-col items-center gap-3 animate-in fade-in zoom-in-90 slide-in-from-bottom-3 duration-200">
                    {/* Option 1: Flash / Torch Toggle */}
                    <button
                      onClick={toggleFlash}
                      className={`w-12 h-12 rounded-full flex items-center justify-center backdrop-blur-md transition-all shadow-lg cursor-pointer active:scale-95 ${
                        flashOn 
                          ? 'bg-amber-400 text-black ring-2 ring-amber-300' 
                          : 'bg-black/50 hover:bg-black/70 text-white'
                      }`}
                      title={flashOn ? "Turn Flash Off" : "Turn Flash On"}
                      aria-label="Toggle Flash"
                    >
                      {flashOn ? <Zap className="w-5 h-5 fill-current" /> : <ZapOff className="w-5 h-5" />}
                    </button>

                    {/* Option 2: Flip / Switch Front & Back Camera */}
                    <button
                      onClick={toggleFacingMode}
                      className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 active:scale-95 text-white flex items-center justify-center backdrop-blur-md transition-all shadow-lg cursor-pointer"
                      title="Flip Camera"
                      aria-label="Flip Camera"
                    >
                      <RefreshCw className="w-5 h-5 transition-transform active:rotate-180 duration-300" />
                    </button>

                    {/* Option 3: Close Options Menu (returns to ⋮) */}
                    <button
                      onClick={() => setShowCameraMenu(false)}
                      className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 active:scale-95 text-white flex items-center justify-center backdrop-blur-md transition-all shadow-lg cursor-pointer"
                      title="Close Menu"
                      aria-label="Close Menu"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ) : (
                  /* Collapsed state: Three Dots (⋮) button */
                  <button 
                    onClick={() => setShowCameraMenu(true)} 
                    className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 active:scale-95 text-white flex items-center justify-center backdrop-blur-md transition-all shadow-lg cursor-pointer"
                    title="Camera Options"
                    aria-label="Camera Options"
                  >
                    <MoreVertical className="w-6 h-6" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      <SettingsModal
        theme={theme || 'Day'}
        onThemeChange={onThemeChange || (() => {})} 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        userProfile={userProfile}
        authUser={authUser}
        onSignInWithGoogle={async () => {
          try {
            await signInWithGoogle();
            showToast("Signed in with Google! Cloud database sync enabled.");
          } catch (e: any) {
            showToast("Google sign in cancelled or failed.");
          }
        }}
        onSignInWithGithub={async () => {
          try {
            await signInWithGithub();
            showToast("Signed in with GitHub! Cloud database sync enabled.");
          } catch (e: any) {
            showToast("GitHub sign in cancelled or failed.");
          }
        }}
        onSignInWithMicrosoft={async () => {
          try {
            await signInWithMicrosoft();
            showToast("Signed in with Microsoft! Cloud database sync enabled.");
          } catch (e: any) {
            showToast("Microsoft sign in cancelled or failed.");
          }
        }}
        onSignOut={async () => {
          try {
            await logOutFromGoogle();
            showToast("Signed out of account.");
          } catch (e: any) {
            showToast("Failed to sign out.");
          }
        }}
        onOpenAuthModal={() => setShowAuthModal(true)}
      />

      {/* In-App Authentication Modal (100% In-App, Zero Redirection) */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={(msg) => showToast(msg || "Signed in successfully!")}
      />

      {/* LuaLaTeX Academic PDF Export Pipeline Modal */}
      <LatexPdfExportModal
        isOpen={showLatexExportModal}
        onClose={() => {
          setShowLatexExportModal(false);
          setLatexExportContent(null);
        }}
        content={latexExportContent || ''}
        defaultTitle={latexExportTitle}
        theme={theme}
      />

      {/* All Links Bottom Sheet / Modal (Matches User Screenshots 2 & 3) */}
      {activeSourcesModalMsg && (
        <div 
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-xs animate-in fade-in duration-150 p-0 sm:p-4"
          onClick={() => setActiveSourcesModalMsg(null)}
        >
          <div 
            className="bg-white w-full sm:max-w-lg max-h-[85vh] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 pt-5 pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2.5">
                <SearchLogo className="w-5 h-5" />
                <h2 className="text-lg font-bold text-gray-900">All links</h2>
              </div>
              <button
                type="button"
                onClick={() => setActiveSourcesModalMsg(null)}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-500 hover:text-black transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs: References & Related results */}
            <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-gray-100">
              <button
                type="button"
                onClick={() => setSourcesTab('references')}
                className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  sourcesTab === 'references'
                    ? 'bg-[#1A1A1A] text-white shadow-sm'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <span>References</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                  sourcesTab === 'references' ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
                }`}>
                  {activeSourcesModalMsg.sources?.length || 0}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSourcesTab('related')}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  sourcesTab === 'related'
                    ? 'bg-[#1A1A1A] text-white shadow-sm'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                Related results
              </button>
            </div>

            {/* Links List */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 divide-y divide-gray-100">
              {(sourcesTab === 'references' 
                ? (activeSourcesModalMsg.sources || []) 
                : (activeSourcesModalMsg.sources?.slice(2) || activeSourcesModalMsg.sources || [])
              ).map((source, sIndex) => (
                <a
                  key={sIndex}
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="pt-3 first:pt-0 block group hover:bg-[#F9F9F8] p-3 -mx-3 rounded-2xl transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="w-5 h-5 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center overflow-hidden flex-shrink-0">
                      {(source.iconUrl || source.domain) ? (
                        <img
                          src={source.iconUrl || `https://www.google.com/s2/favicons?domain=${encodeURIComponent(source.domain)}&sz=64`}
                          alt=""
                          className="w-3.5 h-3.5 object-contain"
                          onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                        />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-gray-400" />
                      )}
                    </div>
                    <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">
                      {source.siteName || source.domain}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-gray-400 group-hover:text-gray-700 ml-auto flex-shrink-0" />
                  </div>

                  <h3 className="text-[13.5px] font-semibold text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
                    {source.title}
                  </h3>

                  {source.snippet && (
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                      {source.snippet}
                    </p>
                  )}

                  <p className="text-[11px] text-gray-400 mt-1.5 truncate">
                    {source.url}
                  </p>
                </a>
              ))}
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[11px] text-gray-500 font-medium">
                <SearchLogo className="w-3.5 h-3.5" />
                <span>Verified Google Live Search Grounding</span>
              </div>
              <button
                type="button"
                onClick={() => setActiveSourcesModalMsg(null)}
                className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 rounded-xl text-xs font-semibold text-gray-800 transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Lightbox Modal */}
      {activeImageLightbox && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in p-4"
          onClick={() => setActiveImageLightbox(null)}
        >
          <div 
            className="relative max-w-3xl w-full max-h-[90vh] bg-neutral-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 text-white">
              <p className="text-sm font-semibold truncate pr-4">{activeImageLightbox.title}</p>
              <button
                type="button"
                onClick={() => setActiveImageLightbox(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-hidden flex items-center justify-center p-4 bg-black/40">
              <img
                src={activeImageLightbox.url}
                alt={activeImageLightbox.title}
                className="max-h-[65vh] w-auto object-contain rounded-xl shadow-lg"
              />
            </div>
            <div className="p-4 bg-neutral-950 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-neutral-400">
                Source: {activeImageLightbox.sourceName || 'Web search'}
              </span>
              {activeImageLightbox.sourceUrl && (
                <a
                  href={activeImageLightbox.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white text-black text-xs font-semibold hover:bg-neutral-200 transition-colors"
                >
                  <span>Visit page</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Copilot-Style Voice Mode Overlay */}
      {showVoiceOverlay && (
        <div className="fixed inset-0 z-[100] bg-white/95 dark:bg-[#09090b]/95 backdrop-blur-md flex flex-col items-center justify-between animate-in fade-in duration-300">
          
          {/* ChatGPT style voice cloud overlay center */}
          <div className="flex-1 w-full flex flex-col justify-center items-center overflow-hidden">
            <div className="relative w-[300px] h-[300px] flex items-center justify-center transition-all duration-500">
              {/* Main outer glow/cloud */}
              <div 
                className={`absolute inset-0 rounded-full bg-gradient-to-tr from-[#8ab4f8] via-[#aecbfa] to-[#e8f0fe] dark:from-[#3b82f6] dark:via-[#60a5fa] dark:to-[#93c5fd] mix-blend-multiply dark:mix-blend-screen transition-all duration-700 ease-in-out ${isLiveListening ? 'scale-110 opacity-70 animate-[pulse_2s_ease-in-out_infinite]' : isSpeaking ? 'scale-125 opacity-100 animate-[spin_4s_linear_infinite]' : 'scale-90 opacity-40'}`}
                style={{ filter: 'blur(20px)' }}
              />
              {/* Inner core */}
              <div 
                className={`absolute inset-6 rounded-full bg-gradient-to-bl from-[#d2e3fc] to-[#ffffff] dark:from-[#2563eb] dark:to-[#60a5fa] opacity-90 transition-all duration-500 ease-in-out ${isLiveListening ? 'scale-105' : 'scale-95'}`}
                style={{ filter: 'blur(10px)' }}
              />
            </div>
          </div>

          {/* Bottom Pill (Copilot style) */}
          <div className="mb-12 bg-white dark:bg-[#161B22] border border-gray-200 dark:border-gray-800 rounded-full shadow-2xl p-2.5 flex items-center gap-8 relative">
            <button 
              onClick={() => {
                setShowVoiceOverlay(false);
                stopLiveListening();
                stopSpeaking();
              }}
              className="w-12 h-12 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-500 cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            
            <button
              onClick={() => {
                if (isLiveListening) {
                  stopLiveListening();
                  stopSpeaking();
                } else {
                  startLiveListening();
                }
              }}
              className={`w-[72px] h-[72px] rounded-full flex items-center justify-center transition-all shadow-md cursor-pointer ${isLiveListening ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 scale-105' : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
            >
              <Mic className={`w-8 h-8 ${isLiveListening ? 'animate-pulse' : ''}`} />
            </button>

            <button className="w-12 h-12 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-500 cursor-pointer">
              <Settings className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}


      <ActiveReminderBanner
        task={activeDueTask}
        onDismiss={() => {
          setActiveDueTask(null);
        }}
        onSnooze={(id, mins) => {
          snoozeTask(id, mins);
          setScheduledTasksList(loadScheduledTasks());
          setActiveDueTask(null);
        }}
        onComplete={(id) => {
          updateTaskStatus(id, 'completed', { triggeredAt: Date.now() });
          setScheduledTasksList(loadScheduledTasks());
          setActiveDueTask(null);
        }}
      />
    </div>
  );
}
