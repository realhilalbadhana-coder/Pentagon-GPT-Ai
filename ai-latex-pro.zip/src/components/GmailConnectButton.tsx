import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn, logout } from '../lib/auth';

export function GmailConnectButton() {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setNeedsAuth(false);
        setUser(user);
        setErrorMsg(null);
      },
      () => {
        setNeedsAuth(true);
        setUser(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleConnect = async () => {
    setIsLoggingIn(true);
    setErrorMsg(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setNeedsAuth(false);
        setUser(result.user);
      }
    } catch (err: any) {
      console.error('Login failed:', err);
      if (err.code === 'auth/popup-closed-by-user') {
        setErrorMsg('Login cancelled. Please do not close the popup.');
      } else {
        setErrorMsg('Failed to connect. Please try again.');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleDisconnect = async () => {
    await logout();
    setNeedsAuth(true);
    setUser(null);
  };

  if (isLoggingIn) {
    return <button disabled className="text-[13px] font-medium px-4 py-1.5 rounded-full bg-gray-100 text-gray-500">Connecting...</button>;
  }

  if (needsAuth || !user) {
    return (
      <div className="flex flex-col items-end gap-1">
        <button 
          onClick={handleConnect}
          className="text-[13px] font-medium px-4 py-1.5 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
        >
          Connect
        </button>
        {errorMsg && <span className="text-[10px] text-red-500 font-medium mr-1">{errorMsg}</span>}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <span className="text-[11px] text-green-600 font-medium px-2 border border-green-200 bg-green-50 rounded-md">Connected</span>
      <button 
        onClick={handleDisconnect}
        className="text-[13px] font-medium px-4 py-1.5 rounded-full border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors"
      >
        Disconnect
      </button>
    </div>
  );
}
