import React, { useState } from 'react';
import { X, Mail, Lock, User as UserIcon, ArrowRight, AlertCircle, CheckCircle2, RefreshCw } from 'lucide-react';
import { 
  signInWithGoogle,
  signInWithGithub, 
  signInWithMicrosoft, 
  signInWithEmailPassword, 
  signUpWithEmailPassword,
  sendResetPasswordEmail 
} from '../lib/firebase';
import { GoogleSignInButton } from './GoogleSignInButton';
import { User } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [tab, setTab] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loadingProvider, setLoadingProvider] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleOAuth = async (provider: 'google' | 'github' | 'microsoft') => {
    setErrorMessage(null);
    setLoadingProvider(provider);
    try {
      if (provider === 'google') await signInWithGoogle();
      if (provider === 'github') await signInWithGithub();
      if (provider === 'microsoft') await signInWithMicrosoft();
      
      const name = provider.charAt(0).toUpperCase() + provider.slice(1);
      onSuccess(`Signed in with ${name}! Cloud sync enabled.`);
      onClose();
    } catch (err: any) {
      if (err?.code === 'auth/account-exists-with-different-credential') {
        setErrorMessage('An account already exists with the same email. Please sign in using the original provider.');
      } else if (err?.code === 'auth/popup-blocked') {
        setErrorMessage('Popup was blocked by browser. Please allow popups or use Email sign in.');
      } else if (err?.code === 'auth/unauthorized-domain') {
        setErrorMessage('This domain is not authorized yet in Firebase Console. Please add it to Authorized Domains or sign in with Email.');
      } else if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
        setErrorMessage(err?.message || `Failed to sign in with ${provider}.`);
      }
    } finally {
      setLoadingProvider(null);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessInfo(null);

    if (!email.trim() || (!password && tab !== 'reset')) {
      setErrorMessage('Please fill in all required fields.');
      return;
    }

    setLoadingProvider('email');
    try {
      if (tab === 'signin') {
        await signInWithEmailPassword(email.trim(), password);
        onSuccess('Welcome back! Signed in successfully.');
        onClose();
      } else if (tab === 'signup') {
        if (password.length < 6) {
          setErrorMessage('Password must be at least 6 characters.');
          setLoadingProvider(null);
          return;
        }
        await signUpWithEmailPassword(email.trim(), password, displayName.trim() || undefined);
        onSuccess('Account created and signed in! Cloud sync active.');
        onClose();
      } else if (tab === 'reset') {
        await sendResetPasswordEmail(email.trim());
        setSuccessInfo('Password reset email sent! Check your inbox.');
      }
    } catch (err: any) {
      if (err?.code === 'auth/operation-not-allowed') {
        setErrorMessage('Email/Password provider is not yet enabled in Firebase Console. Please continue with Google Sign In.');
      } else if (err?.code === 'auth/user-not-found' || err?.code === 'auth/invalid-credential' || err?.code === 'auth/wrong-password') {
        setErrorMessage('Invalid email or password. If you signed up with Google, please continue with Google.');
      } else if (err?.code === 'auth/email-already-in-use') {
        setErrorMessage('An account with this email already exists. Try signing in.');
      } else if (err?.code === 'auth/invalid-email') {
        setErrorMessage('Please enter a valid email address.');
      } else if (err?.code === 'auth/weak-password') {
        setErrorMessage('Password should be at least 6 characters.');
      } else {
        setErrorMessage(err?.message || 'Authentication error. Please try again.');
      }
    } finally {
      setLoadingProvider(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-[#161B22] border border-gray-200 dark:border-gray-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-black dark:bg-white text-white dark:text-black flex items-center justify-center font-bold text-sm shadow-xs">
              P
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white leading-tight">
                {tab === 'signin' && 'Sign in to Pentagon'}
                {tab === 'signup' && 'Create your account'}
                {tab === 'reset' && 'Reset your password'}
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {tab === 'reset' 
                  ? 'Enter your email to receive recovery instructions' 
                  : 'Sync chats, LaTeX papers & projects securely'}
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          
          {/* Error Banner */}
          {errorMessage && (
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-600 dark:text-red-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Success Banner */}
          {successInfo && (
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-green-50 dark:bg-green-950/40 border border-green-200 dark:border-green-800/60 text-green-700 dark:text-green-400 text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successInfo}</span>
            </div>
          )}

          {/* Direct OAuth Providers (Google Identity Services Embed, GitHub, Microsoft) */}
          {tab !== 'reset' && (
            <div className="space-y-2">
              {/* Embedded Google Identity Services Button with Account Chooser */}
              <GoogleSignInButton
                onSuccess={(user: User) => {
                  onSuccess(`Signed in as ${user.displayName || user.email}! Cloud sync enabled.`);
                  onClose();
                }}
                onError={(err) => {
                  if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
                    setErrorMessage('Failed to sign in with Google.');
                  }
                }}
                text={tab === 'signup' ? 'signup_with' : 'signin_with'}
                size="large"
                theme="outline"
              />

              <div className="grid grid-cols-2 gap-2">
                {/* GitHub */}
                <button
                  type="button"
                  disabled={!!loadingProvider}
                  onClick={() => handleOAuth('github')}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800/80 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-100 text-xs font-medium shadow-2xs transition-all cursor-pointer disabled:opacity-60"
                >
                  <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                    <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/>
                  </svg>
                  <span className="truncate">{loadingProvider === 'github' ? 'Connecting...' : 'GitHub'}</span>
                </button>

                {/* Microsoft */}
                <button
                  type="button"
                  disabled={!!loadingProvider}
                  onClick={() => handleOAuth('microsoft')}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800/80 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-100 text-xs font-medium shadow-2xs transition-all cursor-pointer disabled:opacity-60"
                >
                  <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 23 23">
                    <path fill="#f35325" d="M1 1h10v10H1z"/>
                    <path fill="#81bc06" d="M12 1h10v10H12z"/>
                    <path fill="#05a6f0" d="M1 12h10v10H1z"/>
                    <path fill="#ffba08" d="M12 12h10v10H12z"/>
                  </svg>
                  <span className="truncate">{loadingProvider === 'microsoft' ? 'Connecting...' : 'Microsoft'}</span>
                </button>
              </div>

              {/* Divider */}
              <div className="relative py-2 flex items-center justify-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200 dark:border-gray-700/80" />
                </div>
                <span className="relative px-3 bg-white dark:bg-[#161B22] text-[11px] text-gray-400 uppercase tracking-wider font-medium">
                  Or continue with Email
                </span>
              </div>
            </div>
          )}

          {/* Email / Password Form (100% In-App, Zero Redirection) */}
          <form onSubmit={handleEmailAuth} className="space-y-3">
            {tab === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-xs focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-all"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Email address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-xs focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-all"
                />
              </div>
            </div>

            {tab !== 'reset' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">
                    Password
                  </label>
                  {tab === 'signin' && (
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMessage(null);
                        setSuccessInfo(null);
                        setTab('reset');
                      }}
                      className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder={tab === 'signup' ? 'Min 6 characters' : 'Enter your password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-xs focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-all"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={!!loadingProvider}
              className="w-full py-3 px-4 rounded-xl bg-[#1F1F1F] dark:bg-white text-white dark:text-black font-semibold text-xs hover:bg-black dark:hover:bg-gray-100 disabled:opacity-60 transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer mt-2"
            >
              {loadingProvider === 'email' ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>
                    {tab === 'signin' && 'Sign in with Email'}
                    {tab === 'signup' && 'Create Account'}
                    {tab === 'reset' && 'Send Password Reset Link'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Toggle Tab Footer */}
          <div className="pt-2 text-center text-xs text-gray-500 dark:text-gray-400 border-t border-gray-100 dark:border-gray-800">
            {tab === 'signin' && (
              <p>
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setSuccessInfo(null);
                    setTab('signup');
                  }}
                  className="font-semibold text-gray-900 dark:text-white hover:underline cursor-pointer"
                >
                  Sign up
                </button>
              </p>
            )}

            {tab === 'signup' && (
              <p>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setSuccessInfo(null);
                    setTab('signin');
                  }}
                  className="font-semibold text-gray-900 dark:text-white hover:underline cursor-pointer"
                >
                  Sign in
                </button>
              </p>
            )}

            {tab === 'reset' && (
              <p>
                Remembered your password?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setSuccessInfo(null);
                    setTab('signin');
                  }}
                  className="font-semibold text-gray-900 dark:text-white hover:underline cursor-pointer"
                >
                  Back to Sign in
                </button>
              </p>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
