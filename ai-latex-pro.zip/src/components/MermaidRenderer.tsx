import React, { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { Copy, Check, Download, ZoomIn, ZoomOut, RotateCcw, GitFork } from 'lucide-react';

interface MermaidRendererProps {
  chart: string;
  theme?: string;
}

// Clean markdown fences and normalize diagram text
function sanitizeMermaidText(input: string): string {
  if (!input) return '';
  let clean = input.trim();
  clean = clean.replace(/^```(?:mermaid)?\s*\n?/i, '');
  clean = clean.replace(/\n?```\s*$/i, '');
  return clean.trim();
}

function cleanupMermaidDomArtifacts(id?: string) {
  try {
    if (id) {
      const el = document.getElementById(id);
      if (el && el.parentNode === document.body) el.remove();
      const dEl = document.getElementById(`d${id}`);
      if (dEl && dEl.parentNode === document.body) dEl.remove();
    }
    const rogue = document.body.querySelectorAll(':scope > svg[id^="mermaid-"], :scope > svg[id^="dmermaid"], :scope > [id^="dmermaid-"], :scope > .error-icon');
    rogue.forEach(node => node.remove());
  } catch {}
}

export function MermaidRenderer({ chart, theme }: MermaidRendererProps) {
  const [svgContent, setSvgContent] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [copied, setCopied] = useState<boolean>(false);

  const isDark = theme === 'Night' || document.documentElement.classList.contains('dark');
  const cleanChart = sanitizeMermaidText(chart);

  useEffect(() => {
    let isMounted = true;
    const uniqueId = `mermaid-${Math.random().toString(36).substring(2, 9)}`;

    const renderChart = async () => {
      if (!cleanChart) return;

      try {
        mermaid.initialize({
          startOnLoad: false,
          suppressErrorRendering: true,
          theme: isDark ? 'dark' : 'neutral',
          securityLevel: 'loose',
          fontFamily: 'inherit',
          fontSize: 13,
          flowchart: { curve: 'basis', htmlLabels: true, padding: 16 }
        });

        // Safe render
        const { svg } = await mermaid.render(uniqueId, cleanChart);
        if (isMounted) {
          setError(null);
          setSvgContent(svg);
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err?.message || 'Diagram syntax is invalid or incomplete.');
        }
      } finally {
        cleanupMermaidDomArtifacts(uniqueId);
      }
    };

    const timer = setTimeout(renderChart, 100);
    return () => {
      isMounted = false;
      clearTimeout(timer);
      cleanupMermaidDomArtifacts(uniqueId);
    };
  }, [cleanChart, isDark]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(cleanChart);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSvg = () => {
    if (!svgContent) return;
    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'diagram.svg';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (error || !svgContent) {
    return (
      <div className={`my-3 p-4 rounded-xl border transition-all text-xs ${
        isDark ? 'bg-[#1A1D24] border-[#2A2E37] text-gray-300' : 'bg-[#F9F9F8] border-[#E8E7E3] text-gray-700'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="font-semibold flex items-center gap-1.5 text-indigo-500">
            <GitFork className="w-3.5 h-3.5" /> Mermaid Diagram
          </span>
          <button
            type="button"
            onClick={handleCopyCode}
            className="flex items-center gap-1 text-[11px] px-2 py-0.5 rounded border border-gray-300 dark:border-gray-700 hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
        </div>
        <pre className="font-mono text-[11.5px] overflow-x-auto p-2.5 rounded-lg bg-black/5 dark:bg-black/40 whitespace-pre-wrap leading-relaxed">
          {cleanChart}
        </pre>
      </div>
    );
  }

  return (
    <div className={`my-4 w-full rounded-2xl border transition-all overflow-hidden ${
      isDark 
        ? 'bg-[#15181E] border-[#262B35] shadow-lg shadow-black/20 text-gray-100' 
        : 'bg-white border-[#E8E7E3] shadow-xs text-gray-900'
    }`}>
      {/* Top Toolbar */}
      <div className={`flex items-center justify-between px-4 py-2.5 border-b text-xs select-none ${
        isDark ? 'bg-[#1A1D24] border-[#262B35]' : 'bg-[#FAFAFA] border-[#E8E7E3]'
      }`}>
        <div className="flex items-center gap-2">
          <span className="font-semibold text-gray-700 dark:text-gray-200 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-indigo-500 inline-block" />
            Diagram View
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setZoom(prev => Math.min(prev + 0.2, 2.5))}
            className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 transition-colors cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom(prev => Math.max(prev - 0.2, 0.5))}
            className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          {zoom !== 1 && (
            <button
              type="button"
              onClick={() => setZoom(1)}
              className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 transition-colors cursor-pointer"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
          <div className="w-px h-3.5 bg-gray-300 dark:bg-gray-700 mx-1" />
          <button
            type="button"
            onClick={handleDownloadSvg}
            className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 transition-colors cursor-pointer"
            title="Download SVG"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleCopyCode}
            className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 transition-colors cursor-pointer"
            title="Copy Mermaid Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* SVG Canvas */}
      <div 
        className="w-full overflow-auto p-6 flex items-center justify-center min-h-[180px] custom-scrollbar"
      >
        <div 
          style={{ transform: `scale(${zoom})`, transition: 'transform 0.15s ease-out', transformOrigin: 'center center' }}
          dangerouslySetInnerHTML={{ __html: svgContent }}
          className="flex justify-center max-w-full"
        />
      </div>
    </div>
  );
}

