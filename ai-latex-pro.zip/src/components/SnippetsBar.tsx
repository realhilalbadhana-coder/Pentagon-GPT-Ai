import React from 'react';
import { 
  Sigma, 
  Binary, 
  Table as TableIcon, 
  Image as ImageIcon, 
  FileText, 
  CheckCircle2, 
  BookOpen, 
  Sparkles,
  Subscript,
  Superscript,
  Code
} from 'lucide-react';

interface SnippetsBarProps {
  onInsertSnippet: (snippet: string) => void;
}

export const SnippetsBar: React.FC<SnippetsBarProps> = ({ onInsertSnippet }) => {
  const snippets = [
    {
      label: 'Equation',
      icon: <Sigma className="w-3.5 h-3.5 text-blue-400" />,
      code: `\\begin{equation}\n  \\mathcal{L}(\\theta) = \\frac{1}{N} \\sum_{i=1}^{N} \\| y_i - f(x_i; \\theta) \\|^2\n\\end{equation}\n`,
      category: 'math',
    },
    {
      label: 'Align',
      icon: <Sigma className="w-3.5 h-3.5 text-cyan-400" />,
      code: `\\begin{align}\n  \\nabla \\cdot \\mathbf{E} &= \\frac{\\rho}{\\varepsilon_0} \\\\\n  \\nabla \\times \\mathbf{B} &= \\mu_0 \\mathbf{J} + \\mu_0 \\varepsilon_0 \\frac{\\partial \\mathbf{E}}{\\partial t}\n\\end{align}\n`,
      category: 'math',
    },
    {
      label: 'Fraction',
      icon: <Subscript className="w-3.5 h-3.5 text-emerald-400" />,
      code: `\\frac{a}{b}`,
      category: 'math',
    },
    {
      label: 'Integral',
      icon: <Sigma className="w-3.5 h-3.5 text-amber-400" />,
      code: `\\int_{a}^{b} f(x) \\, dx`,
      category: 'math',
    },
    {
      label: 'Summation',
      icon: <Sigma className="w-3.5 h-3.5 text-purple-400" />,
      code: `\\sum_{i=1}^{n} x_i`,
      category: 'math',
    },
    {
      label: 'Matrix (2x2)',
      icon: <Binary className="w-3.5 h-3.5 text-indigo-400" />,
      code: `\\begin{pmatrix}\n  a_{11} & a_{12} \\\\\n  a_{21} & a_{22}\n\\end{pmatrix}`,
      category: 'math',
    },
    {
      label: 'Table (Booktabs)',
      icon: <TableIcon className="w-3.5 h-3.5 text-teal-400" />,
      code: `\\begin{table}[htbp]\n\\caption{Experimental Benchmark Comparison}\n\\centering\n\\begin{tabular}{lccc}\n\\toprule\n\\textbf{Method} & \\textbf{Accuracy (\\%)} & \\textbf{Latency (ms)} & \\textbf{Params (M)} \\\\\n\\midrule\nBaseline A & 84.2 & 12.5 & 45.1 \\\\\nBaseline B & 89.1 & 18.2 & 78.4 \\\\\n\\textbf{Ours} & \\textbf{94.7} & \\textbf{8.4} & \\textbf{32.0} \\\\\n\\bottomrule\n\\end{tabular}\n\\label{tab:comparison}\n\\end{table}\n`,
      category: 'structure',
    },
    {
      label: 'Figure',
      icon: <ImageIcon className="w-3.5 h-3.5 text-rose-400" />,
      code: `\\begin{figure}[htbp]\n\\centering\n% \\includegraphics[width=0.8\\linewidth]{figure.png}\n\\caption{Schematic diagram of the proposed neural operator architecture.}\n\\label{fig:architecture}\n\\end{figure}\n`,
      category: 'structure',
    },
    {
      label: 'Theorem',
      icon: <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />,
      code: `\\begin{theorem}[Global Convergence]\nUnder Lipschitz continuity with constant $L > 0$, the algorithm converges at rate $\\mathcal{O}(1/\\sqrt{T})$.\n\\end{theorem}\n`,
      category: 'structure',
    },
    {
      label: 'Proof',
      icon: <FileText className="w-3.5 h-3.5 text-sky-400" />,
      code: `\\begin{proof}\nBy applying Cauchy-Schwarz inequality to the inner product $\\langle u, v \\rangle$, we obtain the stated bound.\n\\end{proof}\n`,
      category: 'structure',
    },
    {
      label: 'Citation',
      icon: <BookOpen className="w-3.5 h-3.5 text-violet-400" />,
      code: `\\cite{author2025}`,
      category: 'structure',
    },
  ];

  const greekSymbols = [
    { label: 'α', code: '\\alpha' },
    { label: 'β', code: '\\beta' },
    { label: 'γ', code: '\\gamma' },
    { label: 'θ', code: '\\theta' },
    { label: 'λ', code: '\\lambda' },
    { label: 'μ', code: '\\mu' },
    { label: 'π', code: '\\pi' },
    { label: 'σ', code: '\\sigma' },
    { label: 'ω', code: '\\omega' },
    { label: 'Δ', code: '\\Delta' },
    { label: '∇', code: '\\nabla' },
    { label: '∞', code: '\\infty' },
    { label: '∂', code: '\\partial' },
    { label: '∈', code: '\\in' },
    { label: '≤', code: '\\le' },
    { label: '≥', code: '\\ge' },
    { label: '≈', code: '\\approx' },
    { label: '→', code: '\\to' },
    { label: 'ℝ', code: '\\mathbb{R}' },
    { label: '𝔼', code: '\\mathbb{E}' },
  ];

  return (
    <div className="bg-slate-900 border-b border-slate-800 px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto text-xs select-none">
      <div className="flex items-center gap-1 shrink-0 mr-2 border-r border-slate-700 pr-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Snippets:</span>
      </div>

      {/* Structural & Math Snippets */}
      <div className="flex items-center gap-1 shrink-0">
        {snippets.map((snip) => (
          <button
            key={snip.label}
            onClick={() => onInsertSnippet(snip.code)}
            className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 hover:border-slate-600 transition-colors whitespace-nowrap"
            title={`Insert ${snip.label}`}
          >
            {snip.icon}
            <span>{snip.label}</span>
          </button>
        ))}
      </div>

      <div className="h-4 w-px bg-slate-700 mx-1 shrink-0" />

      {/* Greek & Math Quick Symbols */}
      <div className="flex items-center gap-1 shrink-0">
        <span className="text-[11px] text-slate-500 font-serif mr-1">Symbols:</span>
        {greekSymbols.map((sym) => (
          <button
            key={sym.label}
            onClick={() => onInsertSnippet(`$${sym.code}$`)}
            className="px-1.5 py-0.5 min-w-[22px] bg-slate-800/80 hover:bg-slate-700 text-indigo-300 font-serif rounded border border-slate-700/80 hover:border-slate-600 transition-colors text-center"
            title={`Insert ${sym.code}`}
          >
            {sym.label}
          </button>
        ))}
      </div>
    </div>
  );
};
