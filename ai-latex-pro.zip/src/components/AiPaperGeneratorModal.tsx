import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  BookOpen, 
  Layers, 
  Sigma, 
  Users, 
  GraduationCap, 
  Send, 
  CheckCircle,
  AlertCircle,
  Lightbulb
} from 'lucide-react';
import { AiGenerationParams } from '../types';

interface AiPaperGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (params: AiGenerationParams) => Promise<void>;
  isGenerating: boolean;
}

export const AiPaperGeneratorModal: React.FC<AiPaperGeneratorModalProps> = ({
  isOpen,
  onClose,
  onGenerate,
  isGenerating,
}) => {
  const [topic, setTopic] = useState('');
  const [paperType, setPaperType] = useState('IEEE Conference');
  const [authors, setAuthors] = useState('Dr. Farooq Badana, Prof. Sarah Jenkins');
  const [institution, setInstitution] = useState('Department of Computer Science & AI, Stanford University');
  const [keywords, setKeywords] = useState('Deep Learning, LaTeX Typesetting, Scientific AI, Optimization');
  const [mathDensity, setMathDensity] = useState<'low' | 'medium' | 'high' | 'ultra'>('high');
  const [numSections, setNumSections] = useState<number>(5);
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickTopics = [
    'Deep Adaptive Neural Operators for Real-Time Navier-Stokes PDE Simulation',
    'Provable Convergence Bounds of Momentum SGD under Non-Convex Polyak-Lojasiewicz Geometry',
    'Quantum Coherent Control of Topological Majorana Zero Modes in Superconductor Nanowires',
    'Multi-Agent Reinforcement Learning with Latent Dynamics for Autonomous Drone Swarms',
    'Transformer-based Multi-Modal Foundation Models for Automated Medical Imaging Diagnosis',
    'Zero-Knowledge Succinct Non-Interactive Arguments of Knowledge (zk-SNARKs) in Distributed Ledgers',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter a research topic or paper title.');
      return;
    }
    setError(null);

    try {
      await onGenerate({
        topic: topic.trim(),
        paperType,
        authors: authors.trim(),
        institution: institution.trim(),
        keywords: keywords.trim(),
        mathDensity,
        numSections,
        additionalInstructions: additionalInstructions.trim(),
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to generate paper.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/30 border border-indigo-500/40 rounded-lg text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                Generate LaTeX Paper with Gemini AI
                <span className="text-[11px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                  gemini-3.7-flash
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Automatically generate complete, rigorous academic papers with equations, tables & citations.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs text-slate-300 flex-1">
          {error && (
            <div className="p-3 bg-red-950/60 border border-red-800/80 rounded-lg text-red-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Research Topic */}
          <div>
            <label className="block font-medium text-slate-200 mb-1.5 flex items-center justify-between">
              <span>Research Topic / Paper Title *</span>
              <span className="text-[11px] text-slate-400">Be as specific or general as desired</span>
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Physics-Informed Neural Networks for High Reynolds Number Flow..."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              required
            />

            {/* Quick Topic Suggestions */}
            <div className="mt-2">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
                <Lightbulb className="w-3 h-3 text-amber-400" />
                Suggested topics:
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {quickTopics.map((qTopic, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setTopic(qTopic)}
                    className="text-[11px] text-left px-2 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded border border-slate-700/60 transition-colors"
                  >
                    {qTopic}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Grid of Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Paper Format Type */}
            <div>
              <label className="block font-medium text-slate-200 mb-1.5 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                Paper Format Style
              </label>
              <select
                value={paperType}
                onChange={(e) => setPaperType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="IEEE Conference">IEEE Conference (2-Column)</option>
                <option value="arXiv Pre-print">arXiv Pre-print (STEM / AMS-LaTeX)</option>
                <option value="ACM Journal">ACM Transactions Journal</option>
                <option value="Nature Style Report">Nature / Science Format</option>
                <option value="Master/PhD Thesis Chapter">University Thesis Chapter</option>
                <option value="Technical Lab Report">Mathematical Proof / Lab Report</option>
              </select>
            </div>

            {/* Math & Formula Density */}
            <div>
              <label className="block font-medium text-slate-200 mb-1.5 flex items-center gap-1.5">
                <Sigma className="w-3.5 h-3.5 text-emerald-400" />
                Mathematical Rigor & Equations
              </label>
              <select
                value={mathDensity}
                onChange={(e) => setMathDensity(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="low">Standard (Few equations, conceptual focus)</option>
                <option value="medium">Moderate (Key loss functions, metrics)</option>
                <option value="high">High (Deep formulations, aligned equations, proofs)</option>
                <option value="ultra">Ultra-Rigor (Lemmas, theorems, matrix systems, integrals)</option>
              </select>
            </div>

            {/* Authors */}
            <div>
              <label className="block font-medium text-slate-200 mb-1.5 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-400" />
                Authors
              </label>
              <input
                type="text"
                value={authors}
                onChange={(e) => setAuthors(e.target.value)}
                placeholder="e.g. Dr. Alex Vance, Prof. Elena Rostova"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Institution */}
            <div>
              <label className="block font-medium text-slate-200 mb-1.5 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
                Affiliation & Institution
              </label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                placeholder="e.g. Stanford AI Lab, Cambridge"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Keywords & Additional instructions */}
          <div className="space-y-3">
            <div>
              <label className="block font-medium text-slate-200 mb-1">
                Index Terms / Keywords
              </label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="e.g. Machine Learning, PDEs, Optimization, Neural Networks"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-200 mb-1">
                Additional Custom Requirements (Optional)
              </label>
              <textarea
                value={additionalInstructions}
                onChange={(e) => setAdditionalInstructions(e.target.value)}
                rows={2}
                placeholder="e.g., Include an algorithm pseudocode box for training loop; focus on comparison with FNO and PINNs; include 5 key references..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 resize-none"
              />
            </div>
          </div>

          {/* Footer Submit */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              Generates complete compilable LaTeX with preamble, sections & bibliography.
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isGenerating}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isGenerating}
                className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg font-medium shadow-lg shadow-indigo-900/50 transition-all"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Typesetting Paper...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate LaTeX Paper</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
