import React, { useState, useEffect } from 'react';
import { 
  X, 
  FileText, 
  Download, 
  Copy, 
  Check, 
  Sparkles, 
  Printer, 
  Code, 
  Sigma, 
  Table, 
  FileCode, 
  CheckCircle2, 
  Layers,
  ArrowDown,
  ZoomIn,
  ExternalLink,
  Eye
} from 'lucide-react';
import { 
  parseMarkdownToAst, 
  compileAstToLuaLatex, 
  executeLuaLatexPdfPipeline, 
  exportVectorPdfNative,
  openVectorPdfPreviewTab,
  generateVectorHtmlDocument,
  ContentAST 
} from '../utils/latexAstPipeline';
import { downloadLatexSourceFile } from '../utils/pdfExport';

interface LatexPdfExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: string;
  defaultTitle?: string;
  theme?: string;
}

export const LatexPdfExportModal: React.FC<LatexPdfExportModalProps> = ({
  isOpen,
  onClose,
  content,
  defaultTitle,
  theme
}) => {
  const [activeTab, setActiveTab] = useState<'pipeline' | 'preview' | 'latex' | 'ast'>('pipeline');
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [stepMessage, setStepMessage] = useState<string>('');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [ast, setAst] = useState<ContentAST | null>(null);
  const [latexSource, setLatexSource] = useState<string>('');
  const [previewHtml, setPreviewHtml] = useState<string>('');

  useEffect(() => {
    if (isOpen && content) {
      const parsed = parseMarkdownToAst(content);
      if (defaultTitle) parsed.title = defaultTitle;
      setAst(parsed);
      const generatedLatex = compileAstToLuaLatex(parsed);
      setLatexSource(generatedLatex);
      const generatedHtml = generateVectorHtmlDocument(parsed, { showInteractiveBar: false });
      setPreviewHtml(generatedHtml);
      setCurrentStep(0);
      setStepMessage('');
      setIsExporting(false);
    }
  }, [isOpen, content, defaultTitle]);

  if (!isOpen || !ast) return null;

  const handleStartPdfPipeline = async () => {
    try {
      setIsExporting(true);
      await executeLuaLatexPdfPipeline(
        content,
        ast.title,
        (step, msg) => {
          setCurrentStep(step);
          setStepMessage(msg);
        }
      );
      setCurrentStep(5);
      setStepMessage('Vector PDF Engine opened! Select "Save as PDF" for infinite zoom sharpness & selectable text.');
    } catch (err) {
      console.error('Pipeline error:', err);
      setStepMessage('Export initiated.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleTrueVectorPdf = async () => {
    try {
      await exportVectorPdfNative(content, ast.title);
    } catch (e) {
      console.error('Failed vector export', e);
    }
  };

  const handleOpenPreviewTab = () => {
    openVectorPdfPreviewTab(content, ast.title);
  };

  const handleCopyLatex = async () => {
    try {
      await navigator.clipboard.writeText(latexSource);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  const isDark = theme === 'Dark' || theme === 'Midnight' || theme === 'Matrix' || theme === 'Cyberpunk';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className={`w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border ${
        isDark ? 'bg-[#161B22] border-gray-700 text-gray-100' : 'bg-white border-[#EDECE8] text-gray-900'
      }`}>
        
        {/* Header */}
        <div className={`px-6 py-4 flex items-center justify-between border-b ${
          isDark ? 'border-gray-800 bg-[#0D1117]' : 'border-gray-100 bg-[#F9F9F8]'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold">LuaLaTeX Vector PDF Engine</h3>
                <span className="text-[10px] font-mono uppercase bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-semibold">
                  100% Selectable Text & Vector Math
                </span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                True Vector Glyphs &bull; Smart Academic Pagination &bull; No Blur at 5000% Zoom
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-200/60 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className={`flex border-b px-6 gap-6 text-xs font-semibold overflow-x-auto ${
          isDark ? 'border-gray-800 bg-[#161B22]' : 'border-gray-100 bg-white'
        }`}>
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${
              activeTab === 'pipeline'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>AST Pipeline & Vector Export</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${
              activeTab === 'preview'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>Live A4 Page Preview</span>
          </button>

          <button
            onClick={() => setActiveTab('latex')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${
              activeTab === 'latex'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>LuaLaTeX Source (.tex)</span>
          </button>

          <button
            onClick={() => setActiveTab('ast')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${
              activeTab === 'ast'
                ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-gray-500 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>Parsed AST Metrics</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 1: PIPELINE & EXPORT */}
          {activeTab === 'pipeline' && (
            <div className="space-y-6">
              
              {/* Features Pill Box */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <ZoomIn className="w-4 h-4" />
                  </div>
                  <div className="text-xs">
                    <div className="font-bold text-emerald-800 dark:text-emerald-300">100% Selectable Text & Formulas</div>
                    <div className="text-emerald-700 dark:text-emerald-400 text-[11px] mt-0.5">
                      No raster images/screenshots. Every Greek symbol, variable, integral, and word is selectable and copyable in your PDF reader.
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/50 dark:bg-indigo-950/20 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="text-xs">
                    <div className="font-bold text-indigo-800 dark:text-indigo-300">Smart Academic Page Breaks</div>
                    <div className="text-indigo-700 dark:text-indigo-400 text-[11px] mt-0.5">
                      Formulas and equations never cut in half. Tables repeat headers cleanly. Headings never sit alone at the bottom of a page.
                    </div>
                  </div>
                </div>
              </div>

              {/* Architecture Flowchart Card */}
              <div className={`p-4 rounded-xl border ${
                isDark ? 'bg-gray-900/60 border-gray-800' : 'bg-[#FAFAF9] border-[#EDECE8]'
              }`}>
                <div className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-3 flex items-center justify-between">
                  <span>SYSTEM ARCHITECTURE FLOW</span>
                  <span className="text-[11px] text-indigo-500 font-mono">AST-DRIVEN COMPILER</span>
                </div>

                <div className="flex flex-col items-center gap-2 text-xs">
                  {/* Step 1 */}
                  <div className={`w-full p-2.5 rounded-lg border text-center font-semibold transition-all ${
                    currentStep >= 1 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' 
                      : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}>
                    1. AI Output (Markdown & KaTeX LaTeX Formats)
                  </div>

                  <ArrowDown className="w-4 h-4 text-gray-400" />

                  {/* Step 2 */}
                  <div className={`w-full p-2.5 rounded-lg border text-center font-semibold transition-all ${
                    currentStep >= 2 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' 
                      : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}>
                    2. Markdown Parser (Extracts \( ... \), \[ ... \], tables & code)
                  </div>

                  <ArrowDown className="w-4 h-4 text-gray-400" />

                  {/* Step 3 */}
                  <div className="w-full p-3 rounded-lg border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/20 space-y-2">
                    <div className="text-center font-bold text-indigo-600 dark:text-indigo-400">
                      3. Content AST Structure & Node Matrix
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-blue-500" />
                        <span>Normal Text ➔ LaTeX</span>
                      </div>
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <Table className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Tables ➔ booktabs</span>
                      </div>
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <Sigma className="w-3.5 h-3.5 text-purple-500" />
                        <span>Math ➔ amsmath / MathML</span>
                      </div>
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <Code className="w-3.5 h-3.5 text-amber-500" />
                        <span>Code ➔ listings</span>
                      </div>
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <FileCode className="w-3.5 h-3.5 text-red-500" />
                        <span>Images ➔ graphicx</span>
                      </div>
                      <div className="p-2 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-teal-500" />
                        <span>Smart Break ➔ CSS Paged</span>
                      </div>
                    </div>
                  </div>

                  <ArrowDown className="w-4 h-4 text-gray-400" />

                  {/* Step 4 */}
                  <div className={`w-full p-2.5 rounded-lg border text-center font-semibold transition-all ${
                    currentStep >= 4 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' 
                      : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}>
                    4. Typesetting with Native Vector Typography & Embedded Fonts
                  </div>

                  <ArrowDown className="w-4 h-4 text-gray-400" />

                  {/* Step 5 */}
                  <div className={`w-full p-2.5 rounded-lg border text-center font-bold transition-all ${
                    currentStep === 5 
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400' 
                      : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}>
                    5. 100% Vector PDF (Selectable, Searchable & Infinite Zoom)
                  </div>
                </div>
              </div>

              {/* Progress feedback */}
              {stepMessage && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
                  <span>{stepMessage}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => downloadLatexSourceFile(content, ast.title)}
                    className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    <FileCode className="w-4 h-4 text-indigo-500" />
                    <span>Download .tex</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenPreviewTab}
                    className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-xs font-semibold cursor-pointer transition-colors"
                    title="Open standalone document view in a new tab"
                  >
                    <ExternalLink className="w-4 h-4 text-emerald-500" />
                    <span>Open in New Tab</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleTrueVectorPdf}
                  disabled={isExporting}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20 active:scale-98 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Printer className="w-4 h-4" />
                  <span>Save / Print as True Vector PDF</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE A4 PREVIEW */}
          {activeTab === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  Exact academic document rendering with smart page break boundaries & selectable math:
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleOpenPreviewTab}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-xs font-medium cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Full Page</span>
                  </button>
                  <button
                    onClick={handleTrueVectorPdf}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium cursor-pointer shadow-xs"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Save as PDF</span>
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-gray-300 dark:border-gray-700 bg-[#525659] p-4 flex justify-center overflow-auto max-h-[460px]">
                <div className="bg-white text-gray-900 shadow-2xl rounded-sm w-full max-w-[760px] min-h-[500px] overflow-hidden">
                  <iframe
                    title="A4 Vector PDF Preview"
                    srcDoc={previewHtml}
                    className="w-full min-h-[600px] border-0"
                    sandbox="allow-same-origin allow-scripts"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LATEX SOURCE CODE */}
          {activeTab === 'latex' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  Full compilable LuaLaTeX document code with headers, geometry & listing configurations.
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyLatex}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-xs font-medium cursor-pointer"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? 'Copied' : 'Copy Code'}</span>
                  </button>
                  <button
                    onClick={() => downloadLatexSourceFile(content, ast.title)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .tex</span>
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-[#0D1117] text-gray-200 p-4 font-mono text-xs overflow-x-auto max-h-[380px] leading-relaxed">
                <pre>{latexSource}</pre>
              </div>
            </div>
          )}

          {/* TAB 4: PARSED AST METRICS */}
          {activeTab === 'ast' && (
            <div className="space-y-4">
              <div className="text-xs text-gray-500 dark:text-gray-400">
                Detailed AST token count extracted by the Markdown Parser:
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-[#FAFAF9] dark:bg-gray-900 text-center">
                  <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">{ast.stats.headings}</div>
                  <div className="text-[11px] text-gray-500">Headings & Sections</div>
                </div>
                <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-[#FAFAF9] dark:bg-gray-900 text-center">
                  <div className="text-xl font-bold text-purple-600 dark:text-purple-400">{ast.stats.mathBlocks}</div>
                  <div className="text-[11px] text-gray-500">Math Blocks (amsmath)</div>
                </div>
                <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-[#FAFAF9] dark:bg-gray-900 text-center">
                  <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{ast.stats.codeBlocks}</div>
                  <div className="text-[11px] text-gray-500">Code Listings</div>
                </div>
                <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-[#FAFAF9] dark:bg-gray-900 text-center">
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{ast.stats.tables}</div>
                  <div className="text-[11px] text-gray-500">Formatted Tables</div>
                </div>
              </div>

              <div className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/40 text-xs space-y-2">
                <div className="font-semibold text-gray-700 dark:text-gray-300">Document Title Extracted:</div>
                <div className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold">{ast.title}</div>
                <div className="text-gray-500 text-[11px]">
                  Total Nodes in AST Tree: {ast.nodes.length} structural elements.
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
