import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Square, Sparkles, Volume2 } from 'lucide-react';

interface VoiceWaveVisualizerProps {
  isListening: boolean;
  transcript: string;
  volumeLevel: number; // 0 to 100
  onStop: () => void;
  onCancel: () => void;
  error?: string | null;
}

export const VoiceWaveVisualizer: React.FC<VoiceWaveVisualizerProps> = ({
  isListening,
  transcript,
  volumeLevel,
  onStop,
  onCancel,
  error,
}) => {
  // Generate 24 animated waveform bars
  const numBars = 20;

  return (
    <AnimatePresence>
      {isListening && (
        <motion.div
          initial={{ opacity: 0, y: 16, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.98 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="w-full mb-3 rounded-2xl bg-gradient-to-r from-[#0F172A] via-[#1E1B4B] to-[#0F172A] p-4 text-white shadow-2xl border border-indigo-500/30 relative overflow-hidden backdrop-blur-xl"
        >
          {/* Ambient Glow Orbs in Background */}
          <div className="absolute -top-12 -left-12 w-36 h-36 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
          <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-purple-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

          {/* Top Bar: Status Badge & Actions */}
          <div className="flex items-center justify-between relative z-10 mb-3">
            <div className="flex items-center gap-2">
              <div className="relative flex items-center justify-center">
                <span className="absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75 animate-ping" />
                <div className="relative w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
              </div>
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '4s' }} />
                AI Voice Recognition Active
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-lg transition-colors"
                title="Discard audio"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={onStop}
                className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-cyan-500 to-indigo-500 hover:from-cyan-400 hover:to-indigo-400 text-white text-xs font-semibold rounded-lg shadow-md hover:shadow-cyan-500/25 transition-all transform active:scale-95 cursor-pointer"
              >
                <Square className="w-3 h-3 fill-current" />
                Done Speaking
              </button>
            </div>
          </div>

          {/* Live Waveform Frequency Soundwave Graphic */}
          <div className="flex items-center justify-center gap-1.5 h-12 my-2 relative z-10 px-4">
            {Array.from({ length: numBars }).map((_, index) => {
              // Calculate dynamic height based on volumeLevel and mathematical harmonic frequencies
              const centerDist = Math.abs(index - numBars / 2) / (numBars / 2);
              const baseMultiplier = 1 - centerDist * 0.45;
              const dynamicVolume = Math.max(8, (volumeLevel / 100) * 36 * baseMultiplier);
              const variance = Math.sin((index * 0.7) + (Date.now() / 150)) * 6;
              const barHeight = Math.max(6, Math.min(44, dynamicVolume + variance));

              // Colors shifting from cyan to electric violet
              const colorClass = index % 3 === 0 
                ? 'bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.6)]' 
                : index % 3 === 1 
                ? 'bg-indigo-400 shadow-[0_0_10px_rgba(129,140,248,0.6)]' 
                : 'bg-violet-400 shadow-[0_0_10px_rgba(167,139,250,0.6)]';

              return (
                <motion.div
                  key={index}
                  animate={{
                    height: `${barHeight}px`,
                    opacity: isListening ? 0.9 + (volumeLevel / 500) : 0.4,
                  }}
                  transition={{
                    type: 'spring',
                    stiffness: 300,
                    damping: 18,
                  }}
                  className={`w-1 rounded-full ${colorClass} transition-all duration-75`}
                  style={{ minHeight: '6px' }}
                />
              );
            })}
          </div>

          {/* Live Transcript / Feedback Area */}
          <div className="relative z-10 mt-2 bg-slate-900/60 border border-slate-800 rounded-xl p-2.5 min-h-[44px] flex items-center justify-between">
            {transcript ? (
              <p className="text-sm font-medium text-slate-100 italic leading-relaxed line-clamp-2">
                &ldquo;{transcript}&rdquo;
              </p>
            ) : (
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span>Speak into your microphone in English, Urdu, Hindi, or any language...</span>
              </div>
            )}

            {error && (
              <span className="text-xs text-rose-400 font-medium ml-2 shrink-0">
                {error}
              </span>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
