import React, { useEffect, useRef, useState } from 'react';
import { signInWithGoogle, renderGoogleSignInButton } from '../lib/firebase';
import { User } from 'firebase/auth';

interface GoogleSignInButtonProps {
  onSuccess?: (user: User) => void;
  onError?: (err: any) => void;
  className?: string;
  theme?: 'outline' | 'filled_blue' | 'filled_black';
  size?: 'large' | 'medium' | 'small';
  text?: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
  width?: string;
}

export const GoogleSignInButton: React.FC<GoogleSignInButtonProps> = ({
  onSuccess,
  onError,
  className = '',
  theme = 'outline',
  size = 'large',
  text = 'continue_with',
  width
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [useFallback, setUseFallback] = useState(false);

  useEffect(() => {
    let rendered = false;
    
    // First try rendering embedded GSI
    if (containerRef.current) {
      rendered = renderGoogleSignInButton(containerRef.current, onSuccess, {
        theme,
        size,
        text: text as any,
        width
      });
    }

    // If it fails or window.google isn't present in time, fallback to our custom button
    if (!rendered) {
      setUseFallback(true);
      // Wait for GSI script and retry just in case it loads later
      const interval = setInterval(() => {
        if (containerRef.current && (window as any).google?.accounts?.id) {
          const success = renderGoogleSignInButton(containerRef.current, onSuccess, {
            theme,
            size,
            text: text as any,
            width
          });
          if (success) {
            setUseFallback(false);
            clearInterval(interval);
          }
        }
      }, 500);
      
      // Cleanup
      const timeout = setTimeout(() => clearInterval(interval), 5000);
      return () => {
        clearInterval(interval);
        clearTimeout(timeout);
      };
    }
  }, [onSuccess, theme, size, text, width]);

  const handleFallbackSignIn = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      const res = await signInWithGoogle();
      if (res.user && onSuccess) {
        onSuccess(res.user);
      }
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
        if (onError) {
          onError(err);
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getLabel = () => {
    if (isLoading) return 'Signing in with Google...';
    if (text === 'signin_with' || text === 'signin') return 'Sign in with Google';
    if (text === 'signup_with') return 'Sign up with Google';
    return 'Continue with Google';
  };

  return (
    <div className={`w-full relative ${className}`}>
      {/* The official button will mount inside this div */}
      <div 
        ref={containerRef} 
        className={`w-full flex justify-center ${useFallback ? 'hidden' : 'block'}`}
      />
      
      {/* Fallback Custom Button */}
      {useFallback && (
        <button
          type="button"
          onClick={handleFallbackSignIn}
          disabled={isLoading}
          className={`w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#21262D] hover:bg-gray-50 dark:hover:bg-[#30363D] text-gray-800 dark:text-gray-100 font-semibold text-xs shadow-2xs transition-all cursor-pointer active:scale-[0.99] disabled:opacity-60 ${
            size === 'small' ? 'py-1.5 text-[11px]' : size === 'medium' ? 'py-2 text-xs' : 'py-2.5 text-xs'
          }`}
        >
          {isLoading ? (
            <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin shrink-0" />
          ) : (
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
          )}
          <span className="truncate">{getLabel()}</span>
        </button>
      )}
    </div>
  );
};

