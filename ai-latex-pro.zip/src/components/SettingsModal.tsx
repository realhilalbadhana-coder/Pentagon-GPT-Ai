import React, { useState } from 'react';
import { X, ArrowLeft, Check, LogIn, LogOut, Mail } from 'lucide-react';
import { User } from 'firebase/auth';
import { UserProfile } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile | null;
  authUser: User | null;
  onSignInWithGoogle?: () => Promise<void>;
  onSignInWithGithub?: () => Promise<void>;
  onSignInWithMicrosoft?: () => Promise<void>;
  onSignOut?: () => Promise<void>;
  onOpenAuthModal?: () => void;
  theme: string;
  onThemeChange: (theme: string) => void;
}

type ViewState = 'main' | 'voice-language' | 'voice' | 'language' | 'memory' | 'theme';

export function SettingsModal({ 
  isOpen, 
  onClose, 
  userProfile, 
  authUser,
  onSignInWithGoogle,
  onSignInWithGithub,
  onSignInWithMicrosoft,
  onSignOut,
  onOpenAuthModal,
  theme, 
  onThemeChange 
}: SettingsModalProps) {
  const [currentView, setCurrentView] = useState<ViewState>('main');
  const [signingInProvider, setSigningInProvider] = useState<string | null>(null);

  // Selected states for preferences
  const [voiceLanguage, setVoiceLanguage] = useState('Auto-detect');
  const [voice, setVoice] = useState('Wave');
  const [language, setLanguage] = useState('English');
  const [personalization, setPersonalization] = useState(true);
  const [usageData, setUsageData] = useState(true);

  if (!isOpen) return null;

  const handleClose = () => {
    setCurrentView('main');
    onClose();
  };

  const handleProviderAuth = async (provider: 'google' | 'github') => {
    setSigningInProvider(provider);
    try {
      if (provider === 'google' && onSignInWithGoogle) await onSignInWithGoogle();
      if (provider === 'github' && onSignInWithGithub) await onSignInWithGithub();
    } finally {
      setSigningInProvider(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs sm:p-4 animate-in fade-in duration-150">
      <div className="bg-[#F3F3F3] dark:bg-[#161B22] w-full h-full sm:h-auto sm:max-h-[90vh] sm:max-w-md sm:rounded-2xl shadow-xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-2 sm:zoom-in-95 duration-200">
        
        {currentView === 'main' && (
          <>
            {/* Main Settings Header */}
            <div className="flex items-center justify-between p-4 relative shrink-0 border-b border-gray-200/50 dark:border-gray-800">
              <div className="w-8"></div>
              <h2 className="text-[12px] font-semibold text-gray-500 dark:text-gray-400 tracking-wider">SETTINGS</h2>
              <button 
                onClick={handleClose}
                className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Settings Content */}
            <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-hide space-y-4">
              {/* Profile Card */}
              <div className="px-1 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {authUser?.photoURL ? (
                    <img src={authUser.photoURL} alt="Avatar" className="w-11 h-11 rounded-full object-cover border border-gray-200 dark:border-gray-700" />
                  ) : (
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 text-white flex items-center justify-center text-sm font-bold shadow-xs">
                      {authUser?.displayName ? authUser.displayName.charAt(0).toUpperCase() : (userProfile?.name ? userProfile.name.charAt(0).toUpperCase() : 'U')}
                    </div>
                  )}
                  <div>
                    <h3 className="text-base font-semibold text-gray-900 dark:text-white">
                      {authUser?.displayName || userProfile?.name || 'Guest User'}
                    </h3>
                    <p className="text-[13px] text-gray-500 dark:text-gray-400">
                      {authUser?.email || (userProfile?.name ? 'Local Account' : 'Not signed in')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Settings list */}
              <div className="space-y-0 border-t border-b border-gray-200/60 dark:border-gray-800 py-1">
                <SettingItem label="Voice language" value={voiceLanguage.toUpperCase()} onClick={() => setCurrentView('voice-language')} />
                <SettingItem label="Voice" value={voice.toUpperCase()} onClick={() => setCurrentView('voice')} />
                <SettingItem label="Language" value="EN" onClick={() => setCurrentView('language')} />
                <SettingItem label="Theme" value={theme.toUpperCase()} onClick={() => setCurrentView('theme')} />
                <SettingItem label="Memory" onClick={() => setCurrentView('memory')} />
              </div>

              {/* Authentication Actions */}
              {authUser ? (
                <button 
                  onClick={onSignOut}
                  className="w-full rounded-2xl py-3 text-sm font-semibold transition-all flex items-center justify-center gap-2.5 shadow-xs cursor-pointer bg-white dark:bg-[#0D1117] border border-gray-300 dark:border-gray-700 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                >
                  <LogOut className="w-4 h-4" />
                  Sign out
                </button>
              ) : (
                <div className="space-y-2">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-gray-400 px-1">
                    Connect Account
                  </div>
                  
                  {/* Google */}
                  <button 
                    onClick={() => handleProviderAuth('google')}
                    disabled={!!signingInProvider}
                    className="w-full rounded-xl py-2.5 px-3.5 text-xs font-semibold transition-all flex items-center justify-between shadow-2xs cursor-pointer bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-100 border border-gray-200 dark:border-gray-700"
                  >
                    <div className="flex items-center gap-2.5">
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                      </svg>
                      <span>Continue with Google</span>
                    </div>
                    {signingInProvider === 'google' ? (
                      <span className="text-[11px] text-gray-400">Connecting...</span>
                    ) : (
                      <span className="text-[11px] text-blue-600 dark:text-blue-400 font-medium">Connect</span>
                    )}
                  </button>

                  {/* GitHub */}
                  <button 
                    onClick={() => handleProviderAuth('github')}
                    disabled={!!signingInProvider}
                    className="w-full rounded-xl py-2.5 px-3.5 text-xs font-semibold transition-all flex items-center justify-between shadow-2xs cursor-pointer bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-100 border border-gray-200 dark:border-gray-700"
                  >
                    <div className="flex items-center gap-2.5">
                      <svg className="w-4 h-4 fill-current text-gray-900 dark:text-white" viewBox="0 0 24 24">
                        <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/>
                      </svg>
                      <span>Continue with GitHub</span>
                    </div>
                    {signingInProvider === 'github' ? (
                      <span className="text-[11px] text-gray-400">Connecting...</span>
                    ) : (
                      <span className="text-[11px] text-gray-700 dark:text-gray-300 font-medium">Connect</span>
                    )}
                  </button>

                  {/* Email / Password Option (100% In-App) */}
                  {onOpenAuthModal && (
                    <button 
                      onClick={() => {
                        onClose();
                        onOpenAuthModal();
                      }}
                      className="w-full rounded-xl py-2.5 px-3.5 text-xs font-semibold transition-all flex items-center justify-between shadow-2xs cursor-pointer bg-gray-50 dark:bg-gray-800/50 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-800 dark:text-gray-100 border border-gray-200 dark:border-gray-700"
                    >
                      <div className="flex items-center gap-2.5">
                        <Mail className="w-4 h-4 text-gray-500" />
                        <span>Sign in with Email & Password</span>
                      </div>
                      <span className="text-[11px] text-gray-600 dark:text-gray-300 font-medium">Open</span>
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center justify-center gap-4 text-[13px] text-gray-500 dark:text-gray-400 pt-2">
                <a href="https://pentagon-flow.ai.studio/privacy" target="_blank" rel="noopener noreferrer" className="hover:text-gray-900 dark:hover:text-white transition-colors">Privacy</a>
                <a href="https://pentagon-flow.ai.studio/terms" target="_blank" rel="noopener noreferrer" className="hover:text-gray-900 dark:hover:text-white transition-colors">Terms</a>
                <a href="#" className="hover:text-gray-900 dark:hover:text-white transition-colors">FAQ</a>
              </div>
            </div>
          </>
        )}

        {currentView === 'voice-language' && (
          <SubView 
            title="VOICE LANGUAGE" 
            onBack={() => setCurrentView('main')}
          >
            <div className="flex flex-col pt-2">
              <button
                onClick={() => setVoiceLanguage('Auto-detect')}
                className="w-full flex items-center justify-between py-5 px-6 text-left hover:bg-black/5 dark:hover:bg-white/5 transition-colors border-b border-gray-200/60 dark:border-gray-800"
              >
                <span className="text-[15px] text-gray-900 dark:text-white">Auto-detect</span>
                {voiceLanguage === 'Auto-detect' && (
                  <div className="w-5 h-5 bg-[#1F1F1F] dark:bg-white rounded-full flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-white dark:text-black" strokeWidth={3} />
                  </div>
                )}
              </button>
              <div className="pt-2">
                <RadioList 
                  items={[
                    { id: 'Amharic', label: 'Amharic', hint: 'AM' },
                    { id: 'Arabic', label: 'Arabic', hint: 'AR' },
                    { id: 'Bulgarian', label: 'Bulgarian', hint: 'BG' },
                    { id: 'Bengali', label: 'Bengali', hint: 'BN' },
                    { id: 'Bosnian', label: 'Bosnian', hint: 'BS' },
                    { id: 'Catalan', label: 'Catalan', hint: 'CA' },
                    { id: 'Czech', label: 'Czech', hint: 'CS' },
                    { id: 'English', label: 'English', hint: 'EN' },
                    { id: 'Urdu', label: 'Urdu', hint: 'UR' },
                    { id: 'Hindi', label: 'Hindi', hint: 'HI' },
                  ]}
                  selected={voiceLanguage}
                  onChange={setVoiceLanguage}
                  hideLastBorder={true}
                />
              </div>
            </div>
          </SubView>
        )}

        {currentView === 'voice' && (
          <SubView 
            title="VOICE" 
            onBack={() => setCurrentView('main')}
          >
            <div className="px-4 py-4">
              <div className="grid grid-cols-2 gap-3 mb-4">
                {['Wave', 'Rain', 'Canyon', 'Grove', 'Meadow', 'Elm', 'Birch', 'Alder'].map((v) => (
                  <button
                    key={v}
                    onClick={() => setVoice(v)}
                    className={`py-4 rounded-xl text-[14px] font-medium transition-colors ${
                      voice === v 
                        ? 'bg-[#2D2A26] dark:bg-white text-white dark:text-black' 
                        : 'bg-[#E5E5E5] dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-[#DCDCDC]'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-gray-600 dark:text-gray-400 px-1">
                Your conversation will reset when you change voices
              </p>
            </div>
          </SubView>
        )}

        {currentView === 'memory' && (
          <SubView 
            title="MEMORY" 
            onBack={() => setCurrentView('main')}
          >
            <div className="flex flex-col pb-8">
              <div className="flex items-start justify-between py-5 px-5">
                <div className="flex flex-col mr-4">
                  <span className="text-[15px] font-medium text-gray-900 dark:text-white mb-1">Personalization and memory</span>
                  <p className="text-[12px] text-gray-500 dark:text-gray-400 leading-snug">
                    Your conversation history, facts and instructions you share will be saved and synchronized across your devices.
                  </p>
                </div>
                <button 
                  onClick={() => setPersonalization(!personalization)}
                  className={`w-11 h-6 rounded-full relative shrink-0 transition-colors duration-200 ${personalization ? 'bg-green-600' : 'bg-gray-200'}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform duration-200 ${personalization ? 'left-[22px]' : 'left-0.5'}`}></div>
                </button>
              </div>
              
              <div className="flex items-start justify-between py-5 px-5 border-b border-gray-200/60 dark:border-gray-800 mb-2">
                <div className="flex flex-col mr-4">
                  <span className="text-[15px] font-medium text-gray-900 dark:text-white mb-1">Usage data</span>
                  <p className="text-[12px] text-gray-500 dark:text-gray-400 leading-snug">
                    Enable secure synchronization with your cloud storage database.
                  </p>
                </div>
                <button 
                  onClick={() => setUsageData(!usageData)}
                  className={`w-11 h-6 rounded-full relative shrink-0 transition-colors duration-200 ${usageData ? 'bg-green-600' : 'bg-gray-200'}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform duration-200 ${usageData ? 'left-[22px]' : 'left-0.5'}`}></div>
                </button>
              </div>
            </div>
          </SubView>
        )}

        {currentView === 'theme' && (
          <SubView 
            title="THEME" 
            onBack={() => setCurrentView('main')}
          >
            <div className="px-4 py-4">
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => onThemeChange('Day')}
                  className={`flex flex-col items-center justify-center py-6 rounded-xl transition-colors ${
                    theme === 'Day' 
                      ? 'bg-[#2D2A26] dark:bg-white text-white dark:text-black' 
                      : 'bg-[#E5E5E5] dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-[#DCDCDC]'
                  }`}
                >
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-2">
                    <circle cx="12" cy="12" r="4"></circle>
                    <path d="M12 2v2"></path>
                    <path d="M12 20v2"></path>
                    <path d="m4.93 4.93 1.41 1.41"></path>
                    <path d="m17.66 17.66 1.41 1.41"></path>
                    <path d="M2 12h2"></path>
                    <path d="M20 12h2"></path>
                    <path d="m6.34 17.66-1.41 1.41"></path>
                    <path d="m19.07 4.93-1.41 1.41"></path>
                  </svg>
                  <span className="text-[14px] font-medium">Day</span>
                </button>
                <button
                  onClick={() => onThemeChange('Night')}
                  className={`flex flex-col items-center justify-center py-6 rounded-xl transition-colors ${
                    theme === 'Night' 
                      ? 'bg-[#2D2A26] dark:bg-white text-white dark:text-black' 
                      : 'bg-[#E5E5E5] dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-[#DCDCDC]'
                  }`}
                >
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-2">
                    <path d="M12 3a6 6 0 0 0 9 9 9 0 1 1-9-9Z"></path>
                  </svg>
                  <span className="text-[14px] font-medium">Night</span>
                </button>
              </div>
            </div>
          </SubView>
        )}

        {currentView === 'language' && (
          <SubView 
            title="LANGUAGE" 
            onBack={() => setCurrentView('main')}
          >
            <RadioList 
              items={[
                { id: 'Arabic', label: 'Arabic', hint: 'AR' },
                { id: 'Bengali', label: 'Bengali', hint: 'BN' },
                { id: 'English', label: 'English', hint: 'EN' },
                { id: 'French', label: 'French', hint: 'FR' },
                { id: 'German', label: 'German', hint: 'DE' },
                { id: 'Hindi', label: 'Hindi', hint: 'HI' },
                { id: 'Spanish', label: 'Spanish', hint: 'ES' },
                { id: 'Urdu', label: 'Urdu', hint: 'UR' },
              ]}
              selected={language}
              onChange={setLanguage}
            />
          </SubView>
        )}
      </div>
    </div>
  );
}

function SettingItem({ label, value, onClick }: { label: string; value?: string; onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center justify-between py-4 px-1 hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-left group cursor-pointer"
    >
      <span className="text-[15px] text-gray-800 dark:text-gray-200">{label}</span>
      {value && (
        <span className="text-[13px] font-medium text-gray-500 dark:text-gray-400 tracking-wider">
          {value}
        </span>
      )}
    </button>
  );
}

function SubView({ title, onBack, children }: { title: string; onBack: () => void; children: React.ReactNode }) {
  return (
    <div className="flex flex-col h-full bg-[#F3F3F3] dark:bg-[#161B22]">
      <div className="flex items-center p-4 border-b border-gray-200/50 dark:border-gray-800 shrink-0 relative">
        <button 
          onClick={onBack}
          className="w-8 h-8 flex items-center justify-center text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white transition-colors z-10 cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" strokeWidth={2} />
        </button>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <h2 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 tracking-wider uppercase">{title}</h2>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        {children}
      </div>
    </div>
  );
}

function RadioList({ 
  items, 
  selected, 
  onChange,
  hideLastBorder
}: { 
  items: { id: string; label: string; hint?: string }[]; 
  selected: string; 
  onChange: (id: string) => void;
  hideLastBorder?: boolean;
}) {
  return (
    <div className="flex flex-col">
      {items.map((item) => {
        const isSelected = selected === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className="w-full flex items-center justify-between py-4 px-6 text-left hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
          >
            <div className="flex items-baseline gap-3">
              <span className="text-[15px] text-gray-900 dark:text-gray-100">{item.label}</span>
              {item.hint && (
                <span className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">{item.hint}</span>
              )}
            </div>
            {isSelected && (
              <div className="w-5 h-5 bg-[#1F1F1F] dark:bg-white rounded-full flex items-center justify-center shrink-0">
                <Check className="w-3.5 h-3.5 text-white dark:text-black" strokeWidth={3} />
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}
