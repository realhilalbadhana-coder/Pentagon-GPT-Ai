import React, { useState, useMemo, useRef, Component, ErrorInfo, ReactNode } from 'react';
import ReactECharts from 'echarts-for-react';
import { Download, Table as TableIcon, BarChart3, Copy, Check, Sparkles, AlertCircle } from 'lucide-react';

interface MetricInfo {
  label: string;
  value: string | number;
  change?: string;
  isPositive?: boolean;
  color?: string;
}

interface ParsedChartData {
  title?: string;
  subtitle?: string;
  metric?: MetricInfo;
  echartsOption?: any;
  tableData?: { headers: string[]; rows: (string | number)[][] };
  isComplete: boolean;
  rawError?: string;
}

interface NativeChartRendererProps {
  code: string;
  theme?: string;
}

// Error Boundary specifically to catch any internal ECharts rendering exceptions
interface ErrorBoundaryProps {
  fallback: ReactNode;
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ChartErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(_: Error): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Silently capture ECharts provider/syntax errors
    console.warn('ECharts caught render error:', error?.message || error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

export function NativeChartRenderer({ code, theme }: NativeChartRendererProps) {
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('chart');
  const [copied, setCopied] = useState(false);
  const echartsRef = useRef<any>(null);

  const isDark = theme === 'Night' || (typeof document !== 'undefined' && document.documentElement.classList.contains('dark'));

  // Parse code into structured ECharts options and metadata with strict data validation
  const parsedData: ParsedChartData = useMemo(() => {
    try {
      // 1. Clean code string from potential markdown wrappers
      let cleanCode = (code || '').trim();
      if (cleanCode.startsWith('```')) {
        cleanCode = cleanCode.replace(/^```[a-zA-Z]*\n?/, '').replace(/```\s*$/, '').trim();
      }

      if (!cleanCode) {
        return { isComplete: false };
      }

      // Try parsing JSON directly
      let parsed: any;
      try {
        parsed = JSON.parse(cleanCode);
      } catch {
        // Relaxed JSON parsing for streamed or unquoted keys
        try {
          const relaxed = cleanCode
            .replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":')
            .replace(/'/g, '"');
          parsed = JSON.parse(relaxed);
        } catch {
          // If still invalid JSON (e.g. while actively streaming), mark as incomplete
          return { isComplete: false, rawError: 'Streaming chart data...' };
        }
      }

      if (!parsed || typeof parsed !== 'object') {
        return { isComplete: false, rawError: 'Invalid chart format.' };
      }

      let title = parsed.title;
      let subtitle = parsed.subtitle;
      let metric: MetricInfo | undefined = parsed.metric;

      // If title is an ECharts title object
      if (typeof title === 'object' && title !== null) {
        subtitle = title.subtext || subtitle;
        title = title.text;
      }

      let tableData: { headers: string[]; rows: (string | number)[][] } | undefined;
      let option: any = parsed.option || parsed.options || parsed;

      // High-level simplified data format: { type: 'line', data: [{ day: 'Mon', temp: 28 }, ...], xKey: 'day', yKey: 'temp' }
      if ((!option.series || !Array.isArray(option.series)) && parsed.data && Array.isArray(parsed.data) && parsed.data.length > 0) {
        const firstRow = parsed.data[0];
        if (typeof firstRow === 'object' && firstRow !== null) {
          const keys = Object.keys(firstRow);
          const xKey = parsed.xKey || keys[0] || 'label';
          const yKeys = parsed.yKeys || (keys.length > 1 ? [keys[1]] : ['value']);
          const chartType = parsed.type || 'line';

          const xData = parsed.data.map((d: any) => String(d[xKey] ?? ''));
          const seriesList = yKeys.map((k: string) => ({
            name: k,
            type: chartType,
            smooth: true,
            data: parsed.data.map((d: any) => {
              const val = d[k];
              return typeof val === 'number' ? val : Number(val) || 0;
            }),
            symbolSize: 8,
            lineStyle: { width: 3 }
          }));

          option = {
            xAxis: { type: 'category', data: xData },
            yAxis: { type: 'value' },
            series: seriesList
          };

          tableData = {
            headers: [xKey, ...yKeys],
            rows: parsed.data.map((d: any) => [String(d[xKey] ?? ''), ...yKeys.map((k: string) => d[k] ?? '-')])
          };
        }
      }

      // Validate series
      if (!option.series) {
        return { isComplete: false, rawError: 'Waiting for series data...' };
      }

      const rawSeriesList: any[] = Array.isArray(option.series)
        ? option.series.filter(Boolean)
        : [option.series].filter(Boolean);

      if (rawSeriesList.length === 0) {
        return { isComplete: false, rawError: 'No series found in chart configuration.' };
      }

      // Check if series have valid data arrays
      const validatedSeries: any[] = [];
      for (const s of rawSeriesList) {
        if (!s || typeof s !== 'object') continue;

        let sData: any[] = [];
        if (Array.isArray(s.data)) {
          sData = s.data.map((item: any) => {
            if (item === null || item === undefined) return 0;
            if (typeof item === 'object') {
              return { ...item, value: item.value !== undefined ? item.value : 0 };
            }
            if (typeof item === 'string') {
              const num = Number(item.replace(/[^0-9.-]+/g, ''));
              return !isNaN(num) && item.trim() !== '' ? num : item;
            }
            return item;
          });
        } else if (s.data && typeof s.data === 'object') {
          // Object map { Mon: 28, Tue: 30 }
          sData = Object.values(s.data);
        }

        // If sData is still empty or non-array during streaming, mark chart incomplete
        if (!Array.isArray(sData) || sData.length === 0) {
          return { isComplete: false, rawError: 'Loading chart data points...' };
        }

        validatedSeries.push({
          ...s,
          data: sData
        });
      }

      if (validatedSeries.length === 0) {
        return { isComplete: false, rawError: 'Valid series data not found.' };
      }

      // Validate & clean xAxis
      let cleanXAxis: any;
      if (Array.isArray(option.xAxis)) {
        cleanXAxis = option.xAxis.map((x: any) => ({
          ...x,
          type: x.type || 'category',
          data: Array.isArray(x.data) ? x.data.map((d: any) => String(d ?? '')) : []
        }));
      } else if (option.xAxis && typeof option.xAxis === 'object') {
        cleanXAxis = {
          ...option.xAxis,
          type: option.xAxis.type || 'category',
          data: Array.isArray(option.xAxis.data) ? option.xAxis.data.map((d: any) => String(d ?? '')) : []
        };
      } else {
        // Auto-generate categories from series length if xAxis is not specified
        const maxLen = Math.max(...validatedSeries.map((s: any) => s.data.length));
        cleanXAxis = {
          type: 'category',
          data: Array.from({ length: maxLen }, (_, i) => `Point ${i + 1}`)
        };
      }

      // Generate table data if not already generated
      if (!tableData) {
        const xValues: string[] = Array.isArray(cleanXAxis)
          ? cleanXAxis[0]?.data || []
          : cleanXAxis?.data || [];

        const headers = ['Category / Label', ...validatedSeries.map((s: any, i: number) => s.name || `Series ${i + 1}`)];
        if (xValues.length > 0) {
          const rows = xValues.map((xVal: string, idx: number) => {
            const row: (string | number)[] = [xVal];
            validatedSeries.forEach((s: any) => {
              const val = s.data[idx];
              row.push(typeof val === 'object' && val !== null ? val.value ?? '-' : (val ?? '-'));
            });
            return row;
          });
          tableData = { headers, rows };
        }
      }

      // Auto-derive highlight metric if not explicitly provided
      if (!metric && validatedSeries.length > 0) {
        const firstSeries = validatedSeries[0];
        if (firstSeries.data && firstSeries.data.length > 0) {
          const lastVal = firstSeries.data[firstSeries.data.length - 1];
          const rawVal = typeof lastVal === 'object' && lastVal !== null ? lastVal.value : lastVal;
          const seriesName = firstSeries.name || 'Current Value';

          if (rawVal !== undefined && rawVal !== null) {
            metric = {
              label: seriesName,
              value: typeof rawVal === 'number' ? `${rawVal}` : String(rawVal),
              color: '#F59E0B'
            };
          }
        }
      }

      // Apply ChatGPT-grade refined aesthetic styling to ECharts option
      const enhancedOption = {
        backgroundColor: 'transparent',
        animation: true,
        animationDuration: 800,
        animationEasing: 'cubicOut',
        tooltip: {
          trigger: 'axis',
          backgroundColor: isDark ? '#1E222B' : '#FFFFFF',
          borderColor: isDark ? '#333846' : '#E5E7EB',
          borderWidth: 1,
          padding: [10, 14],
          textStyle: {
            color: isDark ? '#F3F4F6' : '#111827',
            fontSize: 13,
            fontWeight: 500
          },
          extraCssText: 'box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1); border-radius: 12px;',
          axisPointer: {
            type: 'line',
            lineStyle: {
              color: isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(0, 0, 0, 0.2)',
              width: 1.5,
              type: 'dashed'
            }
          },
          ...(option.tooltip || {})
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '8%',
          top: '14%',
          containLabel: true,
          ...(option.grid || {})
        },
        xAxis: Array.isArray(cleanXAxis)
          ? cleanXAxis.map((x: any) => ({
              ...x,
              axisLine: { lineStyle: { color: isDark ? '#374151' : '#E5E7EB' } },
              axisLabel: {
                color: isDark ? '#9CA3AF' : '#6B7280',
                fontSize: 12,
                fontWeight: 500,
                margin: 12
              },
              splitLine: { show: false }
            }))
          : {
              ...cleanXAxis,
              axisLine: { lineStyle: { color: isDark ? '#374151' : '#E5E7EB' } },
              axisLabel: {
                color: isDark ? '#9CA3AF' : '#6B7280',
                fontSize: 12,
                fontWeight: 500,
                margin: 12
              },
              splitLine: { show: false }
            },
        yAxis: Array.isArray(option.yAxis)
          ? option.yAxis.map((y: any) => ({
              ...y,
              axisLine: { show: false },
              axisLabel: {
                color: isDark ? '#9CA3AF' : '#6B7280',
                fontSize: 12,
                fontWeight: 500
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.06)',
                  type: 'dashed'
                }
              }
            }))
          : {
              ...(option.yAxis || { type: 'value' }),
              axisLine: { show: false },
              axisLabel: {
                color: isDark ? '#9CA3AF' : '#6B7280',
                fontSize: 12,
                fontWeight: 500
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.06)',
                  type: 'dashed'
                }
              }
            },
        series: validatedSeries.map((s: any, idx: number) => {
          const isLine = s.type === 'line' || (!s.type && (cleanXAxis.type === 'category' || cleanXAxis[0]?.type === 'category'));
          const defaultColors = ['#F59E0B', '#3B82F6', '#10B981', '#EC4899', '#8B5CF6', '#06B6D4'];
          const color = s.color || defaultColors[idx % defaultColors.length];

          if (isLine) {
            return {
              ...s,
              type: 'line',
              smooth: s.smooth ?? 0.35,
              symbol: s.symbol ?? 'circle',
              symbolSize: s.symbolSize ?? 7,
              itemStyle: {
                color: color,
                borderColor: isDark ? '#15181E' : '#FFFFFF',
                borderWidth: 2,
                ...(s.itemStyle || {})
              },
              lineStyle: {
                width: 3.5,
                color: color,
                ...(s.lineStyle || {})
              },
              areaStyle: s.areaStyle !== undefined ? s.areaStyle : {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    { offset: 0, color: `${color}35` },
                    { offset: 1, color: `${color}00` }
                  ]
                }
              }
            };
          }

          if (s.type === 'bar') {
            return {
              ...s,
              itemStyle: {
                color: color,
                borderRadius: [6, 6, 0, 0],
                ...(s.itemStyle || {})
              }
            };
          }

          return s;
        })
      };

      return {
        title,
        subtitle,
        metric,
        echartsOption: enhancedOption,
        tableData,
        isComplete: true
      };
    } catch (err: any) {
      return {
        isComplete: false,
        rawError: err.message || 'Failed to process chart configuration.'
      };
    }
  }, [code, isDark]);

  const handleCopyData = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadImage = () => {
    if (echartsRef.current) {
      try {
        const echartInstance = echartsRef.current.getEchartsInstance();
        const base64 = echartInstance.getDataURL({
          type: 'png',
          pixelRatio: 2,
          backgroundColor: isDark ? '#1A1D24' : '#FFFFFF'
        });
        const link = document.createElement('a');
        link.download = `${parsedData.title || 'chart'}.png`;
        link.href = base64;
        link.click();
      } catch (err) {
        console.warn('Failed to export chart image:', err);
      }
    }
  };

  // If chart is still streaming or incomplete, render a subtle skeleton card
  if (!parsedData.isComplete || !parsedData.echartsOption) {
    return (
      <div className={`my-3 p-4 rounded-2xl border transition-all text-xs ${
        isDark 
          ? 'bg-[#15181E] border-[#262B35] text-gray-300' 
          : 'bg-[#FAF9F6] border-[#E8E7E3] text-gray-700'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
          <span className="font-semibold text-gray-800 dark:text-gray-200">
            {parsedData.rawError || 'Generating interactive visualization...'}
          </span>
        </div>
        <div className="w-full h-32 rounded-xl bg-gray-100 dark:bg-gray-800/40 animate-pulse flex items-center justify-center text-gray-400 text-xs font-mono">
          <span>Preparing chart canvas...</span>
        </div>
      </div>
    );
  }

  const fallbackTable = (
    <div className="p-4 text-xs text-gray-500">
      <div className="flex items-center gap-1.5 text-amber-600 mb-2">
        <AlertCircle className="w-4 h-4" />
        <span>Displaying raw data view:</span>
      </div>
      {parsedData.tableData && (
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-800 font-semibold">
              {parsedData.tableData.headers.map((h, i) => <th key={i} className="py-1 px-2">{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {parsedData.tableData.rows.map((r, i) => (
              <tr key={i} className="border-b border-gray-100 dark:border-gray-900">
                {r.map((c, j) => <td key={j} className="py-1 px-2">{String(c)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  return (
    <div className={`my-4 w-full rounded-2xl border transition-all overflow-hidden ${
      isDark 
        ? 'bg-[#15181E] border-[#262B35] shadow-lg shadow-black/20 text-gray-100' 
        : 'bg-white border-[#E8E7E3] shadow-xs text-gray-900'
    }`}>
      {/* Header Section (ChatGPT Exact Styling) */}
      <div className="p-4 sm:p-5 pb-2">
        <div className="flex items-start justify-between gap-3">
          <div>
            {parsedData.title && (
              <h3 className="text-base sm:text-lg font-bold tracking-tight text-gray-900 dark:text-white">
                {parsedData.title}
              </h3>
            )}
            {parsedData.subtitle && (
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-0.5 font-normal">
                {parsedData.subtitle}
              </p>
            )}
          </div>

          {/* Controls: Chart / Table Toggle & Download */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className={`flex rounded-lg p-0.5 border ${
              isDark ? 'bg-[#1E222B] border-[#2E3442]' : 'bg-[#F3F4F6] border-[#E5E7EB]'
            }`}>
              <button
                type="button"
                onClick={() => setViewMode('chart')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
                  viewMode === 'chart'
                    ? isDark ? 'bg-[#2E3442] text-white shadow-xs' : 'bg-white text-gray-900 shadow-xs'
                    : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                }`}
                title="Chart View"
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Chart</span>
              </button>
              {parsedData.tableData && (
                <button
                  type="button"
                  onClick={() => setViewMode('table')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
                    viewMode === 'table'
                      ? isDark ? 'bg-[#2E3442] text-white shadow-xs' : 'bg-white text-gray-900 shadow-xs'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  title="Table View"
                >
                  <TableIcon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Data</span>
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={handleDownloadImage}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                isDark 
                  ? 'border-[#2E3442] bg-[#1E222B] text-gray-300 hover:text-white hover:bg-[#2A3140]' 
                  : 'border-[#E5E7EB] bg-white text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              title="Download PNG image"
            >
              <Download className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={handleCopyData}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                isDark 
                  ? 'border-[#2E3442] bg-[#1E222B] text-gray-300 hover:text-white hover:bg-[#2A3140]' 
                  : 'border-[#E5E7EB] bg-white text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              title="Copy Chart JSON"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* ChatGPT Style Metric Indicator Card */}
        {parsedData.metric && (
          <div className="mt-3 inline-flex items-center gap-2.5">
            <div 
              className="w-1.5 h-7 rounded-full shrink-0" 
              style={{ backgroundColor: parsedData.metric.color || '#F59E0B' }} 
            />
            <div>
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 block leading-tight">
                {parsedData.metric.label}
              </span>
              <span className="text-lg font-bold text-gray-900 dark:text-white tracking-tight block leading-tight">
                {parsedData.metric.value}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="w-full px-2 pb-3">
        {viewMode === 'chart' ? (
          <div className="w-full h-[280px] sm:h-[340px] relative">
            <ChartErrorBoundary fallback={fallbackTable}>
              <ReactECharts
                ref={echartsRef}
                option={parsedData.echartsOption}
                style={{ height: '100%', width: '100%' }}
                opts={{ renderer: 'canvas' }}
                notMerge={true}
                lazyUpdate={true}
              />
            </ChartErrorBoundary>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[340px] px-2 py-1 custom-scrollbar">
            {parsedData.tableData ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className={`border-b ${isDark ? 'border-gray-800 bg-gray-800/40 text-gray-300' : 'border-gray-200 bg-gray-50 text-gray-700'}`}>
                    {parsedData.tableData.headers.map((h, i) => (
                      <th key={i} className="py-2.5 px-3 font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800/60">
                  {parsedData.tableData.rows.map((row, rIdx) => (
                    <tr key={rIdx} className={`hover:bg-gray-50/50 dark:hover:bg-gray-800/30 transition-colors ${
                      isDark ? 'text-gray-200' : 'text-gray-800'
                    }`}>
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="py-2 px-3 font-mono">{String(cell)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="text-center py-8 text-xs text-gray-400">No tabular data available for this chart.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
