import React, { useState, useEffect } from 'react';
import { Copy, Check, Code, Play, Maximize2, RotateCcw } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { NativeChartRenderer } from './NativeChartRenderer';
import { MermaidRenderer } from './MermaidRenderer';

interface CodeBlockWithRunnerProps {
  language: string;
  code: string;
  isClaude?: boolean;
  isTyping?: boolean;
  title?: string;
  theme?: string;
}

export function CodeBlockWithRunner({ language, code, theme }: CodeBlockWithRunnerProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');
  const [iframeKey, setIframeKey] = useState(0);
  const lang = (language || 'text').toLowerCase();

  // 1. Native ECharts / Chart visualization blocks
  const isChart = lang === 'echarts' || lang === 'chart' || lang === 'recharts' || lang === 'graph';
  if (isChart) {
    return <NativeChartRenderer code={code} theme={theme} />;
  }

  // 2. Native Mermaid diagram blocks
  const isMermaid = lang === 'mermaid';
  if (isMermaid) {
    return <MermaidRenderer chart={code} theme={theme} />;
  }

  // 3. If AI output JSON that looks like a chart specification
  if (lang === 'json' && (code.includes('"xAxis"') || code.includes('"series"') || code.includes('"metric"')) && code.includes('"title"')) {
    return <NativeChartRenderer code={code} theme={theme} />;
  }

  // 4. HTML/SVG Previewable Web Code Blocks
  const isPreviewable = lang === 'html' || lang === 'svg' || lang === 'xml';

  // Force default to code if not previewable
  useEffect(() => {
    if (!isPreviewable && activeTab === 'preview') {
      setActiveTab('code');
    }
  }, [isPreviewable, activeTab]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenFullscreen = () => {
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  return (
    <div className="my-3 w-full rounded-2xl overflow-hidden border border-[#E5E4E0] dark:border-[#2A2E37] bg-white dark:bg-[#1A1D24] shadow-xs text-sm">
      {/* Code Header Bar */}
      <div className="flex items-center justify-between px-3.5 py-2 bg-[#F8F7F5] dark:bg-[#12151B] border-b border-[#E5E4E0] dark:border-[#2A2E37] select-none text-xs">
        <div className="flex items-center gap-2">
          {isPreviewable && (
            <div className="flex bg-[#EDECE8] dark:bg-[#1E222B] rounded-lg p-0.5 border border-[#DFDED9] dark:border-[#2B2F36]">
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all ${
                  activeTab === 'preview' ? 'bg-white dark:bg-[#2B2F36] text-gray-900 dark:text-white shadow-xs' : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <Play className="w-3.5 h-3.5" /> Preview
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('code')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all ${
                  activeTab === 'code' ? 'bg-white dark:bg-[#2B2F36] text-gray-900 dark:text-white shadow-xs' : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <Code className="w-3.5 h-3.5" /> Code
              </button>
            </div>
          )}
          {!isPreviewable && (
            <span className="font-mono font-semibold lowercase tracking-wider text-gray-700 dark:text-gray-300 ml-1">
              {lang}
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-1.5">
          {isPreviewable && activeTab === 'preview' && (
            <>
              <button
                type="button"
                onClick={() => setIframeKey(k => k + 1)}
                className="p-1.5 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer"
                title="Reload Preview"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleOpenFullscreen}
                className="p-1.5 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer"
                title="Open in new window"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer active:scale-95"
            title="Copy code"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span className="text-emerald-500">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Content Area */}
      {activeTab === 'preview' && isPreviewable ? (
        <div className="w-full bg-white relative">
          <div className="w-full min-h-[350px] max-h-[600px] overflow-hidden flex flex-col relative group">
            <iframe
              key={iframeKey}
              title="Code Preview"
              srcDoc={code}
              sandbox="allow-scripts allow-forms allow-popups allow-modals"
              className="w-full flex-1 border-0 bg-white min-h-[360px]"
            />
          </div>
        </div>
      ) : (
        <div className="overflow-x-auto p-0 font-mono text-[13.5px] leading-relaxed custom-scrollbar bg-[#181B22]">
          <SyntaxHighlighter
            language={lang === 'js' ? 'javascript' : lang === 'ts' ? 'typescript' : lang === 'py' ? 'python' : lang}
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              padding: '1rem 1.25rem',
              background: 'transparent',
              fontSize: '13.5px',
              lineHeight: '1.65',
              fontFamily: '"Fira Code", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            }}
            wrapLongLines={false}
          >
            {code}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}

