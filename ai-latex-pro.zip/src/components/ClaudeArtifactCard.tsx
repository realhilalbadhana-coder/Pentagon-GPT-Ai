import React, { useState } from 'react';
import { Download, Code2, Play, Eye, FileCode, Check, ChevronRight, ExternalLink, FileText } from 'lucide-react';
import { downloadPdfFile } from '../utils/pdfExport';

interface ClaudeArtifactCardProps {
  title?: string;
  language: string;
  code: string;
  isClaude?: boolean;
  onOpenRunner?: (tab?: 'code' | 'preview') => void;
}

export function ClaudeArtifactCard({
  title,
  language,
  code,
  isClaude = true,
  onOpenRunner,
}: ClaudeArtifactCardProps) {
  const [downloaded, setDownloaded] = useState(false);
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const lang = (language || 'html').toLowerCase();
  const isRunnable = ['html', 'htm', 'xml', 'svg', 'javascript', 'js', 'typescript', 'ts', 'python', 'py', 'css'].includes(lang);

  const isExplicitPdf = code.includes('<!-- Type: PDF_Document -->');
  
  const isPdfDoc = isExplicitPdf || (
    lang === 'pdf' ||
    ((lang === 'markdown' || lang === 'md' || lang === 'txt') && (
      code.toLowerCase().includes('speech') ||
      code.toLowerCase().includes('essay') ||
      code.toLowerCase().includes('invoice') ||
      code.toLowerCase().includes('resume') ||
      code.toLowerCase().includes('report') ||
      code.toLowerCase().includes('curriculum vitae') ||
      code.toLowerCase().includes('cv') ||
      code.toLowerCase().includes('receipt') ||
      code.toLowerCase().includes('certificate') ||
      code.toLowerCase().includes('letter') ||
      code.toLowerCase().includes('summary') ||
      code.toLowerCase().includes('agreement')
    )) ||
    (title && title.toLowerCase().includes('pdf'))
  );

  // Dynamically extract intelligent title from actual code content
  const extractTitle = (): string => {
    if (title && title.trim()) return title.trim();

    // 1. Check HTML <title> tag
    const titleTagMatch = code.match(/<title[^>]*>(.*?)<\/title>/i);
    if (titleTagMatch && titleTagMatch[1].trim()) {
      return titleTagMatch[1].trim();
    }

    // 2. Check top 3 comment lines
    const lines = code.split('\n').slice(0, 5);
    for (const line of lines) {
      const commentMatch = line.match(/^(\/\/|#|\/\*|\*|<!--)\s*([A-Za-z0-9\s_-]{3,40})/);
      if (commentMatch && commentMatch[2].trim()) {
        const cleaned = commentMatch[2].replace(/-->|\*\//g, '').trim();
        if (cleaned && !cleaned.toLowerCase().includes('eslint') && !cleaned.toLowerCase().includes('typescript') && !cleaned.toLowerCase().includes('strict')) {
          return cleaned;
        }
      }
    }

    // 3. Check for component / function / class declaration
    const funcMatch = code.match(/export\s+(default\s+)?(function|class|const)\s+([A-Za-z0-9_]+)/);
    if (funcMatch && funcMatch[3]) {
      return funcMatch[3];
    }

    // 4. Check for <h1> tag
    const h1Match = code.match(/<h1[^>]*>(.*?)<\/h1>/i);
    if (h1Match && h1Match[1].trim() && h1Match[1].length < 40) {
      return h1Match[1].replace(/<[^>]+>/g, '').trim();
    }

    // Fallbacks based on language & type
    if (isPdfDoc) return 'Formatted Document';
    if (['html', 'htm'].includes(lang)) return 'Interactive Web Page';
    if (lang === 'svg') return 'Vector Graphic';
    if (['python', 'py'].includes(lang)) return 'Python Script';
    if (['typescript', 'ts'].includes(lang)) return 'TypeScript Module';
    if (['javascript', 'js'].includes(lang)) return 'JavaScript Application';
    if (lang === 'css') return 'Custom Stylesheet';
    if (lang === 'json') return 'Configuration Data';
    return 'Code Artifact';
  };

  const displayTitle = extractTitle();

  // Subtitle format: e.g. "Document · PDF", "Code · HTML", "Graphic · SVG"
  const subtitle = isPdfDoc
    ? 'Document · PDF'
    : lang === 'svg'
    ? 'Graphic · SVG'
    : ['html', 'htm'].includes(lang)
    ? 'Web · HTML'
    : `Code · ${lang.toUpperCase()}`;

  const handleDownloadDirectPdf = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setDownloadingPdf(true);
    const safeTitle = displayTitle.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 30);
    const fileName = `${safeTitle || 'document'}.pdf`;
    
    await downloadPdfFile(code, fileName);
    setDownloadingPdf(false);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isPdfDoc) {
      handleDownloadDirectPdf(e);
      return;
    }

    let extension = 'txt';
    if (['html', 'htm'].includes(lang)) extension = 'html';
    else if (['javascript', 'js'].includes(lang)) extension = 'js';
    else if (['typescript', 'ts'].includes(lang)) extension = 'ts';
    else if (['python', 'py'].includes(lang)) extension = 'py';
    else if (lang === 'css') extension = 'css';
    else if (lang === 'svg') extension = 'svg';
    else if (lang === 'json') extension = 'json';

    const safeTitle = displayTitle.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 30);
    const fileName = `${safeTitle || 'artifact'}.${extension}`;

    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);

    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2000);
  };

  return (
    <div 
      onClick={() => onOpenRunner?.(isRunnable ? 'preview' : 'code')}
      className={`my-3.5 w-full rounded-2xl border transition-all cursor-pointer select-none group ${
        isClaude 
          ? 'bg-[#FFFFFF] border-[#E5E3DC] hover:border-[#D1CEBF] shadow-[0_1px_3px_rgba(0,0,0,0.02)] hover:shadow-[0_2px_8px_rgba(0,0,0,0.04)]' 
          : 'bg-[#1E1E1E] border-gray-700/60 hover:border-gray-600 text-gray-200'
      }`}
    >
      <div className="flex items-center justify-between p-3 sm:p-3.5 gap-3">
        {/* Left Side: Icon + Title & Subtitle */}
        <div className="flex items-center gap-3.5 min-w-0">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
            isPdfDoc 
              ? 'border border-red-200 bg-red-50 text-red-600' 
              : isClaude 
              ? 'border border-[#EAE8E1] bg-[#FBFBFA] text-[#8A8781] group-hover:text-[#222120]' 
              : 'border border-gray-700 bg-[#252526] text-gray-400 group-hover:text-white'
          }`}>
            {isPdfDoc ? (
              <FileText className="w-5 h-5 text-red-500" strokeWidth={1.75} />
            ) : (
              <span className="font-mono text-xs font-semibold tracking-tighter">
                &lt;/&gt;
              </span>
            )}
          </div>

          <div className="flex flex-col min-w-0">
            <span className={`text-[14.5px] font-medium tracking-tight truncate ${
              isClaude ? 'text-[#222120]' : 'text-gray-100'
            }`}>
              {displayTitle}
            </span>
            <span className={`text-[12px] font-normal tracking-normal ${
              isPdfDoc
                ? 'text-red-600 font-medium'
                : isClaude
                ? 'text-[#8A8781]'
                : 'text-gray-400'
            }`}>
              {subtitle}
            </span>
          </div>
        </div>

        {/* Right Side: Contextual Action Buttons (Open/Preview & Download PDF / File) */}
        <div className="flex items-center gap-2 shrink-0">
          {isRunnable && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenRunner?.('preview');
              }}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[13px] font-medium transition-all shadow-xs ${
                isClaude
                  ? 'border border-[#E5E3DC] bg-[#FFFFFF] hover:bg-[#F7F6F2] text-[#C4432B] active:scale-98'
                  : 'border border-blue-600/40 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 active:scale-98'
              }`}
            >
              <Play className="w-3 h-3 fill-current" />
              Preview
            </button>
          )}

          <button
            type="button"
            onClick={isPdfDoc ? handleDownloadDirectPdf : handleDownload}
            disabled={downloadingPdf}
            className={`inline-flex items-center justify-center px-3.5 py-1.5 rounded-xl text-[13px] font-medium transition-all shadow-xs ${
              isPdfDoc
                ? 'border border-red-200 bg-red-600 hover:bg-red-700 text-white active:scale-98'
                : isClaude
                ? 'border border-[#E5E3DC] bg-[#FFFFFF] hover:bg-[#F7F6F2] text-[#222120] active:scale-98'
                : 'border border-gray-700 bg-[#2A2A2B] hover:bg-[#38383A] text-white active:scale-98'
            }`}
          >
            {downloadingPdf ? (
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                Generating...
              </span>
            ) : downloaded ? (
              <span className="flex items-center gap-1.5 text-white">
                <Check className="w-3.5 h-3.5" />
                Downloaded
              </span>
            ) : isPdfDoc ? (
              <span className="flex items-center gap-1.5">
                <Download className="w-3.5 h-3.5" />
                Download PDF
              </span>
            ) : (
              'Download'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
