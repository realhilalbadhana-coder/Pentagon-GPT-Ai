const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

content = content.replace(/export type ModelType =/g, "export type ModelType =\n  | 'mimo-v2.5'\n  | 'mimo-v2.5-pro'");

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
