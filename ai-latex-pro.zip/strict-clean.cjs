const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Replace remaining stray colors
content = content.replace(/bg-gray-50/g, 'bg-[#FFFFFF]');
content = content.replace(/bg-red-[1-9]00/g, 'bg-[#D13438]');
content = content.replace(/bg-red-50/g, 'bg-[#D13438]/10');
content = content.replace(/bg-emerald-50/g, 'bg-[#107C10]/10');
content = content.replace(/bg-green-[1-9]00/g, 'bg-[#107C10]');
content = content.replace(/bg-amber-[1-9]00/g, 'bg-[#323130]/10');
content = content.replace(/bg-purple-[1-9]00/g, 'bg-[#0078D4]/10');
content = content.replace(/bg-purple-50/g, 'bg-[#0078D4]/5');

content = content.replace(/text-purple-[1-9]00/g, 'text-[#0078D4]');
content = content.replace(/ring-amber-[1-9]00/g, 'ring-[#323130]/20');

// Fix `bg-[#FFFFFF] text-[#FFFFFF]` which can happen if my bubble replacement caught something else
// Let's verify the user bubble again
// Specifically, ensure that the send button has text-white.
content = content.replace(/bg-\[\#0078D4\] text-\[\#323130\]/g, 'bg-[#0078D4] text-[#FFFFFF]');

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
