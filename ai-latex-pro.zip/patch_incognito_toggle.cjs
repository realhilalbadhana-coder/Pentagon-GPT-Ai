const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const targetToggle = 'onClick={() => setIsTemporary(!isTemporary)}';
const replacementToggle = `onClick={() => {
                const nextState = !isTemporary;
                setIsTemporary(nextState);
                if (nextState) {
                  // If turned ON, remove the current empty session from history completely
                  setSessions(prev => {
                    const filtered = prev.filter(s => s.id !== currentSessionId);
                    localStorageHelper.saveSessions(filtered);
                    return filtered;
                  });
                } else {
                  // If turned OFF, create a fresh session to replace it
                  const fresh = localStorageHelper.createNewSession();
                  setSessions(prev => [fresh, ...prev]);
                  setCurrentSessionId(fresh.id);
                }
              }}`;

if (code.includes(targetToggle)) {
  code = code.replace(targetToggle, replacementToggle);
  
  // Also we can remove the sidebar filter we added earlier since we are now actually removing the session from state
  const sidebarTarget = '{[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).filter(s => !(isTemporary && s.id === currentSessionId)).sort((a, b) => {';
  const sidebarReplacement = '{[...sessions].filter(s => activeProjectId ? s.projectId === activeProjectId : true).sort((a, b) => {';
  code = code.replace(sidebarTarget, sidebarReplacement);
  
  fs.writeFileSync('src/components/AiAgentChat.tsx', code);
  console.log('Successfully patched incognito toggle logic.');
} else {
  console.log('Could not find incognito toggle.');
}
