const fs = require('fs');
let code = fs.readFileSync('src/index.css', 'utf8');

if (code.includes('padding: 3px;')) {
  code = code.replace('padding: 3px;', 'padding: 1.5px;');
  fs.writeFileSync('src/index.css', code);
  console.log('Successfully patched src/index.css');
} else {
  console.log('Could not find padding: 3px;');
}
