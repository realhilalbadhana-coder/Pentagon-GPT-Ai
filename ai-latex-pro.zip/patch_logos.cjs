const fs = require('fs');

let logosCode = fs.readFileSync('src/components/ModelLogos.tsx', 'utf8');

logosCode = logosCode.replace("gemini: '/logos/gemini.svg'", "gemini: 'https://ik.imagekit.io/j33n0ehll/gemini'");
logosCode = logosCode.replace("chatgpt: '/logos/chatgpt.svg'", "chatgpt: 'https://ik.imagekit.io/j33n0ehll/ChatGpt'");
logosCode = logosCode.replace("claude: '/logos/claude.svg'", "claude: 'https://ik.imagekit.io/j33n0ehll/Claude'");
logosCode = logosCode.replace("pentagon: '/logos/pentagon.svg'", "pentagon: 'https://ik.imagekit.io/qe76xsswb/file_000000001be48211939a1c0eec994ae5.png'");

fs.writeFileSync('src/components/ModelLogos.tsx', logosCode);

let chatCode = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');
chatCode = chatCode.replace("name: 'Claude 3 Opus',", "name: 'Fable 5',");

fs.writeFileSync('src/components/AiAgentChat.tsx', chatCode);

console.log('Patched logos and model name');
