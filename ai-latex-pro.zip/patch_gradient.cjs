const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Find the start of the Clean Input Surface
const targetDivStart = '          {/* Clean Input Surface */}\n          <div className={`relative rounded-[32px] sm:rounded-[36px] border p-3.5 sm:p-4 transition-all duration-300 ${theme === "Night" ? "bg-[#1E242C] border-[#30363D] shadow-[0_8px_32px_rgba(0,0,0,0.3)] focus-within:border-[#4B5563]" : "bg-white border-[#E5E5E5] shadow-[0_8px_30px_rgba(0,0,0,0.06)] focus-within:shadow-[0_8px_35px_rgba(0,0,0,0.08)] focus-within:border-[#D1D1D1]"}`}>';

if (code.includes(targetDivStart)) {
  const replacement = '          {/* Clean Input Surface */}\n          <div className={searchMode ? "google-gradient-box transition-all duration-300" : "transition-all duration-300"}>\n            <div className={`relative rounded-[32px] sm:rounded-[36px] border p-3.5 sm:p-4 transition-all duration-300 ${searchMode ? "border-transparent" : (theme === "Night" ? "border-[#30363D] focus-within:border-[#4B5563]" : "border-[#E5E5E5] focus-within:border-[#D1D1D1]")} ${theme === "Night" ? "bg-[#1E242C] shadow-[0_8px_32px_rgba(0,0,0,0.3)]" : "bg-white shadow-[0_8px_30px_rgba(0,0,0,0.06)] focus-within:shadow-[0_8px_35px_rgba(0,0,0,0.08)]"}`}>';
  code = code.replace(targetDivStart, replacement);
  
  // Now add the closing div
  const targetClosing = '                </div>\n              </div>\n            </div>\n          </div>\n      </main>';
  if (code.includes(targetClosing)) {
    const replacementClosing = '                </div>\n              </div>\n            </div>\n          </div>\n          </div>\n      </main>';
    code = code.replace(targetClosing, replacementClosing);
    fs.writeFileSync('src/components/AiAgentChat.tsx', code);
    console.log('Successfully patched AiAgentChat.tsx');
  } else {
    console.log('Could not find closing target');
  }
} else {
  console.log("Could not find the target div.");
}
