const fs = require('fs');
let content = fs.readFileSync('src/index.css', 'utf8');
content = content.replace(/background-color: #FAF9F6;/g, 'background-color: #FFFFFF;');
content = content.replace(/color: #1A1A1A;/g, 'color: #323130;');
fs.writeFileSync('src/index.css', content, 'utf8');
