const fs = require('fs');

let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Colors
const WHITE = '#FFFFFF';
const DARK_GRAY = '#323130';
const BLUE_PRIMARY = '#0078D4'; // Brand blue
const BLUE_GLASS = '#0078D415'; // Glass blue
const GREEN = '#107C10';
const RED = '#D13438';

// First, strip out dark: prefix everywhere. The user doesn't want atrangi colors, wants a unified light theme.
content = content.replace(/dark:[a-zA-Z0-9-\[\]\#\/]+/g, '');

// Replace specific backgrounds
// User user messages (blue)
content = content.replace(/bg-blue-600/g, `bg-[${BLUE_PRIMARY}]`);
content = content.replace(/bg-\[\#4285F4\]/g, `bg-[${BLUE_PRIMARY}]`);
content = content.replace(/bg-blue-50/g, `bg-[${BLUE_PRIMARY}]/10`);
content = content.replace(/bg-blue-100/g, `bg-[${BLUE_PRIMARY}]/15`);
content = content.replace(/bg-blue-500\/10/g, `bg-[${BLUE_PRIMARY}]/10`);
content = content.replace(/bg-blue-500\/20/g, `bg-[${BLUE_PRIMARY}]/20`);
content = content.replace(/bg-blue-950\/50/g, `bg-[${BLUE_PRIMARY}]/10`);

// Replace other generic backgrounds that should be white or off-white
content = content.replace(/bg-(?:\[#[a-fA-F0-9]+\]|gray-[1-4]00|neutral-[1-4]00|zinc-[1-4]00|slate-[1-4]00|stone-[1-4]00)/g, `bg-[${WHITE}]`);
content = content.replace(/bg-(?:gray|neutral|zinc|slate|stone)-[5-9]00/g, `bg-[${DARK_GRAY}]`);
content = content.replace(/bg-white/g, `bg-[${WHITE}]`);
content = content.replace(/bg-black/g, `bg-[${DARK_GRAY}]`);

// Replace Text Colors
content = content.replace(/text-(?:\[#[a-fA-F0-9]+\]|gray-[5-9]00|neutral-[5-9]00|zinc-[5-9]00|slate-[5-9]00|stone-[5-9]00|black)/g, `text-[${DARK_GRAY}]`);
content = content.replace(/text-(?:gray-[1-4]00|neutral-[1-4]00|zinc-[1-4]00|slate-[1-4]00|stone-[1-4]00)/g, `text-[${DARK_GRAY}]/70`);
content = content.replace(/text-white/g, `text-[${WHITE}]`); // keep text-white where background is dark (like user messages)
content = content.replace(/text-(?:blue|indigo|cyan|sky)-\d+/g, `text-[${BLUE_PRIMARY}]`);
content = content.replace(/text-(?:emerald|green|teal)-\d+/g, `text-[${GREEN}]`);
content = content.replace(/text-(?:red|rose|pink)-\d+/g, `text-[${RED}]`);
content = content.replace(/text-(?:amber|yellow|orange)-\d+/g, `text-[${DARK_GRAY}]`); 

// Replace Border Colors
content = content.replace(/border-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, `border-[${DARK_GRAY}]/15`);
content = content.replace(/border-(?:blue|indigo|cyan|sky)-\d+/g, `border-[${BLUE_PRIMARY}]/30`);
content = content.replace(/border-(?:emerald|green|teal)-\d+/g, `border-[${GREEN}]`);
content = content.replace(/border-(?:red|rose|pink)-\d+/g, `border-[${RED}]`);

// Rings
content = content.replace(/ring-(?:\[#[a-fA-F0-9]+\]|gray-\d+|neutral-\d+|zinc-\d+|slate-\d+|stone-\d+|white|black)/g, `ring-[${DARK_GRAY}]/15`);
content = content.replace(/ring-(?:blue|indigo|cyan|sky)-\d+/g, `ring-[${BLUE_PRIMARY}]/40`);

// Re-adjust some specifics
// We want hover states for buttons. If we made `hover:bg-[white]`, it won't be visible.
content = content.replace(/hover:bg-\[\#FFFFFF\]/g, `hover:bg-[${DARK_GRAY}]/5`);
content = content.replace(/hover:bg-\[\#323130\]/g, `hover:bg-[${DARK_GRAY}]/90`);

// Send Button is currently a mix, let's make sure primary buttons use Blue.
// Look for user message bubble (usually text-white and blue bg)
// Fix text-white on primary button:
content = content.replace(/text-\[\#323130\](?=.*bg-\[\#0078D4\])/g, `text-[#FFFFFF]`);

// Fix hover on blue background buttons
content = content.replace(/hover:bg-blue-700/g, `hover:bg-[${BLUE_PRIMARY}]/90`);

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
