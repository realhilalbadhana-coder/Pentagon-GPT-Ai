const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Add AudioLines to lucide imports
if (!code.includes('AudioLines')) {
  code = code.replace("} from 'lucide-react';", "  AudioLines,\n} from 'lucide-react';");
}

const oldButtons = `                    <>
                      <button
                        type="button"
                        onClick={toggleMicListening}
                        className={\`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer \${
                          isLiveListening
                            ? 'bg-red-500 text-white animate-pulse'
                            : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                        }\`}
                        title={isLiveListening ? 'Listening... click to stop' : 'Voice input'}
                      >
                        <Mic className="w-[20px] h-[20px]" strokeWidth={2} />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSend()}
                        disabled={!input.trim()}
                        className={\`w-10 h-10 rounded-full flex items-center justify-center transition-transform active:scale-95 \${
                          input.trim() 
                            ? 'bg-[#EAE8E3] dark:bg-[#343D49] hover:bg-[#DCDAD5] dark:hover:bg-[#434F5D] text-gray-800 dark:text-gray-200 cursor-pointer scale-100 opacity-100' 
                            : 'bg-transparent text-transparent scale-75 opacity-0 pointer-events-none w-0 -ml-2'
                        }\`}
                        title="Send message"
                        style={{ transition: 'all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
                      >
                        <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
                      </button>
                    </>`;

const newButtons = `                    <>
                      <button
                        type="button"
                        onClick={toggleDictation}
                        disabled={isDictatingTranscribing}
                        className={\`w-10 h-10 rounded-full flex items-center justify-center transition-all \${
                          isDictating
                            ? 'bg-red-500 text-white animate-pulse'
                            : isDictatingTranscribing 
                              ? 'text-gray-400 opacity-50 cursor-wait'
                              : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer'
                        }\`}
                        title={isDictating ? 'Dictating... click to stop' : 'Dictate with Groq Whisper'}
                      >
                        {isDictatingTranscribing ? (
                          <Loader2 className="w-[20px] h-[20px] animate-spin" strokeWidth={2} />
                        ) : (
                          <Mic className="w-[20px] h-[20px]" strokeWidth={2} />
                        )}
                      </button>
                      
                      <button
                        type="button"
                        onClick={toggleMicListening}
                        className="w-10 h-10 rounded-full bg-blue-500 hover:bg-blue-600 flex items-center justify-center text-white transition-colors cursor-pointer ml-1"
                        title="Voice Chat Mode"
                      >
                        <AudioLines className="w-[20px] h-[20px]" strokeWidth={2.5} />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSend()}
                        disabled={!input.trim()}
                        className={\`w-10 h-10 rounded-full flex items-center justify-center transition-transform active:scale-95 ml-1 \${
                          input.trim() 
                            ? 'bg-[#EAE8E3] dark:bg-[#343D49] hover:bg-[#DCDAD5] dark:hover:bg-[#434F5D] text-gray-800 dark:text-gray-200 cursor-pointer scale-100 opacity-100' 
                            : 'bg-transparent text-transparent scale-75 opacity-0 pointer-events-none w-0 -ml-2'
                        }\`}
                        title="Send message"
                        style={{ transition: 'all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
                      >
                        <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
                      </button>
                    </>`;

code = code.replace(oldButtons, newButtons);
fs.writeFileSync('src/components/AiAgentChat.tsx', code, 'utf8');
