import { searchWebImages, searchDuckDuckGo } from './server.ts';

async function run() {
  console.log("Testing searchWebImages...");
  const images = await searchWebImages("disha patani", 5);
  console.log("Images found:", images.length);
  console.log(images);

  console.log("\nTesting searchDuckDuckGo...");
  const webResults = await searchDuckDuckGo("disha patani news", 3);
  console.log("Web Results found:", webResults.length);
  console.log(webResults);
}

run();
