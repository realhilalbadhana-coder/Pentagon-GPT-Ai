const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');
code = code.replace("Blend\\n  AudioLines,", "Blend,\\n  AudioLines,");
fs.writeFileSync('src/components/AiAgentChat.tsx', code, 'utf8');
