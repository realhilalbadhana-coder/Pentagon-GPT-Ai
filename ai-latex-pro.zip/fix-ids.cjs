const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

content = content.replace(/'amazon\/nova-2-lite-v1'/g, "'amazon/nova-2-lite-v1:free'");
content = content.replace(/id: 'amazon\/nova-2-lite-v1',/g, "id: 'amazon/nova-2-lite-v1:free',");
content = content.replace(/'minimax\/minimax-m2\.7'/g, "'minimax/minimax-m2.7:free'");
content = content.replace(/id: 'minimax\/minimax-m2\.7',/g, "id: 'minimax/minimax-m2.7:free',");

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
