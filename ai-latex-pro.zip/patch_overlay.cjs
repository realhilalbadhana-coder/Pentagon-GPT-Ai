const fs = require('fs');
let code = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

const oldOverlayRegex = /\{showVoiceOverlay && \([\s\S]*?\{\/\* Bottom Pill \(Copilot style\) \*\//;

const newOverlay = `{showVoiceOverlay && (
        <div className="fixed inset-0 z-[100] bg-white/95 dark:bg-[#09090b]/95 backdrop-blur-md flex flex-col items-center justify-between animate-in fade-in duration-300">
          
          {/* ChatGPT style voice cloud overlay center */}
          <div className="flex-1 w-full flex flex-col justify-center items-center overflow-hidden">
            <div className="relative w-[300px] h-[300px] flex items-center justify-center transition-all duration-500">
              {/* Main outer glow/cloud */}
              <div 
                className={\`absolute inset-0 rounded-full bg-gradient-to-tr from-[#8ab4f8] via-[#aecbfa] to-[#e8f0fe] dark:from-[#3b82f6] dark:via-[#60a5fa] dark:to-[#93c5fd] mix-blend-multiply dark:mix-blend-screen transition-all duration-700 ease-in-out \${isLiveListening ? 'scale-110 opacity-70 animate-[pulse_2s_ease-in-out_infinite]' : isSpeaking ? 'scale-125 opacity-100 animate-[spin_4s_linear_infinite]' : 'scale-90 opacity-40'}\`}
                style={{ filter: 'blur(20px)' }}
              />
              {/* Inner core */}
              <div 
                className={\`absolute inset-6 rounded-full bg-gradient-to-bl from-[#d2e3fc] to-[#ffffff] dark:from-[#2563eb] dark:to-[#60a5fa] opacity-90 transition-all duration-500 ease-in-out \${isLiveListening ? 'scale-105' : 'scale-95'}\`}
                style={{ filter: 'blur(10px)' }}
              />
            </div>
          </div>

          {/* Bottom Pill (Copilot style) */}`;

code = code.replace(oldOverlayRegex, newOverlay);

fs.writeFileSync('src/components/AiAgentChat.tsx', code, 'utf8');
