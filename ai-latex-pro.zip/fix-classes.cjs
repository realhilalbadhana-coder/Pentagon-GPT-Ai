const fs = require('fs');
let content = fs.readFileSync('src/components/AiAgentChat.tsx', 'utf8');

// Fix compounded opacities
content = content.replace(/bg-\[\#323130\](?:\/\d+)+/g, 'bg-[#323130]/10');
content = content.replace(/text-\[\#323130\](?:\/\d+)+/g, 'text-[#323130]/70');
content = content.replace(/border-\[\#323130\](?:\/\d+)+/g, 'border-[#323130]/15');
content = content.replace(/hover:bg-\[\#323130\]\/10/g, 'hover:bg-[#323130]/15');
content = content.replace(/bg-\[\#FFFFFF\](?:\/\d+)+/g, 'bg-[#FFFFFF]/80');

fs.writeFileSync('src/components/AiAgentChat.tsx', content, 'utf8');
